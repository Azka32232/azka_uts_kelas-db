import 'package:flutter/material.dart';

import 'package:flutter_app/pages/cover_eticket_app.dart';
import 'package:flutter_app/pages/detail_ticket.dart';
import 'package:flutter_app/pages/fa_6_solidplane_departure.dart';
import 'package:flutter_app/pages/fa_6_solidplane_departure_1.dart';
import 'package:flutter_app/pages/frame_100.dart';
import 'package:flutter_app/pages/frame_80.dart';
import 'package:flutter_app/pages/home_screen.dart';
import 'package:flutter_app/pages/iconsax_boldfilter.dart';
import 'package:flutter_app/pages/kretya_studio.dart';
import 'package:flutter_app/pages/schedule.dart';
import 'package:flutter_app/pages/screen_flights.dart';

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter App',
      home: Scaffold(
        #body: CoverEticketApp(),
        #body: DetailTicket(),
        #body: Fa6SolidplaneDeparture(),
        #body: Fa6SolidplaneDeparture1(),
        #body: Frame100(),
        #body: Frame80(),
        #body: HomeScreen(),
        #body: IconsaxBoldfilter(),
        #body: KretyaStudio(),
        #body: Schedule(),
        #body: ScreenFlights(),
      ),
    );
  }
}
