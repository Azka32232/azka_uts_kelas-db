import 'package:flutter/material.dart';
import 'dart:ui';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_app/utils.dart';
import 'package:google_fonts/google_fonts.dart';

class CoverEticketApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return 
    Container(
      decoration: BoxDecoration(
        color: Color(0xFF121212),
      ),
      child: SizedBox(
        width: 1600,
        child: Container(
          padding: EdgeInsets.fromLTRB(107, 0, 94.9, 0),
          child: Stack(
            clipBehavior: Clip.none,
            children: [
              Positioned(
                right: -143.9,
                top: 56,
                child: ImageFiltered(
                  imageFilter: ImageFilter.blur(
                    sigmaX: 150,
                    sigmaY: 150,
                  ),
                  child: Container(
                    decoration: BoxDecoration(
                      color: Color(0xFF39CABD),
                      borderRadius: BorderRadius.circular(144.5),
                    ),
                    child: Container(
                      width: 289,
                      height: 289,
                    ),
                  ),
                ),
              ),
              Positioned(
                left: 514,
                bottom: -84,
                child: ImageFiltered(
                  imageFilter: ImageFilter.blur(
                    sigmaX: 150,
                    sigmaY: 150,
                  ),
                  child: Container(
                    decoration: BoxDecoration(
                      color: Color(0xFF7C74EE),
                      borderRadius: BorderRadius.circular(133),
                    ),
                    child: Container(
                      width: 266,
                      height: 266,
                    ),
                  ),
                ),
              ),
              Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    margin: EdgeInsets.fromLTRB(91, 0, 91, 63.5),
                    child: Align(
                      alignment: Alignment.topLeft,
                      child: ImageFiltered(
                        imageFilter: ImageFilter.blur(
                          sigmaX: 150,
                          sigmaY: 150,
                        ),
                        child: Container(
                          decoration: BoxDecoration(
                            color: Color(0xFF39CABD),
                            borderRadius: BorderRadius.circular(141.5),
                          ),
                          child: Container(
                            width: 283,
                            height: 283,
                          ),
                        ),
                      ),
                    ),
                  ),
                  Stack(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 177.5, 22.1, 0),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  margin: EdgeInsets.fromLTRB(0, 0, 0, 120),
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        margin: EdgeInsets.fromLTRB(0, 0, 27.7, 14),
                                        child: Text(
                                          'E-Ticket App',
                                          style: GoogleFonts.getFont(
                                            'Montserrat',
                                            fontWeight: FontWeight.w700,
                                            fontSize: 64,
                                            letterSpacing: 5.1,
                                            color: Color(0xFFF6F6F6),
                                          ),
                                        ),
                                      ),
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Container(
                                            margin: EdgeInsets.fromLTRB(0, 0.5, 40.1, 0.5),
                                            child: Text(
                                              'Mobile App UI KIT',
                                              style: GoogleFonts.getFont(
                                                'Montserrat',
                                                fontWeight: FontWeight.w600,
                                                fontSize: 40,
                                                letterSpacing: 3.2,
                                                color: Color(0xFFF6F6F6),
                                              ),
                                            ),
                                          ),
                                          Container(
                                            decoration: BoxDecoration(
                                              borderRadius: BorderRadius.circular(6),
                                              color: Color(0xFF212121),
                                              boxShadow: [
                                                BoxShadow(
                                                  color: Color(0x40000000),
                                                  offset: Offset(0, 2),
                                                  blurRadius: 1,
                                                ),
                                              ],
                                            ),
                                            child: SizedBox(
                                              width: 50,
                                              child: Container(
                                                padding: EdgeInsets.fromLTRB(12.5, 6.3, 12.5, 6.3),
                                                child: Column(
                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    SizedBox(
                                                      width: 25,
                                                      child: Row(
                                                        mainAxisAlignment: MainAxisAlignment.start,
                                                        crossAxisAlignment: CrossAxisAlignment.start,
                                                        children: [
                                                          SizedBox(
                                                            width: 12.5,
                                                            height: 12.5,
                                                            child: SvgPicture.asset(
                                                              'assets/vectors/vector_77_x2.svg',
                                                            ),
                                                          ),
                                                          SizedBox(
                                                            width: 12.5,
                                                            height: 12.5,
                                                            child: SvgPicture.asset(
                                                              'assets/vectors/vector_18_x2.svg',
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    SizedBox(
                                                      width: 25,
                                                      child: Row(
                                                        mainAxisAlignment: MainAxisAlignment.start,
                                                        crossAxisAlignment: CrossAxisAlignment.start,
                                                        children: [
                                                          SizedBox(
                                                            width: 12.5,
                                                            height: 12.5,
                                                            child: SvgPicture.asset(
                                                              'assets/vectors/vector_33_x2.svg',
                                                            ),
                                                          ),
                                                          SizedBox(
                                                            width: 12.5,
                                                            height: 12.5,
                                                            child: SvgPicture.asset(
                                                              'assets/vectors/vector_27_x2.svg',
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    Align(
                                                      alignment: Alignment.topLeft,
                                                      child: SizedBox(
                                                        width: 12.5,
                                                        height: 12.5,
                                                        child: SvgPicture.asset(
                                                          'assets/vectors/vector_41_x2.svg',
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  margin: EdgeInsets.fromLTRB(3.3, 0, 3.3, 0),
                                  child: Align(
                                    alignment: Alignment.topLeft,
                                    child: Column(
                                      mainAxisAlignment: MainAxisAlignment.start,
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          margin: EdgeInsets.fromLTRB(0, 0, 10, 32),
                                          child: Row(
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Container(
                                                margin: EdgeInsets.fromLTRB(0, 2.3, 27.3, 3.3),
                                                width: 33.3,
                                                height: 33.3,
                                                child: SizedBox(
                                                  width: 33.3,
                                                  height: 33.3,
                                                  child: SvgPicture.asset(
                                                    'assets/vectors/vector_72_x2.svg',
                                                  ),
                                                ),
                                              ),
                                              Text(
                                                'Home Screen',
                                                style: GoogleFonts.getFont(
                                                  'Montserrat',
                                                  fontWeight: FontWeight.w500,
                                                  fontSize: 32,
                                                  letterSpacing: 2.6,
                                                  color: Color(0xFFF6F6F6),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Container(
                                          margin: EdgeInsets.fromLTRB(0, 0, 28.6, 33),
                                          child: Row(
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Container(
                                                margin: EdgeInsets.fromLTRB(0, 3.3, 27.3, 2.3),
                                                width: 33.3,
                                                height: 33.3,
                                                child: SizedBox(
                                                  width: 33.3,
                                                  height: 33.3,
                                                  child: SvgPicture.asset(
                                                    'assets/vectors/vector_68_x2.svg',
                                                  ),
                                                ),
                                              ),
                                              Text(
                                                'Detail Order',
                                                style: GoogleFonts.getFont(
                                                  'Montserrat',
                                                  fontWeight: FontWeight.w500,
                                                  fontSize: 32,
                                                  letterSpacing: 2.6,
                                                  color: Color(0xFFF6F6F6),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Container(
                                          margin: EdgeInsets.fromLTRB(0, 0, 0, 33),
                                          child: Row(
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Container(
                                                margin: EdgeInsets.fromLTRB(0, 3.3, 27.3, 2.3),
                                                width: 33.3,
                                                height: 33.3,
                                                child: SizedBox(
                                                  width: 33.3,
                                                  height: 33.3,
                                                  child: SvgPicture.asset(
                                                    'assets/vectors/vector_37_x2.svg',
                                                  ),
                                                ),
                                              ),
                                              Text(
                                                'Choose Flight',
                                                style: GoogleFonts.getFont(
                                                  'Montserrat',
                                                  fontWeight: FontWeight.w500,
                                                  fontSize: 32,
                                                  letterSpacing: 2.6,
                                                  color: Color(0xFFF6F6F6),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Container(
                                          margin: EdgeInsets.fromLTRB(0, 0, 22.6, 0),
                                          child: Row(
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Container(
                                                margin: EdgeInsets.fromLTRB(0, 3.3, 27.3, 2.3),
                                                width: 33.3,
                                                height: 33.3,
                                                child: SizedBox(
                                                  width: 33.3,
                                                  height: 33.3,
                                                  child: SvgPicture.asset(
                                                    'assets/vectors/vector_61_x2.svg',
                                                  ),
                                                ),
                                              ),
                                              Text(
                                                'Ticket Detail',
                                                style: GoogleFonts.getFont(
                                                  'Montserrat',
                                                  fontWeight: FontWeight.w500,
                                                  fontSize: 32,
                                                  letterSpacing: 2.6,
                                                  color: Color(0xFFF6F6F6),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 0, 67.8, 16.5),
                            child: Transform(
                              transform: Matrix4.identity()..rotationZ(-0.1745330593),
                              child: Container(
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(15.1),
                                  color: Color(0xFFFFFFFF),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Color(0x33000000),
                                      offset: Offset(0, 30.1),
                                      blurRadius: 18.8270626068,
                                    ),
                                    BoxShadow(
                                      color: Color(0x33000000),
                                      offset: Offset(0, -30.1),
                                      blurRadius: 15.0616512299,
                                    ),
                                  ],
                                ),
                                child: SizedBox(
                                  width: 399.6,
                                  child: Container(
                                    padding: EdgeInsets.fromLTRB(0, 0, 0, 57.1),
                                    child: Stack(
                                      clipBehavior: Clip.none,
                                      children: [
                                        Column(
                                          mainAxisAlignment: MainAxisAlignment.start,
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            Container(
                                              margin: EdgeInsets.fromLTRB(0, 0, 0, 174.1),
                                              child: Container(
                                                decoration: BoxDecoration(
                                                  color: Color(0xFF7060E5),
                                                  borderRadius: BorderRadius.circular(15.1),
                                                ),
                                                child: SizedBox(
                                                  height: 377.3,
                                                  child: Container(
                                                    padding: EdgeInsets.fromLTRB(27.4, 16, 27.4, 0),
                                                    child: Stack(
                                                      clipBehavior: Clip.none,
                                                      children: [
                                                        Positioned(
                                                          left: -60.3,
                                                          top: -30.8,
                                                          child: Container(
                                                            decoration: BoxDecoration(
                                                              color: Color(0xFF7868EC),
                                                              borderRadius: BorderRadius.circular(62.9),
                                                            ),
                                                            child: Container(
                                                              width: 145.7,
                                                              height: 145.7,
                                                            ),
                                                          ),
                                                        ),
                                                        Positioned(
                                                          left: -78.2,
                                                          top: -20.3,
                                                          child: Container(
                                                            decoration: BoxDecoration(
                                                              color: Color(0xFF7F6FF2),
                                                              borderRadius: BorderRadius.circular(52.7),
                                                            ),
                                                            child: Container(
                                                              width: 122.1,
                                                              height: 122.1,
                                                              padding: EdgeInsets.fromLTRB(6.1, 14.1, 6.1, 0),
                                                              child: Container(
                                                                decoration: BoxDecoration(
                                                                  color: Color(0xFF8778F8),
                                                                  borderRadius: BorderRadius.circular(37.7),
                                                                ),
                                                                child: Container(
                                                                  width: 87.2,
                                                                  height: 87.2,
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                        Column(
                                                          mainAxisAlignment: MainAxisAlignment.start,
                                                          crossAxisAlignment: CrossAxisAlignment.center,
                                                          children: [
                                                            Container(
                                                              margin: EdgeInsets.fromLTRB(0, 0, 5.4, 18.7),
                                                              child: SizedBox(
                                                                width: 251.1,
                                                                child: Row(
                                                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                                  children: [
                                                                    Container(
                                                                      margin: EdgeInsets.fromLTRB(0, 35.7, 0, 0),
                                                                      child: Text(
                                                                        '9:41',
                                                                        style: GoogleFonts.getFont(
                                                                          'Roboto Condensed',
                                                                          fontWeight: FontWeight.w400,
                                                                          fontSize: 12.8,
                                                                          height: 1.3,
                                                                          color: Color(0xFFFFFFFF),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                    Container(
                                                                      margin: EdgeInsets.fromLTRB(0, 0, 0, 36.4),
                                                                      child: SizedBox(
                                                                        width: 40.7,
                                                                        child: Row(
                                                                          mainAxisAlignment: MainAxisAlignment.start,
                                                                          crossAxisAlignment: CrossAxisAlignment.start,
                                                                          children: [
                                                                            Container(
                                                                              margin: EdgeInsets.fromLTRB(0, 5.1, 4, 0),
                                                                              child: SizedBox(
                                                                                width: 14.2,
                                                                                height: 11.2,
                                                                                child: SvgPicture.asset(
                                                                                  'assets/vectors/wifi_5_x2.svg',
                                                                                ),
                                                                              ),
                                                                            ),
                                                                            Container(
                                                                              margin: EdgeInsets.fromLTRB(0, 0, 0, 3),
                                                                              child: SizedBox(
                                                                                width: 22.5,
                                                                                height: 13.3,
                                                                                child: SvgPicture.asset(
                                                                                  'assets/vectors/battery_5_x2.svg',
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ],
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                              ),
                                                            ),
                                                            Container(
                                                              margin: EdgeInsets.fromLTRB(13.4, 0, 0, 0),
                                                              child: Row(
                                                                mainAxisAlignment: MainAxisAlignment.start,
                                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                                children: [
                                                                  Container(
                                                                    margin: EdgeInsets.fromLTRB(0, 29.8, 3.2, 0),
                                                                    child: Container(
                                                                      decoration: BoxDecoration(
                                                                        color: Color(0x33FFFFFF),
                                                                        borderRadius: BorderRadius.circular(7.5),
                                                                      ),
                                                                      child: Container(
                                                                        padding: EdgeInsets.fromLTRB(13, 8.4, 11.1, 10.5),
                                                                        child: Row(
                                                                          mainAxisAlignment: MainAxisAlignment.start,
                                                                          crossAxisAlignment: CrossAxisAlignment.start,
                                                                          children: [
                                                                            Container(
                                                                              margin: EdgeInsets.fromLTRB(0, 10.2, 5.5, 0),
                                                                              width: 6.4,
                                                                              height: 7.8,
                                                                              child: SizedBox(
                                                                                width: 6.4,
                                                                                height: 7.8,
                                                                                child: SvgPicture.asset(
                                                                                  'assets/vectors/frame_521_x2.svg',
                                                                                ),
                                                                              ),
                                                                            ),
                                                                            Container(
                                                                              margin: EdgeInsets.fromLTRB(0, 0, 0, 9),
                                                                              child: Text(
                                                                                'One-way',
                                                                                style: GoogleFonts.getFont(
                                                                                  'Poppins',
                                                                                  fontWeight: FontWeight.w400,
                                                                                  fontSize: 9,
                                                                                  height: 1,
                                                                                  color: Color(0xFFFFFFFF),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ],
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  Container(
                                                                    margin: EdgeInsets.fromLTRB(0, 15.4, 1.6, 14.4),
                                                                    child: Container(
                                                                      decoration: BoxDecoration(
                                                                        color: Color(0xFFFFFFFF),
                                                                        borderRadius: BorderRadius.circular(7.5),
                                                                      ),
                                                                      child: Container(
                                                                        padding: EdgeInsets.fromLTRB(6.6, 8.2, 6.9, 8.5),
                                                                        child: Row(
                                                                          mainAxisAlignment: MainAxisAlignment.start,
                                                                          crossAxisAlignment: CrossAxisAlignment.start,
                                                                          children: [
                                                                            Container(
                                                                              margin: EdgeInsets.fromLTRB(0, 9.9, 3.8, 0),
                                                                              width: 10.2,
                                                                              height: 10.2,
                                                                              child: SizedBox(
                                                                                width: 10.2,
                                                                                height: 10.2,
                                                                                child: SvgPicture.asset(
                                                                                  'assets/vectors/vector_82_x2.svg',
                                                                                ),
                                                                              ),
                                                                            ),
                                                                            Container(
                                                                              margin: EdgeInsets.fromLTRB(0, 0, 0, 11.1),
                                                                              child: Text(
                                                                                'Round-trip',
                                                                                style: GoogleFonts.getFont(
                                                                                  'Poppins',
                                                                                  fontWeight: FontWeight.w600,
                                                                                  fontSize: 9,
                                                                                  height: 1,
                                                                                  color: Color(0xFF7060E5),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ],
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  Container(
                                                                    margin: EdgeInsets.fromLTRB(0, 0, 0, 27.8),
                                                                    child: Container(
                                                                      decoration: BoxDecoration(
                                                                        color: Color(0x33FFFFFF),
                                                                        borderRadius: BorderRadius.circular(7.5),
                                                                      ),
                                                                      child: Container(
                                                                        padding: EdgeInsets.fromLTRB(11.7, 9.8, 12.4, 9.2),
                                                                        child: Row(
                                                                          mainAxisAlignment: MainAxisAlignment.start,
                                                                          crossAxisAlignment: CrossAxisAlignment.start,
                                                                          children: [
                                                                            Container(
                                                                              margin: EdgeInsets.fromLTRB(0, 7.5, 2.7, 0),
                                                                              child: SizedBox(
                                                                                width: 12.2,
                                                                                height: 12.2,
                                                                                child: SvgPicture.asset(
                                                                                  'assets/vectors/iconsax_lineararrow_x2.svg',
                                                                                ),
                                                                              ),
                                                                            ),
                                                                            Container(
                                                                              margin: EdgeInsets.fromLTRB(0, 0, 0, 10.7),
                                                                              child: Text(
                                                                                'Multi-city',
                                                                                style: GoogleFonts.getFont(
                                                                                  'Poppins',
                                                                                  fontWeight: FontWeight.w400,
                                                                                  fontSize: 9,
                                                                                  height: 1,
                                                                                  color: Color(0xFFFFFFFF),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ],
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                        Positioned(
                                                          left: -0.8,
                                                          top: 57.3,
                                                          child: SizedBox(
                                                            width: 151,
                                                            height: 36.2,
                                                            child: Row(
                                                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                              crossAxisAlignment: CrossAxisAlignment.start,
                                                              children: [
                                                                Container(
                                                                  margin: EdgeInsets.fromLTRB(0, 24, 0, 0),
                                                                  width: 14,
                                                                  height: 12.2,
                                                                  child: Container(
                                                                    width: 14,
                                                                    height: 12.2,
                                                                    child: SizedBox(
                                                                      width: 14,
                                                                      height: 12.2,
                                                                      child: SvgPicture.asset(
                                                                        'assets/vectors/combined_shape_x2.svg',
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                                Container(
                                                                  margin: EdgeInsets.fromLTRB(0, 0, 0, 27.2),
                                                                  child: Text(
                                                                    'Flights',
                                                                    style: GoogleFonts.getFont(
                                                                      'Poppins',
                                                                      fontWeight: FontWeight.w600,
                                                                      fontSize: 13.6,
                                                                      height: 0.7,
                                                                      letterSpacing: 0.2,
                                                                      color: Color(0xFFFFFFFF),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Container(
                                              margin: EdgeInsets.fromLTRB(0, 0, 41.5, 1.2),
                                              child: Text(
                                                'Lower Price!',
                                                style: GoogleFonts.getFont(
                                                  'Poppins',
                                                  fontWeight: FontWeight.w600,
                                                  fontSize: 15.1,
                                                  letterSpacing: 0.1,
                                                  color: Color(0xFF121212),
                                                ),
                                              ),
                                            ),
                                            Container(
                                              margin: EdgeInsets.fromLTRB(20.5, 0, 0, 0),
                                              child: Row(
                                                mainAxisAlignment: MainAxisAlignment.start,
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    margin: EdgeInsets.fromLTRB(0, 14.3, 3.9, 0),
                                                    decoration: BoxDecoration(
                                                      borderRadius: BorderRadius.circular(7.5),
                                                      color: Color(0xFF7060E5),
                                                      boxShadow: [
                                                        BoxShadow(
                                                          color: Color(0x24000000),
                                                          offset: Offset(0, 3),
                                                          blurRadius: 7.5308256149,
                                                        ),
                                                      ],
                                                    ),
                                                    child: Container(
                                                      padding: EdgeInsets.fromLTRB(7.9, 4.3, 10.1, 11.7),
                                                      child: Text(
                                                        'Domestic',
                                                        style: GoogleFonts.getFont(
                                                          'Poppins',
                                                          fontWeight: FontWeight.w500,
                                                          fontSize: 9,
                                                          letterSpacing: 0,
                                                          color: Color(0xFFEEEEEE),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    margin: EdgeInsets.fromLTRB(0, 0, 0, 11.6),
                                                    decoration: BoxDecoration(
                                                      borderRadius: BorderRadius.circular(7.5),
                                                      color: Color(0x1A7060E5),
                                                      boxShadow: [
                                                        BoxShadow(
                                                          color: Color(0x1F000000),
                                                          offset: Offset(0, 3),
                                                          blurRadius: 7.5308256149,
                                                        ),
                                                      ],
                                                    ),
                                                    child: Container(
                                                      padding: EdgeInsets.fromLTRB(7.9, 4.3, 10.1, 14.5),
                                                      child: Text(
                                                        'International',
                                                        style: GoogleFonts.getFont(
                                                          'Poppins',
                                                          fontWeight: FontWeight.w500,
                                                          fontSize: 9,
                                                          letterSpacing: 0,
                                                          color: Color(0xFF7060E5),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                        Positioned(
                                          right: -1.4,
                                          top: 113.9,
                                          child: Container(
                                            decoration: BoxDecoration(
                                              color: Color(0xFFE8E8E8),
                                              borderRadius: BorderRadius.circular(7.5),
                                            ),
                                            child: SizedBox(
                                              width: 80.1,
                                              height: 42.9,
                                              child: Container(
                                                padding: EdgeInsets.fromLTRB(13.2, 9.1, 15.1, 9.7),
                                                child: Row(
                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    Container(
                                                      margin: EdgeInsets.fromLTRB(0, 7.2, 7, 0),
                                                      width: 15.9,
                                                      height: 16.9,
                                                      child: SizedBox(
                                                        width: 15.9,
                                                        height: 16.9,
                                                        child: SvgPicture.asset(
                                                          'assets/vectors/vector_39_x2.svg',
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      margin: EdgeInsets.fromLTRB(0, 0, 0, 9.1),
                                                      child: Text(
                                                        'Flight',
                                                        style: GoogleFonts.getFont(
                                                          'Poppins',
                                                          fontWeight: FontWeight.w500,
                                                          fontSize: 10.5,
                                                          height: 1.4,
                                                          letterSpacing: 0.2,
                                                          color: Color(0xFF121212),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Positioned(
                                          left: 37.1,
                                          top: 128.7,
                                          child: Container(
                                            decoration: BoxDecoration(
                                              borderRadius: BorderRadius.circular(15.1),
                                              color: Color(0xFFFFFFFF),
                                              boxShadow: [
                                                BoxShadow(
                                                  color: Color(0x24000000),
                                                  offset: Offset(0, 3),
                                                  blurRadius: 11.2962379456,
                                                ),
                                              ],
                                            ),
                                            child: SizedBox(
                                              height: 333.5,
                                              child: Container(
                                                padding: EdgeInsets.fromLTRB(17.4, 0, 24.5, 0),
                                                child: Stack(
                                                  clipBehavior: Clip.none,
                                                  children: [
                                                    Positioned(
                                                      left: 6,
                                                      top: 51.6,
                                                      child: Container(
                                                        decoration: BoxDecoration(
                                                          color: Color(0xFFDEDEDE),
                                                        ),
                                                        child: Container(
                                                          width: 229.9,
                                                          height: 0.8,
                                                        ),
                                                      ),
                                                    ),
                                                    Column(
                                                      mainAxisAlignment: MainAxisAlignment.start,
                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                      children: [
                                                        Container(
                                                          margin: EdgeInsets.fromLTRB(0, 0, 0, 0.9),
                                                          child: Align(
                                                            alignment: Alignment.topLeft,
                                                            child: SizedBox(
                                                              width: 238.1,
                                                              child: Row(
                                                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                                children: [
                                                                  Container(
                                                                    margin: EdgeInsets.fromLTRB(0, 15.6, 0, 0),
                                                                    child: Row(
                                                                      mainAxisAlignment: MainAxisAlignment.start,
                                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                                      children: [
                                                                        Container(
                                                                          margin: EdgeInsets.fromLTRB(0, 0, 2.4, 5.4),
                                                                          child: Text(
                                                                            'From',
                                                                            style: GoogleFonts.getFont(
                                                                              'Poppins',
                                                                              fontWeight: FontWeight.w400,
                                                                              fontSize: 9,
                                                                              color: Color(0xFF9B9B9B),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                        Container(
                                                                          margin: EdgeInsets.fromLTRB(0, 4.4, 0, 0),
                                                                          child: Text(
                                                                            'Bandung (BDO)',
                                                                            style: GoogleFonts.getFont(
                                                                              'Poppins',
                                                                              fontWeight: FontWeight.w400,
                                                                              fontSize: 10.5,
                                                                              color: Color(0xFF464646),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                  Container(
                                                                    margin: EdgeInsets.fromLTRB(0, 0, 0, 4.4),
                                                                    decoration: BoxDecoration(
                                                                      border: Border.all(color: Color(0xFFDEDEDE)),
                                                                      borderRadius: BorderRadius.circular(65.9),
                                                                      color: Color(0xFFFFFFFF),
                                                                      boxShadow: [
                                                                        BoxShadow(
                                                                          color: Color(0x1A000000),
                                                                          offset: Offset(0, 0),
                                                                          blurRadius: 6.5894732475,
                                                                        ),
                                                                      ],
                                                                    ),
                                                                    child: Container(
                                                                      width: 30.5,
                                                                      height: 30.5,
                                                                      padding: EdgeInsets.fromLTRB(2.5, 5.2, 2.5, 5.2),
                                                                      child: SizedBox(
                                                                        width: 24.8,
                                                                        height: 19.5,
                                                                        child: SvgPicture.asset(
                                                                          'assets/vectors/group_31_x2.svg',
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                        Container(
                                                          margin: EdgeInsets.fromLTRB(3.3, 0, 3.3, 5.4),
                                                          child: Align(
                                                            alignment: Alignment.topLeft,
                                                            child: Container(
                                                              width: 16.8,
                                                              height: 13.6,
                                                              child: SizedBox(
                                                                width: 16.8,
                                                                height: 13.6,
                                                                child: SvgPicture.asset(
                                                                  'assets/vectors/vector_24_x2.svg',
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                        Container(
                                                          margin: EdgeInsets.fromLTRB(13.3, 0, 25.1, 3.8),
                                                          child: Container(
                                                            decoration: BoxDecoration(
                                                              color: Color(0xFFDEDEDE),
                                                            ),
                                                            child: Container(
                                                              width: 229.9,
                                                              height: 0.8,
                                                            ),
                                                          ),
                                                        ),
                                                        Container(
                                                          margin: EdgeInsets.fromLTRB(7.3, 0, 20.8, 7.7),
                                                          child: SizedBox(
                                                            width: 240.2,
                                                            child: Stack(
                                                              children: [
                                                                SizedBox(
                                                                  width: 240.2,
                                                                  child: Row(
                                                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                                    crossAxisAlignment: CrossAxisAlignment.start,
                                                                    children: [
                                                                      Row(
                                                                        mainAxisAlignment: MainAxisAlignment.start,
                                                                        crossAxisAlignment: CrossAxisAlignment.start,
                                                                        children: [
                                                                          Container(
                                                                            margin: EdgeInsets.fromLTRB(0, 0, 5.5, 0),
                                                                            child: Column(
                                                                              mainAxisAlignment: MainAxisAlignment.start,
                                                                              crossAxisAlignment: CrossAxisAlignment.center,
                                                                              children: [
                                                                                Container(
                                                                                  margin: EdgeInsets.fromLTRB(0, 0, 12.3, 2.6),
                                                                                  child: Text(
                                                                                    'To',
                                                                                    style: GoogleFonts.getFont(
                                                                                      'Poppins',
                                                                                      fontWeight: FontWeight.w400,
                                                                                      fontSize: 9,
                                                                                      color: Color(0xFF9B9B9B),
                                                                                    ),
                                                                                  ),
                                                                                ),
                                                                                Container(
                                                                                  margin: EdgeInsets.fromLTRB(6.1, 0, 0, 0),
                                                                                  width: 16.9,
                                                                                  height: 14.5,
                                                                                  child: SizedBox(
                                                                                    width: 16.9,
                                                                                    height: 14.5,
                                                                                    child: SvgPicture.asset(
                                                                                      'assets/vectors/vector_51_x2.svg',
                                                                                    ),
                                                                                  ),
                                                                                ),
                                                                              ],
                                                                            ),
                                                                          ),
                                                                          Container(
                                                                            margin: EdgeInsets.fromLTRB(0, 1.4, 0, 14.6),
                                                                            child: Text(
                                                                              'Denpasar (DPS)',
                                                                              style: GoogleFonts.getFont(
                                                                                'Poppins',
                                                                                fontWeight: FontWeight.w400,
                                                                                fontSize: 10.5,
                                                                                color: Color(0xFF464646),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ],
                                                                      ),
                                                                      Container(
                                                                        margin: EdgeInsets.fromLTRB(0, 7.4, 0, 9.7),
                                                                        child: Text(
                                                                          'Round-trip?',
                                                                          style: GoogleFonts.getFont(
                                                                            'Poppins',
                                                                            fontWeight: FontWeight.w400,
                                                                            fontSize: 9,
                                                                            color: Color(0xFF9B9B9B),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ],
                                                                  ),
                                                                ),
                                                                Positioned(
                                                                  left: 6,
                                                                  top: 5.9,
                                                                  child: Container(
                                                                    decoration: BoxDecoration(
                                                                      color: Color(0xFFD0CFCF),
                                                                    ),
                                                                    child: Container(
                                                                      width: 170.6,
                                                                      height: 0.8,
                                                                    ),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                        Container(
                                                          margin: EdgeInsets.fromLTRB(16, 0, 16, 11.3),
                                                          child: Align(
                                                            alignment: Alignment.topLeft,
                                                            child: Text(
                                                              'Departure Date',
                                                              style: GoogleFonts.getFont(
                                                                'Poppins',
                                                                fontWeight: FontWeight.w400,
                                                                fontSize: 9,
                                                                color: Color(0xFF9B9B9B),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                        Container(
                                                          margin: EdgeInsets.fromLTRB(20.5, 0, 20.5, 8.3),
                                                          child: Align(
                                                            alignment: Alignment.topLeft,
                                                            child: Container(
                                                              width: 13.4,
                                                              height: 14.9,
                                                              child: SizedBox(
                                                                width: 13.4,
                                                                height: 14.9,
                                                                child: SvgPicture.asset(
                                                                  'assets/vectors/vector_67_x2.svg',
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                        Container(
                                                          margin: EdgeInsets.fromLTRB(0, 0, 71.3, 3.3),
                                                          child: Align(
                                                            alignment: Alignment.topCenter,
                                                            child: Text(
                                                              'Sunday, 15 Feb 2023',
                                                              style: GoogleFonts.getFont(
                                                                'Poppins',
                                                                fontWeight: FontWeight.w400,
                                                                fontSize: 10.5,
                                                                color: Color(0xFF464646),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                        Align(
                                                          alignment: Alignment.topRight,
                                                          child: Row(
                                                            mainAxisAlignment: MainAxisAlignment.start,
                                                            crossAxisAlignment: CrossAxisAlignment.start,
                                                            children: [
                                                              Container(
                                                                margin: EdgeInsets.fromLTRB(0, 0, 8.7, 0),
                                                                child: Column(
                                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                                  children: [
                                                                    Container(
                                                                      margin: EdgeInsets.fromLTRB(0, 0, 0, 11.8),
                                                                      child: Align(
                                                                        alignment: Alignment.topLeft,
                                                                        child: Container(
                                                                          width: 13.4,
                                                                          height: 14.9,
                                                                          child: SizedBox(
                                                                            width: 13.4,
                                                                            height: 14.9,
                                                                            child: SvgPicture.asset(
                                                                              'assets/vectors/vector_8_x2.svg',
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                    Container(
                                                                      margin: EdgeInsets.fromLTRB(4.1, 0, 0, 0),
                                                                      child: Container(
                                                                        padding: EdgeInsets.fromLTRB(4.7, 9.8, 0, 0),
                                                                        child: Stack(
                                                                          clipBehavior: Clip.none,
                                                                          children: [
                                                                            Column(
                                                                              mainAxisAlignment: MainAxisAlignment.start,
                                                                              crossAxisAlignment: CrossAxisAlignment.end,
                                                                              children: [
                                                                                Container(
                                                                                  margin: EdgeInsets.fromLTRB(16.5, 0, 16.5, 1.5),
                                                                                  child: Text(
                                                                                    '2 Passenger(s)',
                                                                                    style: GoogleFonts.getFont(
                                                                                      'Poppins',
                                                                                      fontWeight: FontWeight.w400,
                                                                                      fontSize: 10.5,
                                                                                      color: Color(0xFF464646),
                                                                                    ),
                                                                                  ),
                                                                                ),
                                                                                SizedBox(
                                                                                  width: 113.1,
                                                                                  height: 12.7,
                                                                                  child: Stack(
                                                                                    children: [
                                                                                      Container(
                                                                                        width: 14.2,
                                                                                        height: 12.7,
                                                                                        child: SizedBox(
                                                                                          width: 14.2,
                                                                                          height: 12.7,
                                                                                          child: SvgPicture.asset(
                                                                                            'assets/vectors/vector_32_x2.svg',
                                                                                          ),
                                                                                        ),
                                                                                      ),
                                                                                      Positioned(
                                                                                        right: 0,
                                                                                        top: 0.2,
                                                                                        child: Container(
                                                                                          decoration: BoxDecoration(
                                                                                            color: Color(0xFFDEDEDE),
                                                                                          ),
                                                                                          child: Container(
                                                                                            width: 111.2,
                                                                                            height: 0.8,
                                                                                          ),
                                                                                        ),
                                                                                      ),
                                                                                    ],
                                                                                  ),
                                                                                ),
                                                                              ],
                                                                            ),
                                                                            Positioned(
                                                                              left: -4.7,
                                                                              top: -9.8,
                                                                              child: SizedBox(
                                                                                height: 14,
                                                                                child: Text(
                                                                                  'Passengers',
                                                                                  style: GoogleFonts.getFont(
                                                                                    'Poppins',
                                                                                    fontWeight: FontWeight.w400,
                                                                                    fontSize: 9,
                                                                                    color: Color(0xFF9B9B9B),
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ],
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                              ),
                                                              Container(
                                                                margin: EdgeInsets.fromLTRB(0, 12.1, 0, 29.6),
                                                                child: SizedBox(
                                                                  width: 110,
                                                                  child: Container(
                                                                    padding: EdgeInsets.fromLTRB(0, 9, 12.4, 0),
                                                                    child: Stack(
                                                                      clipBehavior: Clip.none,
                                                                      children: [
                                                                        Text(
                                                                          'Economy',
                                                                          style: GoogleFonts.getFont(
                                                                            'Poppins',
                                                                            fontWeight: FontWeight.w400,
                                                                            fontSize: 10.5,
                                                                            color: Color(0xFF464646),
                                                                          ),
                                                                        ),
                                                                        Positioned(
                                                                          left: 0,
                                                                          top: 0,
                                                                          child: SizedBox(
                                                                            height: 14,
                                                                            child: Text(
                                                                              'Seat',
                                                                              style: GoogleFonts.getFont(
                                                                                'Poppins',
                                                                                fontWeight: FontWeight.w400,
                                                                                fontSize: 9,
                                                                                color: Color(0xFF9B9B9B),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                        Positioned(
                                                                          right: 0,
                                                                          bottom: 3.1,
                                                                          child: Container(
                                                                            decoration: BoxDecoration(
                                                                              color: Color(0xFFDEDEDE),
                                                                            ),
                                                                            child: Container(
                                                                              width: 103.8,
                                                                              height: 0.8,
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                    Positioned(
                                                      left: 41.2,
                                                      top: 143.4,
                                                      child: SizedBox(
                                                        height: 15,
                                                        child: Text(
                                                          'Monday, 9 Jan 2023',
                                                          style: GoogleFonts.getFont(
                                                            'Poppins',
                                                            fontWeight: FontWeight.w400,
                                                            fontSize: 10.5,
                                                            color: Color(0xFF464646),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Positioned(
                                                      left: 23.3,
                                                      bottom: 138.9,
                                                      child: SizedBox(
                                                        height: 14,
                                                        child: Text(
                                                          'Return Date',
                                                          style: GoogleFonts.getFont(
                                                            'Poppins',
                                                            fontWeight: FontWeight.w400,
                                                            fontSize: 9,
                                                            color: Color(0xFF9B9B9B),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Positioned(
                                                      top: 142,
                                                      child: SizedBox(
                                                        width: 229.9,
                                                        height: 0.8,
                                                        child: SvgPicture.asset(
                                                          'assets/vectors/container_x2.svg',
                                                        ),
                                                      ),
                                                    ),
                                                    Positioned(
                                                      right: 9.2,
                                                      bottom: 149.2,
                                                      child: Container(
                                                        decoration: BoxDecoration(
                                                          color: Color(0xFFDEDEDE),
                                                        ),
                                                        child: Container(
                                                          width: 229.9,
                                                          height: 0.8,
                                                        ),
                                                      ),
                                                    ),
                                                    Positioned(
                                                      right: -7.1,
                                                      bottom: 17.4,
                                                      child: Container(
                                                        decoration: BoxDecoration(
                                                          borderRadius: BorderRadius.circular(9),
                                                          color: Color(0xFF7060E5),
                                                          boxShadow: [
                                                            BoxShadow(
                                                              color: Color(0x1A000000),
                                                              offset: Offset(0, 3),
                                                              blurRadius: 11.2962379456,
                                                            ),
                                                          ],
                                                        ),
                                                        child: Container(
                                                          width: 234.4,
                                                          height: 65.8,
                                                          padding: EdgeInsets.fromLTRB(0, 24.2, 1.6, 29.5),
                                                          child: Text(
                                                            'Search',
                                                            style: GoogleFonts.getFont(
                                                              'Roboto',
                                                              fontWeight: FontWeight.w500,
                                                              fontSize: 10.5,
                                                              color: Color(0xFFEEEEEE),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Positioned(
                                          right: -44.8,
                                          bottom: 122.8,
                                          child: SizedBox(
                                            width: 354.3,
                                            height: 117.7,
                                            child: Container(
                                              padding: EdgeInsets.fromLTRB(0, 0, 0, 11.7),
                                              child: Stack(
                                                clipBehavior: Clip.none,
                                                children: [
                                                  Column(
                                                    mainAxisAlignment: MainAxisAlignment.start,
                                                    crossAxisAlignment: CrossAxisAlignment.end,
                                                    children: [
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(0, 0, 13.8, 52.1),
                                                        child: SizedBox(
                                                          width: 263.3,
                                                          child: Row(
                                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                            crossAxisAlignment: CrossAxisAlignment.start,
                                                            children: [
                                                              Container(
                                                                margin: EdgeInsets.fromLTRB(0, 16.9, 11.5, 0),
                                                                child: SizedBox(
                                                                  width: 227.4,
                                                                  child: Text(
                                                                    'Recent Searches',
                                                                    style: GoogleFonts.getFont(
                                                                      'Poppins',
                                                                      fontWeight: FontWeight.w600,
                                                                      fontSize: 15.1,
                                                                      color: Color(0xFF121212),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                              Container(
                                                                margin: EdgeInsets.fromLTRB(0, 0, 0, 25.9),
                                                                child: Text(
                                                                  'Clear',
                                                                  style: GoogleFonts.getFont(
                                                                    'Poppins',
                                                                    fontWeight: FontWeight.w400,
                                                                    fontSize: 9,
                                                                    color: Color(0xFF7060E5),
                                                                  ),
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ),
                                                      Text(
                                                        'See all',
                                                        style: GoogleFonts.getFont(
                                                          'Poppins',
                                                          fontWeight: FontWeight.w400,
                                                          fontSize: 9,
                                                          letterSpacing: 0,
                                                          color: Color(0xFF7060E5),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                  Positioned(
                                                    right: 0,
                                                    top: 8,
                                                    child: Container(
                                                      decoration: BoxDecoration(
                                                        borderRadius: BorderRadius.circular(7.5),
                                                        color: Color(0xFFFFFFFF),
                                                        boxShadow: [
                                                          BoxShadow(
                                                            color: Color(0x24000000),
                                                            offset: Offset(0, 3),
                                                            blurRadius: 11.2962379456,
                                                          ),
                                                        ],
                                                      ),
                                                      child: SizedBox(
                                                        width: 173.4,
                                                        height: 78.7,
                                                        child: Container(
                                                          padding: EdgeInsets.fromLTRB(8.8, 11.5, 17, 36.4),
                                                          child: Stack(
                                                            clipBehavior: Clip.none,
                                                            children: [
                                                              SizedBox(
                                                                width: 147.7,
                                                                child: Row(
                                                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                                  children: [
                                                                    Container(
                                                                      margin: EdgeInsets.fromLTRB(0, 12.1, 0, 0),
                                                                      child: Row(
                                                                        mainAxisAlignment: MainAxisAlignment.start,
                                                                        crossAxisAlignment: CrossAxisAlignment.start,
                                                                        children: [
                                                                          Container(
                                                                            margin: EdgeInsets.fromLTRB(0, 7.7, 9, 0),
                                                                            child: Text(
                                                                              'BDO',
                                                                              style: GoogleFonts.getFont(
                                                                                'Poppins',
                                                                                fontWeight: FontWeight.w500,
                                                                                fontSize: 10.5,
                                                                                height: 1,
                                                                                color: Color(0xFF121212),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                          Container(
                                                                            margin: EdgeInsets.fromLTRB(0, 7, 5.9, 3.5),
                                                                            width: 9.3,
                                                                            height: 8.1,
                                                                            child: Container(
                                                                              width: 9.3,
                                                                              height: 8.1,
                                                                              child: SizedBox(
                                                                                width: 9.3,
                                                                                height: 8.1,
                                                                                child: SvgPicture.asset(
                                                                                  'assets/vectors/combined_shape_5_x2.svg',
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                          Container(
                                                                            margin: EdgeInsets.fromLTRB(0, 0, 0, 7.7),
                                                                            child: Text(
                                                                              'DPS',
                                                                              style: GoogleFonts.getFont(
                                                                                'Poppins',
                                                                                fontWeight: FontWeight.w500,
                                                                                fontSize: 10.5,
                                                                                height: 1,
                                                                                color: Color(0xFF121212),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ],
                                                                      ),
                                                                    ),
                                                                    Container(
                                                                      margin: EdgeInsets.fromLTRB(0, 0, 0, 22.4),
                                                                      width: 5.6,
                                                                      height: 8.4,
                                                                      child: Container(
                                                                        width: 5.6,
                                                                        height: 8.4,
                                                                        child: SizedBox(
                                                                          width: 5.6,
                                                                          height: 8.4,
                                                                          child: SvgPicture.asset(
                                                                            'assets/vectors/stroke_13_x2.svg',
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                              ),
                                                              Positioned(
                                                                left: 3.4,
                                                                bottom: -19,
                                                                child: SizedBox(
                                                                  width: 119.5,
                                                                  height: 28,
                                                                  child: Row(
                                                                    mainAxisAlignment: MainAxisAlignment.start,
                                                                    crossAxisAlignment: CrossAxisAlignment.start,
                                                                    children: [
                                                                      Container(
                                                                        margin: EdgeInsets.fromLTRB(0, 14, 5, 0),
                                                                        child: Text(
                                                                          '19 Des 22',
                                                                          style: GoogleFonts.getFont(
                                                                            'Poppins',
                                                                            fontWeight: FontWeight.w400,
                                                                            fontSize: 9,
                                                                            color: Color(0xFF808080),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                      Container(
                                                                        margin: EdgeInsets.fromLTRB(0, 17.6, 5, 6),
                                                                        child: Container(
                                                                          decoration: BoxDecoration(
                                                                            color: Color(0xFFD9D9D9),
                                                                            borderRadius: BorderRadius.circular(1.9),
                                                                          ),
                                                                          child: Container(
                                                                            width: 4.4,
                                                                            height: 4.4,
                                                                          ),
                                                                        ),
                                                                      ),
                                                                      Container(
                                                                        margin: EdgeInsets.fromLTRB(0, 10.6, 5.1, 5.9),
                                                                        child: Row(
                                                                          mainAxisAlignment: MainAxisAlignment.start,
                                                                          crossAxisAlignment: CrossAxisAlignment.start,
                                                                          children: [
                                                                            Container(
                                                                              margin: EdgeInsets.fromLTRB(0, 3, 1.4, 0),
                                                                              width: 7.2,
                                                                              height: 8.5,
                                                                              child: SizedBox(
                                                                                width: 7.2,
                                                                                height: 8.5,
                                                                                child: SvgPicture.asset(
                                                                                  'assets/vectors/vector_70_x2.svg',
                                                                                ),
                                                                              ),
                                                                            ),
                                                                            Container(
                                                                              margin: EdgeInsets.fromLTRB(0, 0, 0, 0.5),
                                                                              child: Text(
                                                                                '1',
                                                                                style: GoogleFonts.getFont(
                                                                                  'Roboto',
                                                                                  fontWeight: FontWeight.w400,
                                                                                  fontSize: 9,
                                                                                  color: Color(0xFF808080),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ],
                                                                        ),
                                                                      ),
                                                                      Container(
                                                                        margin: EdgeInsets.fromLTRB(0, 12.6, 2.9, 11),
                                                                        child: Container(
                                                                          decoration: BoxDecoration(
                                                                            color: Color(0xFFD9D9D9),
                                                                            borderRadius: BorderRadius.circular(1.9),
                                                                          ),
                                                                          child: Container(
                                                                            width: 4.4,
                                                                            height: 4.4,
                                                                          ),
                                                                        ),
                                                                      ),
                                                                      Container(
                                                                        margin: EdgeInsets.fromLTRB(0, 0, 0, 14),
                                                                        child: Text(
                                                                          'Ekonomi',
                                                                          style: GoogleFonts.getFont(
                                                                            'Poppins',
                                                                            fontWeight: FontWeight.w400,
                                                                            fontSize: 9,
                                                                            color: Color(0xFF808080),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ],
                                                                  ),
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Positioned(
                                                    left: 5.1,
                                                    bottom: 0,
                                                    child: Container(
                                                      decoration: BoxDecoration(
                                                        borderRadius: BorderRadius.circular(7.5),
                                                        color: Color(0xFFFFFFFF),
                                                        boxShadow: [
                                                          BoxShadow(
                                                            color: Color(0x24000000),
                                                            offset: Offset(0, 3),
                                                            blurRadius: 11.2962379456,
                                                          ),
                                                        ],
                                                      ),
                                                      child: SizedBox(
                                                        width: 173.4,
                                                        height: 78.7,
                                                        child: Container(
                                                          padding: EdgeInsets.fromLTRB(8.8, 11.5, 17, 36.4),
                                                          child: Stack(
                                                            clipBehavior: Clip.none,
                                                            children: [
                                                              SizedBox(
                                                                width: 147.7,
                                                                child: Row(
                                                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                                  children: [
                                                                    Container(
                                                                      margin: EdgeInsets.fromLTRB(0, 12.1, 0, 0),
                                                                      child: Row(
                                                                        mainAxisAlignment: MainAxisAlignment.start,
                                                                        crossAxisAlignment: CrossAxisAlignment.start,
                                                                        children: [
                                                                          Container(
                                                                            margin: EdgeInsets.fromLTRB(0, 7.7, 8.4, 0),
                                                                            child: Text(
                                                                              'CGK',
                                                                              style: GoogleFonts.getFont(
                                                                                'Poppins',
                                                                                fontWeight: FontWeight.w500,
                                                                                fontSize: 10.5,
                                                                                height: 1,
                                                                                color: Color(0xFF121212),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                          Container(
                                                                            margin: EdgeInsets.fromLTRB(0, 7, 5.9, 3.5),
                                                                            width: 9.3,
                                                                            height: 8.1,
                                                                            child: Container(
                                                                              width: 9.3,
                                                                              height: 8.1,
                                                                              child: SizedBox(
                                                                                width: 9.3,
                                                                                height: 8.1,
                                                                                child: SvgPicture.asset(
                                                                                  'assets/vectors/combined_shape_1_x2.svg',
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                          Container(
                                                                            margin: EdgeInsets.fromLTRB(0, 0, 0, 7.7),
                                                                            child: Text(
                                                                              'DPS',
                                                                              style: GoogleFonts.getFont(
                                                                                'Poppins',
                                                                                fontWeight: FontWeight.w500,
                                                                                fontSize: 10.5,
                                                                                height: 1,
                                                                                color: Color(0xFF121212),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ],
                                                                      ),
                                                                    ),
                                                                    Container(
                                                                      margin: EdgeInsets.fromLTRB(0, 0, 0, 22.4),
                                                                      width: 5.6,
                                                                      height: 8.4,
                                                                      child: Container(
                                                                        width: 5.6,
                                                                        height: 8.4,
                                                                        child: SizedBox(
                                                                          width: 5.6,
                                                                          height: 8.4,
                                                                          child: SvgPicture.asset(
                                                                            'assets/vectors/stroke_11_x2.svg',
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                              ),
                                                              Positioned(
                                                                left: 3.4,
                                                                bottom: -19,
                                                                child: SizedBox(
                                                                  width: 118.9,
                                                                  height: 26.3,
                                                                  child: Row(
                                                                    mainAxisAlignment: MainAxisAlignment.start,
                                                                    crossAxisAlignment: CrossAxisAlignment.start,
                                                                    children: [
                                                                      Container(
                                                                        margin: EdgeInsets.fromLTRB(0, 12.3, 5.3, 0),
                                                                        child: Text(
                                                                          '17 Nov 22',
                                                                          style: GoogleFonts.getFont(
                                                                            'Poppins',
                                                                            fontWeight: FontWeight.w400,
                                                                            fontSize: 9,
                                                                            color: Color(0xFF808080),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                      Container(
                                                                        margin: EdgeInsets.fromLTRB(0, 15.9, 5, 6),
                                                                        child: Container(
                                                                          decoration: BoxDecoration(
                                                                            color: Color(0xFFD9D9D9),
                                                                            borderRadius: BorderRadius.circular(1.9),
                                                                          ),
                                                                          child: Container(
                                                                            width: 4.4,
                                                                            height: 4.4,
                                                                          ),
                                                                        ),
                                                                      ),
                                                                      Container(
                                                                        margin: EdgeInsets.fromLTRB(0, 8.9, 5.1, 5.9),
                                                                        child: Row(
                                                                          mainAxisAlignment: MainAxisAlignment.start,
                                                                          crossAxisAlignment: CrossAxisAlignment.start,
                                                                          children: [
                                                                            Container(
                                                                              margin: EdgeInsets.fromLTRB(0, 3, 1.4, 0),
                                                                              width: 7.2,
                                                                              height: 8.5,
                                                                              child: SizedBox(
                                                                                width: 7.2,
                                                                                height: 8.5,
                                                                                child: SvgPicture.asset(
                                                                                  'assets/vectors/vector_74_x2.svg',
                                                                                ),
                                                                              ),
                                                                            ),
                                                                            Container(
                                                                              margin: EdgeInsets.fromLTRB(0, 0, 0, 0.5),
                                                                              child: Text(
                                                                                '1',
                                                                                style: GoogleFonts.getFont(
                                                                                  'Roboto',
                                                                                  fontWeight: FontWeight.w400,
                                                                                  fontSize: 9,
                                                                                  color: Color(0xFF808080),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ],
                                                                        ),
                                                                      ),
                                                                      Container(
                                                                        margin: EdgeInsets.fromLTRB(0, 10.9, 3.2, 11),
                                                                        child: Container(
                                                                          decoration: BoxDecoration(
                                                                            color: Color(0xFFD9D9D9),
                                                                            borderRadius: BorderRadius.circular(1.9),
                                                                          ),
                                                                          child: Container(
                                                                            width: 4.4,
                                                                            height: 4.4,
                                                                          ),
                                                                        ),
                                                                      ),
                                                                      Container(
                                                                        margin: EdgeInsets.fromLTRB(0, 0, 0, 15.3),
                                                                        child: Text(
                                                                          'Economy',
                                                                          style: GoogleFonts.getFont(
                                                                            'Roboto',
                                                                            fontWeight: FontWeight.w400,
                                                                            fontSize: 9,
                                                                            color: Color(0xFF808080),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ],
                                                                  ),
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                        Positioned(
                                          left: 117.4,
                                          bottom: -71.2,
                                          child: Container(
                                            decoration: BoxDecoration(
                                              borderRadius: BorderRadius.circular(7.5),
                                              color: Color(0xFFFFFFFF),
                                              boxShadow: [
                                                BoxShadow(
                                                  color: Color(0x26000000),
                                                  offset: Offset(0, 3),
                                                  blurRadius: 7.5308256149,
                                                ),
                                              ],
                                            ),
                                            child: Stack(
                                              children: [
                                              Positioned(
                                                top: -11.1,
                                                child: Container(
                                                  decoration: BoxDecoration(
                                                    gradient: LinearGradient(
                                                      begin: Alignment(0, -1),
                                                      end: Alignment(0, 1),
                                                      colors: <Color>[Color(0xFF000000), Color(0xFF000000)],
                                                      stops: <double>[0, 1],
                                                    ),
                                                  ),
                                                  child: SizedBox(
                                                    width: 139.5,
                                                    height: 138.8,
                                                    child: Container(
                                                      padding: EdgeInsets.fromLTRB(0, 0, 6.1, 0),
                                                      child: Stack(
                                                        clipBehavior: Clip.none,
                                                        children: [
                                                          Container(
                                                            decoration: BoxDecoration(
                                                              image: DecorationImage(
                                                                fit: BoxFit.cover,
                                                                image: AssetImage(
                                                                  'assets/images/image_15.png',
                                                                ),
                                                              ),
                                                            ),
                                                            child: Container(
                                                              width: 133.4,
                                                              height: 100.4,
                                                            ),
                                                          ),
                                                          Positioned(
                                                            bottom: 0,
                                                            child: Container(
                                                              decoration: BoxDecoration(
                                                                gradient: LinearGradient(
                                                                  begin: Alignment(0, 0.088),
                                                                  end: Alignment(0, 1),
                                                                  colors: <Color>[Color(0x00000000), Color(0xFF000000)],
                                                                  stops: <double>[0, 1],
                                                                ),
                                                              ),
                                                              child: Container(
                                                                width: 139.5,
                                                                height: 138.8,
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                        SizedBox(
                                                  height: 138.8,
                                                  child: Container(
                                                    padding: EdgeInsets.fromLTRB(0.1, 11.1, 16.1, 0),
                                                    child: Stack(
                                                      clipBehavior: Clip.none,
                                                      children: [
                                                        Column(
                                                          mainAxisAlignment: MainAxisAlignment.start,
                                                          crossAxisAlignment: CrossAxisAlignment.center,
                                                          children: [
                                                            Container(
                                                              margin: EdgeInsets.fromLTRB(0, 0, 0, 26.1),
                                                              child: Row(
                                                                mainAxisAlignment: MainAxisAlignment.start,
                                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                                children: [
                                                                  Container(
                                                                    margin: EdgeInsets.fromLTRB(0, 1.5, 15, 0),
                                                                    child: Container(
                                                                      decoration: BoxDecoration(
                                                                        image: DecorationImage(
                                                                          fit: BoxFit.cover,
                                                                          image: AssetImage(
                                                                            'assets/images/air_asia_1.png',
                                                                          ),
                                                                        ),
                                                                      ),
                                                                      child: Container(
                                                                        width: 57.3,
                                                                        height: 43.9,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  Container(
                                                                    margin: EdgeInsets.fromLTRB(0, 0, 0, 21.6),
                                                                    child: Container(
                                                                      decoration: BoxDecoration(
                                                                        color: Color(0xFF7060E5),
                                                                        borderRadius: BorderRadius.only(
                                                                          topLeft: Radius.circular(4.5),
                                                                          bottomLeft: Radius.circular(4.5),
                                                                        ),
                                                                      ),
                                                                      child: Container(
                                                                        padding: EdgeInsets.fromLTRB(4.6, 1.5, 7, 8.3),
                                                                        child: Text(
                                                                          'IDR 500k',
                                                                          style: GoogleFonts.getFont(
                                                                            'Poppins',
                                                                            fontWeight: FontWeight.w500,
                                                                            fontSize: 9,
                                                                            color: Color(0xFFFFFFFF),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                            Container(
                                                              margin: EdgeInsets.fromLTRB(19.7, 0, 17.5, 4.1),
                                                              child: Container(
                                                                padding: EdgeInsets.fromLTRB(0, 0, 0, 6.2),
                                                                child: Stack(
                                                                  clipBehavior: Clip.none,
                                                                  children: [
                                                                    Text(
                                                                      'Bandung',
                                                                      style: GoogleFonts.getFont(
                                                                        'Poppins',
                                                                        fontWeight: FontWeight.w600,
                                                                        fontSize: 9,
                                                                        color: Color(0xFFFFFFFF),
                                                                      ),
                                                                    ),
                                                                    Positioned(
                                                                      right: 0,
                                                                      bottom: 0,
                                                                      child: SizedBox(
                                                                        height: 14,
                                                                        child: Text(
                                                                          'Bali/Denpasar',
                                                                          style: GoogleFonts.getFont(
                                                                            'Poppins',
                                                                            fontWeight: FontWeight.w600,
                                                                            fontSize: 9,
                                                                            color: Color(0xFFFFFFFF),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                              ),
                                                            ),
                                                            Container(
                                                              margin: EdgeInsets.fromLTRB(0, 0, 8.4, 0),
                                                              child: Text(
                                                                '9 - 18 Januari 2023',
                                                                style: GoogleFonts.getFont(
                                                                  'Poppins',
                                                                  fontWeight: FontWeight.w300,
                                                                  fontSize: 7.5,
                                                                  color: Color(0xFFFFFFFF),
                                                                ),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                        Positioned(
                                                          left: 24.4,
                                                          bottom: 24.6,
                                                          child: Container(
                                                            width: 9.7,
                                                            height: 10.4,
                                                            child: SizedBox(
                                                              width: 9.7,
                                                              height: 10.4,
                                                              child: SvgPicture.asset(
                                                                'assets/vectors/swap_x2.svg',
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                        Positioned(
                                          right: 12.2,
                                          bottom: -48.2,
                                          child: Container(
                                            decoration: BoxDecoration(
                                              borderRadius: BorderRadius.circular(7.5),
                                              color: Color(0xFFFFFFFF),
                                              boxShadow: [
                                                BoxShadow(
                                                  color: Color(0x26000000),
                                                  offset: Offset(0, 3),
                                                  blurRadius: 7.5308256149,
                                                ),
                                              ],
                                            ),
                                            child: Stack(
                                              children: [
                                              Positioned(
                                                right: -87.5,
                                                top: -23.7,
                                                child: Container(
                                                  decoration: BoxDecoration(
                                                    image: DecorationImage(
                                                      fit: BoxFit.cover,
                                                      image: AssetImage(
                                                        'assets/images/image_12.png',
                                                      ),
                                                    ),
                                                  ),
                                                  child: Container(
                                                    width: 210.7,
                                                    height: 151.4,
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                top: -11.2,
                                                child: Container(
                                                  decoration: BoxDecoration(
                                                    gradient: LinearGradient(
                                                      begin: Alignment(0, 0.088),
                                                      end: Alignment(0, 1),
                                                      colors: <Color>[Color(0x00000000), Color(0xFF000000)],
                                                      stops: <double>[0, 1],
                                                    ),
                                                  ),
                                                  child: Container(
                                                    width: 139.5,
                                                    height: 138.8,
                                                  ),
                                                ),
                                              ),
                                        SizedBox(
                                                  height: 138.8,
                                                  child: Container(
                                                    padding: EdgeInsets.fromLTRB(7.2, 11.2, 16.3, 0),
                                                    child: Stack(
                                                      clipBehavior: Clip.none,
                                                      children: [
                                                        Column(
                                                          mainAxisAlignment: MainAxisAlignment.start,
                                                          crossAxisAlignment: CrossAxisAlignment.start,
                                                          children: [
                                                            Container(
                                                              margin: EdgeInsets.fromLTRB(0, 0, 0, 38.1),
                                                              child: Row(
                                                                mainAxisAlignment: MainAxisAlignment.start,
                                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                                children: [
                                                                  Container(
                                                                    margin: EdgeInsets.fromLTRB(0, 13.4, 26.5, 0),
                                                                    width: 39.5,
                                                                    height: 20.3,
                                                                    child: Container(
                                                                      decoration: BoxDecoration(
                                                                        image: DecorationImage(
                                                                          image: AssetImage(
                                                                            'assets/images/logo_citilink_by_kampungdesigner_1.png',
                                                                          ),
                                                                        ),
                                                                      ),
                                                                      child: Container(
                                                                        width: 39.5,
                                                                        height: 20.3,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  Container(
                                                                    margin: EdgeInsets.fromLTRB(0, 0, 0, 10.1),
                                                                    child: Container(
                                                                      decoration: BoxDecoration(
                                                                        color: Color(0xFF7060E5),
                                                                        borderRadius: BorderRadius.only(
                                                                          topLeft: Radius.circular(4.5),
                                                                          bottomLeft: Radius.circular(4.5),
                                                                        ),
                                                                      ),
                                                                      child: Container(
                                                                        padding: EdgeInsets.fromLTRB(4.6, 1.5, 6.7, 8.1),
                                                                        child: Text(
                                                                          'IDR 760k',
                                                                          style: GoogleFonts.getFont(
                                                                            'Poppins',
                                                                            fontWeight: FontWeight.w500,
                                                                            fontSize: 9,
                                                                            color: Color(0xFFFFFFFF),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                            Container(
                                                              margin: EdgeInsets.fromLTRB(17.1, 0, 17.1, 0.4),
                                                              child: Align(
                                                                alignment: Alignment.topLeft,
                                                                child: Container(
                                                                  padding: EdgeInsets.fromLTRB(0, 0, 0, 8.3),
                                                                  child: Stack(
                                                                    clipBehavior: Clip.none,
                                                                    children: [
                                                                      Text(
                                                                        'Jakarta',
                                                                        style: GoogleFonts.getFont(
                                                                          'Poppins',
                                                                          fontWeight: FontWeight.w600,
                                                                          fontSize: 9,
                                                                          color: Color(0xFFFFFFFF),
                                                                        ),
                                                                      ),
                                                                      Positioned(
                                                                        right: 0,
                                                                        bottom: 0,
                                                                        child: SizedBox(
                                                                          height: 14,
                                                                          child: Text(
                                                                            'Singapore',
                                                                            style: GoogleFonts.getFont(
                                                                              'Poppins',
                                                                              fontWeight: FontWeight.w600,
                                                                              fontSize: 9,
                                                                              color: Color(0xFFFFFFFF),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ],
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                            Container(
                                                              margin: EdgeInsets.fromLTRB(0, 0, 4, 0),
                                                              child: Align(
                                                                alignment: Alignment.topCenter,
                                                                child: Text(
                                                                  '4 - 15 Februari 2023',
                                                                  style: GoogleFonts.getFont(
                                                                    'Poppins',
                                                                    fontWeight: FontWeight.w300,
                                                                    fontSize: 7.5,
                                                                    color: Color(0xFFFFFFFF),
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                        Positioned(
                                                          left: 21.8,
                                                          bottom: 25.3,
                                                          child: Container(
                                                            width: 9.7,
                                                            height: 10.4,
                                                            child: SizedBox(
                                                              width: 9.7,
                                                              height: 10.4,
                                                              child: SvgPicture.asset(
                                                                'assets/vectors/swap_1_x2.svg',
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                        Positioned(
                                          right: -118.3,
                                          bottom: -25.2,
                                          child: Container(
                                            decoration: BoxDecoration(
                                              borderRadius: BorderRadius.circular(7.5),
                                              image: DecorationImage(
                                                image: AssetImage(
                                                  'assets/images/image_13.png',
                                                ),
                                              ),
                                            ),
                                            child: Stack(
                                              children: [
                                              Positioned(
                                                left: -9.6,
                                                right: -16.2,
                                                top: -11.1,
                                                bottom: 0,
                                                child: Container(
                                                  decoration: BoxDecoration(
                                                    gradient: LinearGradient(
                                                      begin: Alignment(0, 0.088),
                                                      end: Alignment(0, 1),
                                                      colors: <Color>[Color(0x00000000), Color(0xFF000000)],
                                                      stops: <double>[0, 1],
                                                    ),
                                                  ),
                                                  child: Container(
                                                    width: 139.5,
                                                    height: 138.8,
                                                  ),
                                                ),
                                              ),
                                        SizedBox(
                                                  height: 138.8,
                                                  child: Container(
                                                    padding: EdgeInsets.fromLTRB(9.6, 11.1, 16.2, 0),
                                                    child: Stack(
                                                      clipBehavior: Clip.none,
                                                      children: [
                                                        Column(
                                                          mainAxisAlignment: MainAxisAlignment.start,
                                                          crossAxisAlignment: CrossAxisAlignment.start,
                                                          children: [
                                                            Container(
                                                              margin: EdgeInsets.fromLTRB(0, 0, 0, 38.9),
                                                              child: Row(
                                                                mainAxisAlignment: MainAxisAlignment.start,
                                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                                children: [
                                                                  Container(
                                                                    margin: EdgeInsets.fromLTRB(0, 13.4, 28.1, 0),
                                                                    child: Container(
                                                                      decoration: BoxDecoration(
                                                                        image: DecorationImage(
                                                                          fit: BoxFit.cover,
                                                                          image: AssetImage(
                                                                            'assets/images/logo_batik_air_1.png',
                                                                          ),
                                                                        ),
                                                                      ),
                                                                      child: Container(
                                                                        width: 45.8,
                                                                        height: 19.6,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  Container(
                                                                    margin: EdgeInsets.fromLTRB(0, 0, 0, 11.6),
                                                                    child: Container(
                                                                      decoration: BoxDecoration(
                                                                        color: Color(0xFF7060E5),
                                                                        borderRadius: BorderRadius.only(
                                                                          topLeft: Radius.circular(4.5),
                                                                          bottomLeft: Radius.circular(4.5),
                                                                        ),
                                                                      ),
                                                                      child: Container(
                                                                        padding: EdgeInsets.fromLTRB(4.6, 1.6, 7.3, 5.7),
                                                                        child: Text(
                                                                          'IDR 7jt',
                                                                          style: GoogleFonts.getFont(
                                                                            'Poppins',
                                                                            fontWeight: FontWeight.w500,
                                                                            fontSize: 9,
                                                                            color: Color(0xFFFFFFFF),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                            Container(
                                                              margin: EdgeInsets.fromLTRB(14.7, 0, 14.7, 9.9),
                                                              child: Align(
                                                                alignment: Alignment.topLeft,
                                                                child: Container(
                                                                  child: Text(
                                                                    'Jakarta',
                                                                    style: GoogleFonts.getFont(
                                                                      'Poppins',
                                                                      fontWeight: FontWeight.w600,
                                                                      fontSize: 9,
                                                                      color: Color(0xFFFFFFFF),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                            Container(
                                                              margin: EdgeInsets.fromLTRB(19.8, 0, 19.8, 0),
                                                              child: Align(
                                                                alignment: Alignment.topLeft,
                                                                child: Text(
                                                                  '3 - 20 Maret 2023',
                                                                  style: GoogleFonts.getFont(
                                                                    'Poppins',
                                                                    fontWeight: FontWeight.w300,
                                                                    fontSize: 7.5,
                                                                    color: Color(0xFFFFFFFF),
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                        Positioned(
                                                          left: 34.1,
                                                          bottom: 30.1,
                                                          child: SizedBox(
                                                            height: 14,
                                                            child: Text(
                                                              'Tokyo',
                                                              style: GoogleFonts.getFont(
                                                                'Poppins',
                                                                fontWeight: FontWeight.w600,
                                                                fontSize: 9,
                                                                color: Color(0xFFFFFFFF),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                        Positioned(
                                                          left: 19.4,
                                                          bottom: 24.6,
                                                          child: Container(
                                                            width: 9.7,
                                                            height: 10.4,
                                                            child: SizedBox(
                                                              width: 9.7,
                                                              height: 10.4,
                                                              child: SvgPicture.asset(
                                                                'assets/vectors/swap_10_x2.svg',
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 0, 0, 16.5),
                            child: Transform(
                              transform: Matrix4.identity()..rotationZ(0.1745330593),
                              child: Container(
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(15.1),
                                  color: Color(0xFFFFFFFF),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Color(0x33000000),
                                      offset: Offset(0, 30.1),
                                      blurRadius: 18.8270626068,
                                    ),
                                    BoxShadow(
                                      color: Color(0x33000000),
                                      offset: Offset(0, -30.1),
                                      blurRadius: 15.0616512299,
                                    ),
                                  ],
                                ),
                                child: SizedBox(
                                  width: 399.6,
                                  height: 676.9,
                                  child: Stack(
                                    children: [
                                      Container(
                                        decoration: BoxDecoration(
                                          color: Color(0xFF7060E5),
                                          borderRadius: BorderRadius.circular(15.1),
                                        ),
                                        child: SizedBox(
                                          height: 218.6,
                                          child: Container(
                                            padding: EdgeInsets.fromLTRB(17.2, 13, 17.2, 0),
                                            child: Stack(
                                              clipBehavior: Clip.none,
                                              children: [
                                                Positioned(
                                                  left: -25.5,
                                                  top: -65.5,
                                                  child: Container(
                                                    decoration: BoxDecoration(
                                                      color: Color(0xFF7868EC),
                                                      borderRadius: BorderRadius.circular(62.9),
                                                    ),
                                                    child: Container(
                                                      width: 145.7,
                                                      height: 145.7,
                                                    ),
                                                  ),
                                                ),
                                                Positioned(
                                                  left: -41.1,
                                                  top: -65.1,
                                                  child: Container(
                                                    decoration: BoxDecoration(
                                                      color: Color(0xFF7F6FF2),
                                                      borderRadius: BorderRadius.circular(52.7),
                                                    ),
                                                    child: Container(
                                                      width: 122.1,
                                                      height: 122.1,
                                                      padding: EdgeInsets.fromLTRB(8, 10.4, 8, 0),
                                                      child: Container(
                                                        decoration: BoxDecoration(
                                                          color: Color(0xFF8778F8),
                                                          borderRadius: BorderRadius.circular(37.7),
                                                        ),
                                                        child: Container(
                                                          width: 87.2,
                                                          height: 87.2,
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Column(
                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                  crossAxisAlignment: CrossAxisAlignment.end,
                                                  children: [
                                                    Container(
                                                      margin: EdgeInsets.fromLTRB(0, 0, 0, 17.2),
                                                      child: Row(
                                                        mainAxisAlignment: MainAxisAlignment.start,
                                                        crossAxisAlignment: CrossAxisAlignment.start,
                                                        children: [
                                                          Container(
                                                            margin: EdgeInsets.fromLTRB(0, 41.6, 0.2, 4.6),
                                                            width: 14,
                                                            height: 12.2,
                                                            child: Container(
                                                              width: 14,
                                                              height: 12.2,
                                                              child: SizedBox(
                                                                width: 14,
                                                                height: 12.2,
                                                                child: SvgPicture.asset(
                                                                  'assets/vectors/combined_shape_3_x2.svg',
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                          Column(
                                                            mainAxisAlignment: MainAxisAlignment.start,
                                                            crossAxisAlignment: CrossAxisAlignment.start,
                                                            children: [
                                                              Container(
                                                                margin: EdgeInsets.fromLTRB(0, 0, 0, 17.7),
                                                                child: Align(
                                                                  alignment: Alignment.topLeft,
                                                                  child: Container(
                                                                    child: Text(
                                                                      '9:41',
                                                                      style: GoogleFonts.getFont(
                                                                        'Roboto Condensed',
                                                                        fontWeight: FontWeight.w400,
                                                                        fontSize: 12.8,
                                                                        height: 1.3,
                                                                        color: Color(0xFFEEEEEE),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                              Container(
                                                                margin: EdgeInsets.fromLTRB(16.8, 0, 0, 0),
                                                                child: SizedBox(
                                                                  width: 234.5,
                                                                  child: Row(
                                                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                                    crossAxisAlignment: CrossAxisAlignment.start,
                                                                    children: [
                                                                      Container(
                                                                        margin: EdgeInsets.fromLTRB(0, 0, 8.5, 6.8),
                                                                        child: SizedBox(
                                                                          width: 185.3,
                                                                          child: Text(
                                                                            'Bandung to Denpasar',
                                                                            style: GoogleFonts.getFont(
                                                                              'Poppins',
                                                                              fontWeight: FontWeight.w500,
                                                                              fontSize: 13.6,
                                                                              height: 1.2,
                                                                              color: Color(0xFFFFFFFF),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                      Container(
                                                                        margin: EdgeInsets.fromLTRB(0, 7.7, 0, 0),
                                                                        child: SizedBox(
                                                                          width: 40.7,
                                                                          child: Row(
                                                                            mainAxisAlignment: MainAxisAlignment.start,
                                                                            crossAxisAlignment: CrossAxisAlignment.start,
                                                                            children: [
                                                                              Container(
                                                                                margin: EdgeInsets.fromLTRB(0, 0, 4, 4.9),
                                                                                child: SizedBox(
                                                                                  width: 14.2,
                                                                                  height: 11.2,
                                                                                  child: SvgPicture.asset(
                                                                                    'assets/vectors/wifi_4_x2.svg',
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                              Container(
                                                                                margin: EdgeInsets.fromLTRB(0, 2.8, 0, 0),
                                                                                child: SizedBox(
                                                                                  width: 22.5,
                                                                                  height: 13.3,
                                                                                  child: SvgPicture.asset(
                                                                                    'assets/vectors/battery_6_x2.svg',
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                            ],
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ],
                                                                  ),
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    Container(
                                                      margin: EdgeInsets.fromLTRB(6, 0, 6, 10.1),
                                                      child: Container(
                                                        decoration: BoxDecoration(
                                                          color: Color(0x33FFFFFF),
                                                          borderRadius: BorderRadius.circular(7.5),
                                                        ),
                                                        child: Container(
                                                          padding: EdgeInsets.fromLTRB(7.9, 4.3, 11.5, 9.5),
                                                          child: Text(
                                                            'Change',
                                                            style: GoogleFonts.getFont(
                                                              'Poppins',
                                                              fontWeight: FontWeight.w500,
                                                              fontSize: 7.5,
                                                              letterSpacing: 0,
                                                              color: Color(0xFFFFFFFF),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      margin: EdgeInsets.fromLTRB(75.7, 0, 0, 0),
                                                      child: Align(
                                                        alignment: Alignment.topCenter,
                                                        child: Row(
                                                          mainAxisAlignment: MainAxisAlignment.start,
                                                          crossAxisAlignment: CrossAxisAlignment.start,
                                                          children: [
                                                            Container(
                                                              margin: EdgeInsets.fromLTRB(0, 44.6, 36.4, 0),
                                                              width: 17.4,
                                                              height: 17.4,
                                                              child: SizedBox(
                                                                width: 17.4,
                                                                height: 17.4,
                                                                child: SvgPicture.asset(
                                                                  'assets/vectors/vector_21_x2.svg',
                                                                ),
                                                              ),
                                                            ),
                                                            Container(
                                                              margin: EdgeInsets.fromLTRB(0, 0, 0, 4.5),
                                                              child: Container(
                                                                decoration: BoxDecoration(
                                                                  color: Color(0x33FFFFFF),
                                                                  borderRadius: BorderRadius.circular(7.5),
                                                                ),
                                                                child: Container(
                                                                  padding: EdgeInsets.fromLTRB(9.2, 11.7, 10.9, 22.9),
                                                                  child: RichText(
                                                                    textAlign: TextAlign.center,
                                                                    text: TextSpan(
                                                                      style: GoogleFonts.getFont(
                                                                        'Roboto',
                                                                        fontWeight: FontWeight.w400,
                                                                        fontSize: 10.5,
                                                                        color: Color(0xFF6D6D6D),
                                                                      ),
                                                                      children: [
                                                                        TextSpan(
                                                                          text: 'Mon, 10 Jan
                                                                  ',
                                                                          style: GoogleFonts.getFont(
                                                                            'Roboto',
                                                                            fontWeight: FontWeight.w600,
                                                                            fontSize: 10.5,
                                                                            height: 1.3,
                                                                            color: Color(0xFFFFFFFF),
                                                                          ),
                                                                        ),
                                                                        TextSpan(
                                                                          text: 'Rp. 935.000',
                                                                          style: GoogleFonts.getFont(
                                                                            'Roboto',
                                                                            fontWeight: FontWeight.w400,
                                                                            fontSize: 9,
                                                                            height: 1.3,
                                                                            color: Color(0xFFFFFFFF),
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                                Positioned(
                                                  left: 46.8,
                                                  top: 55.4,
                                                  child: SizedBox(
                                                    width: 148.5,
                                                    height: 32,
                                                    child: Row(
                                                      mainAxisAlignment: MainAxisAlignment.start,
                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                      children: [
                                                        Container(
                                                          margin: EdgeInsets.fromLTRB(0, 0, 7.4, 18),
                                                          child: Text(
                                                            'Sun, 9 Jan 23 ',
                                                            style: GoogleFonts.getFont(
                                                              'Poppins',
                                                              fontWeight: FontWeight.w400,
                                                              fontSize: 9,
                                                              color: Color(0xFFFFFFFF),
                                                            ),
                                                          ),
                                                        ),
                                                        Container(
                                                          margin: EdgeInsets.fromLTRB(0, 16.6, 7.9, 11.1),
                                                          child: Container(
                                                            decoration: BoxDecoration(
                                                              color: Color(0xFFFFFFFF),
                                                              borderRadius: BorderRadius.circular(1.9),
                                                            ),
                                                            child: Container(
                                                              width: 4.4,
                                                              height: 4.4,
                                                            ),
                                                          ),
                                                        ),
                                                        Container(
                                                          margin: EdgeInsets.fromLTRB(0, 17, 8.2, 4),
                                                          child: Row(
                                                            mainAxisAlignment: MainAxisAlignment.start,
                                                            crossAxisAlignment: CrossAxisAlignment.start,
                                                            children: [
                                                              Container(
                                                                margin: EdgeInsets.fromLTRB(0, 0, 1.3, 2.6),
                                                                width: 7.2,
                                                                height: 8.5,
                                                                child: SizedBox(
                                                                  width: 7.2,
                                                                  height: 8.5,
                                                                  child: SvgPicture.asset(
                                                                    'assets/vectors/vector_78_x2.svg',
                                                                  ),
                                                                ),
                                                              ),
                                                              Container(
                                                                margin: EdgeInsets.fromLTRB(0, 0.1, 0, 0),
                                                                child: Text(
                                                                  '1',
                                                                  style: GoogleFonts.getFont(
                                                                    'Roboto',
                                                                    fontWeight: FontWeight.w400,
                                                                    fontSize: 9,
                                                                    color: Color(0xFFFFFFFF),
                                                                  ),
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                        Container(
                                                          margin: EdgeInsets.fromLTRB(0, 22.6, 6.1, 5),
                                                          child: Container(
                                                            decoration: BoxDecoration(
                                                              color: Color(0xFFFFFFFF),
                                                              borderRadius: BorderRadius.circular(1.9),
                                                            ),
                                                            child: Container(
                                                              width: 4.4,
                                                              height: 4.4,
                                                            ),
                                                          ),
                                                        ),
                                                        Container(
                                                          margin: EdgeInsets.fromLTRB(0, 21, 0, 0),
                                                          child: Text(
                                                            'Economy',
                                                            style: GoogleFonts.getFont(
                                                              'Roboto',
                                                              fontWeight: FontWeight.w400,
                                                              fontSize: 9,
                                                              color: Color(0xFFFFFFFF),
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ),
                                                Positioned(
                                                  left: 96.1,
                                                  bottom: 51.6,
                                                  child: Container(
                                                    decoration: BoxDecoration(
                                                      color: Color(0xFFFFFFFF),
                                                      borderRadius: BorderRadius.circular(7.5),
                                                    ),
                                                    child: Container(
                                                      height: 57.6,
                                                      padding: EdgeInsets.fromLTRB(13.5, 12.5, 15.2, 0),
                                                      child: RichText(
                                                        textAlign: TextAlign.center,
                                                        text: TextSpan(
                                                          style: GoogleFonts.getFont(
                                                            'Roboto',
                                                            fontWeight: FontWeight.w400,
                                                            fontSize: 10.5,
                                                            color: Color(0xFF7060E5),
                                                          ),
                                                          children: [
                                                            TextSpan(
                                                              text: 'Sun, 9 Jan
                                                      ',
                                                              style: GoogleFonts.getFont(
                                                                'Roboto',
                                                                fontWeight: FontWeight.w600,
                                                                fontSize: 10.5,
                                                                height: 1.3,
                                                                color: Color(0xFF7060E5),
                                                              ),
                                                            ),
                                                            TextSpan(
                                                              text: 'Rp. 955.000',
                                                              style: GoogleFonts.getFont(
                                                                'Roboto',
                                                                fontWeight: FontWeight.w400,
                                                                fontSize: 9,
                                                                height: 1.3,
                                                                color: Color(0xFF7060E5),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Positioned(
                                                  left: 16.7,
                                                  bottom: 65.6,
                                                  child: Container(
                                                    decoration: BoxDecoration(
                                                      color: Color(0x33FFFFFF),
                                                      borderRadius: BorderRadius.circular(7.5),
                                                    ),
                                                    child: Container(
                                                      height: 57.6,
                                                      padding: EdgeInsets.fromLTRB(12.2, 12, 14, 0),
                                                      child: RichText(
                                                        textAlign: TextAlign.center,
                                                        text: TextSpan(
                                                          style: GoogleFonts.getFont(
                                                            'Roboto',
                                                            fontWeight: FontWeight.w400,
                                                            fontSize: 10.5,
                                                            color: Color(0xFF6D6D6D),
                                                          ),
                                                          children: [
                                                            TextSpan(
                                                              text: 'Sat, 8 Jan
                                                      ',
                                                              style: GoogleFonts.getFont(
                                                                'Roboto',
                                                                fontWeight: FontWeight.w600,
                                                                fontSize: 10.5,
                                                                height: 1.3,
                                                                color: Color(0xFFFFFFFF),
                                                              ),
                                                            ),
                                                            TextSpan(
                                                              text: 'Rp. 1.040.000',
                                                              style: GoogleFonts.getFont(
                                                                'Roboto',
                                                                fontWeight: FontWeight.w400,
                                                                fontSize: 9,
                                                                height: 1.3,
                                                                color: Color(0xFFFFFFFF),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        right: -61.1,
                                        top: 181.3,
                                        child: Container(
                                          decoration: BoxDecoration(
                                            color: Color(0xFFE8E8E8),
                                            borderRadius: BorderRadius.circular(7.5),
                                          ),
                                          child: SizedBox(
                                            width: 80.1,
                                            height: 42.9,
                                            child: Container(
                                              padding: EdgeInsets.fromLTRB(13.2, 9.7, 15.3, 14.3),
                                              child: Row(
                                                mainAxisAlignment: MainAxisAlignment.start,
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    margin: EdgeInsets.fromLTRB(0, 0, 6.9, 2),
                                                    width: 15.9,
                                                    height: 16.9,
                                                    child: SizedBox(
                                                      width: 15.9,
                                                      height: 16.9,
                                                      child: SvgPicture.asset(
                                                        'assets/vectors/vector_48_x2.svg',
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    margin: EdgeInsets.fromLTRB(0, 3.9, 0, 0),
                                                    child: Text(
                                                      'Flight',
                                                      style: GoogleFonts.getFont(
                                                        'Poppins',
                                                        fontWeight: FontWeight.w500,
                                                        fontSize: 10.5,
                                                        height: 1.4,
                                                        letterSpacing: 0.2,
                                                        color: Color(0xFF121212),
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        right: -34.5,
                                        top: 137.3,
                                        child: Container(
                                          decoration: BoxDecoration(
                                            color: Color(0x33FFFFFF),
                                            borderRadius: BorderRadius.circular(7.5),
                                          ),
                                          child: Container(
                                            height: 57.6,
                                            padding: EdgeInsets.fromLTRB(10.8, 12, 12.6, 0),
                                            child: RichText(
                                              textAlign: TextAlign.center,
                                              text: TextSpan(
                                                style: GoogleFonts.getFont(
                                                  'Roboto',
                                                  fontWeight: FontWeight.w400,
                                                  fontSize: 10.5,
                                                  color: Color(0xFF6D6D6D),
                                                ),
                                                children: [
                                                  TextSpan(
                                                    text: 'Tue, 11 Jan
                                            ',
                                                    style: GoogleFonts.getFont(
                                                      'Roboto',
                                                      fontWeight: FontWeight.w600,
                                                      fontSize: 10.5,
                                                      height: 1.3,
                                                      color: Color(0xFFFFFFFF),
                                                    ),
                                                  ),
                                                  TextSpan(
                                                    text: 'Rp. 1.004.000',
                                                    style: GoogleFonts.getFont(
                                                      'Roboto',
                                                      fontWeight: FontWeight.w400,
                                                      fontSize: 9,
                                                      height: 1.3,
                                                      color: Color(0xFFFFFFFF),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        left: 34.7,
                                        top: 81.3,
                                        child: Container(
                                          decoration: BoxDecoration(
                                            color: Color(0x33FFFFFF),
                                            borderRadius: BorderRadius.circular(7.5),
                                          ),
                                          child: Container(
                                            height: 57.6,
                                            padding: EdgeInsets.fromLTRB(12.2, 12, 14, 0),
                                            child: RichText(
                                              textAlign: TextAlign.center,
                                              text: TextSpan(
                                                style: GoogleFonts.getFont(
                                                  'Roboto',
                                                  fontWeight: FontWeight.w400,
                                                  fontSize: 10.5,
                                                  color: Color(0xFF6D6D6D),
                                                ),
                                                children: [
                                                  TextSpan(
                                                    text: 'Fri, 7 Jan
                                            ',
                                                    style: GoogleFonts.getFont(
                                                      'Roboto',
                                                      fontWeight: FontWeight.w600,
                                                      fontSize: 10.5,
                                                      height: 1.3,
                                                      color: Color(0xFFFFFFFF),
                                                    ),
                                                  ),
                                                  TextSpan(
                                                    text: 'Rp. 1.004.000',
                                                    style: GoogleFonts.getFont(
                                                      'Roboto',
                                                      fontWeight: FontWeight.w400,
                                                      fontSize: 9,
                                                      height: 1.3,
                                                      color: Color(0xFFFFFFFF),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        top: 185.1,
                                        child: SizedBox(
                                          width: 217.4,
                                          height: 57.4,
                                          child: Row(
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Container(
                                                margin: EdgeInsets.fromLTRB(0, 0, 0, 33),
                                                decoration: BoxDecoration(
                                                  borderRadius: BorderRadius.circular(7.5),
                                                  color: Color(0xFF7060E5),
                                                  boxShadow: [
                                                    BoxShadow(
                                                      color: Color(0x24000000),
                                                      offset: Offset(0, 3),
                                                      blurRadius: 7.5308256149,
                                                    ),
                                                  ],
                                                ),
                                                child: Container(
                                                  padding: EdgeInsets.fromLTRB(7.9, 4.3, 11, 6.1),
                                                  child: Text(
                                                    'All',
                                                    style: GoogleFonts.getFont(
                                                      'Poppins',
                                                      fontWeight: FontWeight.w500,
                                                      fontSize: 9,
                                                      letterSpacing: 0,
                                                      color: Color(0xFFEEEEEE),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                margin: EdgeInsets.fromLTRB(0, 6, 0, 15.9),
                                                decoration: BoxDecoration(
                                                  borderRadius: BorderRadius.circular(7.5),
                                                  color: Color(0x1A7060E5),
                                                  boxShadow: [
                                                    BoxShadow(
                                                      color: Color(0x1F000000),
                                                      offset: Offset(0, 3),
                                                      blurRadius: 7.5308256149,
                                                    ),
                                                  ],
                                                ),
                                                child: Container(
                                                  padding: EdgeInsets.fromLTRB(7.9, 4.3, 9.7, 17.3),
                                                  child: Text(
                                                    'Free Reschedule',
                                                    style: GoogleFonts.getFont(
                                                      'Poppins',
                                                      fontWeight: FontWeight.w500,
                                                      fontSize: 9,
                                                      letterSpacing: 0,
                                                      color: Color(0xFF7060E5),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                margin: EdgeInsets.fromLTRB(0, 23.1, 0, 0),
                                                decoration: BoxDecoration(
                                                  borderRadius: BorderRadius.circular(7.5),
                                                  color: Color(0x1A7060E5),
                                                  boxShadow: [
                                                    BoxShadow(
                                                      color: Color(0x1F000000),
                                                      offset: Offset(0, 3),
                                                      blurRadius: 7.5308256149,
                                                    ),
                                                  ],
                                                ),
                                                child: Container(
                                                  padding: EdgeInsets.fromLTRB(7.9, 4.3, 9.4, 16),
                                                  child: Text(
                                                    'Free Protection',
                                                    style: GoogleFonts.getFont(
                                                      'Poppins',
                                                      fontWeight: FontWeight.w500,
                                                      fontSize: 9,
                                                      letterSpacing: 0,
                                                      color: Color(0xFF7060E5),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        right: 53,
                                        top: 219.2,
                                        child: Container(
                                          decoration: BoxDecoration(
                                            border: Border.all(color: Color(0xFFDEDEDE)),
                                            borderRadius: BorderRadius.circular(7.5),
                                            color: Color(0xFFFFFFFF),
                                            boxShadow: [
                                              BoxShadow(
                                                color: Color(0x24000000),
                                                offset: Offset(0, 3),
                                                blurRadius: 7.5308256149,
                                              ),
                                            ],
                                          ),
                                          child: SizedBox(
                                            width: 275,
                                            height: 133.3,
                                            child: Container(
                                              padding: EdgeInsets.fromLTRB(13.1, 10.3, 18.7, 14.2),
                                              child: Column(
                                                mainAxisAlignment: MainAxisAlignment.start,
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Align(
                                                    alignment: Alignment.topLeft,
                                                    child: Container(
                                                      width: 51.5,
                                                      height: 28,
                                                      child: Container(
                                                        decoration: BoxDecoration(
                                                          image: DecorationImage(
                                                            image: AssetImage(
                                                              'assets/images/air_asia_1.png',
                                                            ),
                                                          ),
                                                        ),
                                                        child: Container(
                                                          width: 51.5,
                                                          height: 28,
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    margin: EdgeInsets.fromLTRB(3, 0, 0, 6.9),
                                                    child: Row(
                                                      mainAxisAlignment: MainAxisAlignment.start,
                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                      children: [
                                                        Container(
                                                          margin: EdgeInsets.fromLTRB(0, 0, 26.5, 8.5),
                                                          child: Row(
                                                            mainAxisAlignment: MainAxisAlignment.start,
                                                            crossAxisAlignment: CrossAxisAlignment.start,
                                                            children: [
                                                              Container(
                                                                margin: EdgeInsets.fromLTRB(0, 0, 14.4, 16.1),
                                                                child: Column(
                                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                                  children: [
                                                                    Container(
                                                                      margin: EdgeInsets.fromLTRB(0, 0, 0, 3.3),
                                                                      child: Text(
                                                                        '09:10',
                                                                        style: GoogleFonts.getFont(
                                                                          'Roboto',
                                                                          fontWeight: FontWeight.w500,
                                                                          fontSize: 12,
                                                                          color: Color(0xFF464646),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                    Container(
                                                                      margin: EdgeInsets.fromLTRB(0.5, 0, 3.6, 0),
                                                                      child: Container(
                                                                        decoration: BoxDecoration(
                                                                          color: Color(0x12808080),
                                                                          borderRadius: BorderRadius.circular(7.5),
                                                                        ),
                                                                        child: Container(
                                                                          padding: EdgeInsets.fromLTRB(5.8, 0.8, 5.8, 3.4),
                                                                          child: Text(
                                                                            'BDO',
                                                                            style: GoogleFonts.getFont(
                                                                              'Poppins',
                                                                              fontWeight: FontWeight.w500,
                                                                              fontSize: 7.5,
                                                                              color: Color(0xFF9B9B9B),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                              ),
                                                              Container(
                                                                margin: EdgeInsets.fromLTRB(0, 9.4, 7.6, 1.2),
                                                                child: Column(
                                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                                  children: [
                                                                    Container(
                                                                      margin: EdgeInsets.fromLTRB(10.3, 0, 5.5, 5.4),
                                                                      child: Text(
                                                                        '1hr 30m',
                                                                        style: GoogleFonts.getFont(
                                                                          'Poppins',
                                                                          fontWeight: FontWeight.w400,
                                                                          fontSize: 7.5,
                                                                          color: Color(0xFF9B9B9B),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                    Container(
                                                                      margin: EdgeInsets.fromLTRB(0, 0, 0, 1.2),
                                                                      child: SizedBox(
                                                                        width: 43,
                                                                        height: 9.4,
                                                                        child: Container(
                                                                          padding: EdgeInsets.fromLTRB(0, 1.4, 0, 7.3),
                                                                          child: Stack(
                                                                            clipBehavior: Clip.none,
                                                                            children: [
                                                                              Container(
                                                                                decoration: BoxDecoration(
                                                                                  color: Color(0xFF9B9B9B),
                                                                                ),
                                                                                child: Container(
                                                                                  width: 43,
                                                                                  height: 0.8,
                                                                                ),
                                                                              ),
                                                                              Positioned(
                                                                                left: 16,
                                                                                bottom: 0,
                                                                                child: Container(
                                                                                  width: 10.4,
                                                                                  height: 9.4,
                                                                                  child: SizedBox(
                                                                                    width: 10.4,
                                                                                    height: 9.4,
                                                                                    child: SvgPicture.asset(
                                                                                      'assets/vectors/vector_16_x2.svg',
                                                                                    ),
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                            ],
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                    Container(
                                                                      margin: EdgeInsets.fromLTRB(8.9, 0, 13.4, 0),
                                                                      child: Text(
                                                                        'Direct',
                                                                        style: GoogleFonts.getFont(
                                                                          'Poppins',
                                                                          fontWeight: FontWeight.w400,
                                                                          fontSize: 7.5,
                                                                          color: Color(0xFF9B9B9B),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                              ),
                                                              Container(
                                                                margin: EdgeInsets.fromLTRB(0, 16.5, 0, 0),
                                                                child: Column(
                                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                                  children: [
                                                                    Container(
                                                                      margin: EdgeInsets.fromLTRB(0, 0, 0, 3.6),
                                                                      child: Text(
                                                                        '10:40',
                                                                        style: GoogleFonts.getFont(
                                                                          'Roboto',
                                                                          fontWeight: FontWeight.w500,
                                                                          fontSize: 12,
                                                                          color: Color(0xFF464646),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                    Container(
                                                                      margin: EdgeInsets.fromLTRB(0.2, 0, 7.9, 0),
                                                                      child: Container(
                                                                        decoration: BoxDecoration(
                                                                          color: Color(0x12808080),
                                                                          borderRadius: BorderRadius.circular(7.5),
                                                                        ),
                                                                        child: Container(
                                                                          padding: EdgeInsets.fromLTRB(4.5, 0.5, 4.5, 3),
                                                                          child: Text(
                                                                            'DPS',
                                                                            style: GoogleFonts.getFont(
                                                                              'Poppins',
                                                                              fontWeight: FontWeight.w500,
                                                                              fontSize: 7.5,
                                                                              color: Color(0xFF9B9B9B),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                        Container(
                                                          margin: EdgeInsets.fromLTRB(0, 26.7, 0, 0),
                                                          child: Column(
                                                            mainAxisAlignment: MainAxisAlignment.start,
                                                            crossAxisAlignment: CrossAxisAlignment.end,
                                                            children: [
                                                              Container(
                                                                margin: EdgeInsets.fromLTRB(0, 0, 14, 1.4),
                                                                child: Text(
                                                                  'Rp. 955.000',
                                                                  style: GoogleFonts.getFont(
                                                                    'Poppins',
                                                                    fontWeight: FontWeight.w600,
                                                                    fontSize: 12,
                                                                    color: Color(0xFFFC7725),
                                                                  ),
                                                                ),
                                                              ),
                                                              Text(
                                                                '/Pax',
                                                                style: GoogleFonts.getFont(
                                                                  'Poppins',
                                                                  fontWeight: FontWeight.w400,
                                                                  fontSize: 7.5,
                                                                  color: Color(0xFF9B9B9B),
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                  Container(
                                                    margin: EdgeInsets.fromLTRB(6.4, 0, 6.4, 0),
                                                    child: Align(
                                                      alignment: Alignment.topRight,
                                                      child: Container(
                                                        width: 10.5,
                                                        height: 15.5,
                                                        child: SizedBox(
                                                          width: 10.5,
                                                          height: 15.5,
                                                          child: SvgPicture.asset(
                                                            'assets/vectors/vector_38_x2.svg',
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        left: 54.8,
                                        bottom: 229.6,
                                        child: Container(
                                          decoration: BoxDecoration(
                                            border: Border.all(color: Color(0xFFDEDEDE)),
                                            borderRadius: BorderRadius.circular(7.5),
                                            color: Color(0xFFFFFFFF),
                                            boxShadow: [
                                              BoxShadow(
                                                color: Color(0x24000000),
                                                offset: Offset(0, 3),
                                                blurRadius: 7.5308256149,
                                              ),
                                            ],
                                          ),
                                          child: SizedBox(
                                            height: 133.3,
                                            child: Container(
                                              padding: EdgeInsets.fromLTRB(13.1, 10.3, 18.7, 14.2),
                                              child: Stack(
                                                clipBehavior: Clip.none,
                                                children: [
                                                  Column(
                                                    mainAxisAlignment: MainAxisAlignment.start,
                                                    crossAxisAlignment: CrossAxisAlignment.start,
                                                    children: [
                                                      Align(
                                                        alignment: Alignment.topLeft,
                                                        child: Container(
                                                          width: 51.5,
                                                          height: 28,
                                                          child: Container(
                                                            decoration: BoxDecoration(
                                                              image: DecorationImage(
                                                                image: AssetImage(
                                                                  'assets/images/air_asia_1.png',
                                                                ),
                                                              ),
                                                            ),
                                                            child: Container(
                                                              width: 51.5,
                                                              height: 28,
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(3, 0, 0, 6.9),
                                                        child: Row(
                                                          mainAxisAlignment: MainAxisAlignment.start,
                                                          crossAxisAlignment: CrossAxisAlignment.start,
                                                          children: [
                                                            Container(
                                                              margin: EdgeInsets.fromLTRB(0, 0, 26.7, 8.5),
                                                              child: Row(
                                                                mainAxisAlignment: MainAxisAlignment.start,
                                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                                children: [
                                                                  Container(
                                                                    margin: EdgeInsets.fromLTRB(0, 0, 14.4, 16.1),
                                                                    child: Column(
                                                                      mainAxisAlignment: MainAxisAlignment.start,
                                                                      crossAxisAlignment: CrossAxisAlignment.center,
                                                                      children: [
                                                                        Container(
                                                                          margin: EdgeInsets.fromLTRB(0, 0, 0, 3.3),
                                                                          child: Text(
                                                                            '13:10',
                                                                            style: GoogleFonts.getFont(
                                                                              'Roboto',
                                                                              fontWeight: FontWeight.w500,
                                                                              fontSize: 12,
                                                                              color: Color(0xFF464646),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                        Container(
                                                                          margin: EdgeInsets.fromLTRB(0.5, 0, 3.6, 0),
                                                                          child: Container(
                                                                            decoration: BoxDecoration(
                                                                              color: Color(0x12808080),
                                                                              borderRadius: BorderRadius.circular(7.5),
                                                                            ),
                                                                            child: Container(
                                                                              padding: EdgeInsets.fromLTRB(5.8, 0.8, 5.8, 3.4),
                                                                              child: Text(
                                                                                'BDO',
                                                                                style: GoogleFonts.getFont(
                                                                                  'Poppins',
                                                                                  fontWeight: FontWeight.w500,
                                                                                  fontSize: 7.5,
                                                                                  color: Color(0xFF9B9B9B),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                  Container(
                                                                    margin: EdgeInsets.fromLTRB(0, 9.4, 7.6, 1.2),
                                                                    child: Column(
                                                                      mainAxisAlignment: MainAxisAlignment.start,
                                                                      crossAxisAlignment: CrossAxisAlignment.center,
                                                                      children: [
                                                                        Container(
                                                                          margin: EdgeInsets.fromLTRB(10.3, 0, 5.5, 5.4),
                                                                          child: Text(
                                                                            '1hr 30m',
                                                                            style: GoogleFonts.getFont(
                                                                              'Poppins',
                                                                              fontWeight: FontWeight.w400,
                                                                              fontSize: 7.5,
                                                                              color: Color(0xFF9B9B9B),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                        Container(
                                                                          margin: EdgeInsets.fromLTRB(0, 0, 0, 1.2),
                                                                          child: SizedBox(
                                                                            width: 43,
                                                                            height: 9.4,
                                                                            child: Container(
                                                                              padding: EdgeInsets.fromLTRB(0, 1.4, 0, 7.3),
                                                                              child: Stack(
                                                                                clipBehavior: Clip.none,
                                                                                children: [
                                                                                  Container(
                                                                                    decoration: BoxDecoration(
                                                                                      color: Color(0xFF9B9B9B),
                                                                                    ),
                                                                                    child: Container(
                                                                                      width: 43,
                                                                                      height: 0.8,
                                                                                    ),
                                                                                  ),
                                                                                  Positioned(
                                                                                    left: 16,
                                                                                    bottom: 0,
                                                                                    child: Container(
                                                                                      width: 10.4,
                                                                                      height: 9.4,
                                                                                      child: SizedBox(
                                                                                        width: 10.4,
                                                                                        height: 9.4,
                                                                                        child: SvgPicture.asset(
                                                                                          'assets/vectors/vector_69_x2.svg',
                                                                                        ),
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                        Container(
                                                                          margin: EdgeInsets.fromLTRB(8.9, 0, 13.4, 0),
                                                                          child: Text(
                                                                            'Direct',
                                                                            style: GoogleFonts.getFont(
                                                                              'Poppins',
                                                                              fontWeight: FontWeight.w400,
                                                                              fontSize: 7.5,
                                                                              color: Color(0xFF9B9B9B),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                  Container(
                                                                    margin: EdgeInsets.fromLTRB(0, 16.5, 0, 0),
                                                                    child: Column(
                                                                      mainAxisAlignment: MainAxisAlignment.start,
                                                                      crossAxisAlignment: CrossAxisAlignment.center,
                                                                      children: [
                                                                        Container(
                                                                          margin: EdgeInsets.fromLTRB(0, 0, 0, 3.6),
                                                                          child: Text(
                                                                            '14:40',
                                                                            style: GoogleFonts.getFont(
                                                                              'Roboto',
                                                                              fontWeight: FontWeight.w500,
                                                                              fontSize: 12,
                                                                              color: Color(0xFF464646),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                        Container(
                                                                          margin: EdgeInsets.fromLTRB(0.2, 0, 7.9, 0),
                                                                          child: Container(
                                                                            decoration: BoxDecoration(
                                                                              color: Color(0x12808080),
                                                                              borderRadius: BorderRadius.circular(7.5),
                                                                            ),
                                                                            child: Container(
                                                                              padding: EdgeInsets.fromLTRB(4.5, 0.5, 4.5, 3),
                                                                              child: Text(
                                                                                'DPS',
                                                                                style: GoogleFonts.getFont(
                                                                                  'Poppins',
                                                                                  fontWeight: FontWeight.w500,
                                                                                  fontSize: 7.5,
                                                                                  color: Color(0xFF9B9B9B),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                            Container(
                                                              margin: EdgeInsets.fromLTRB(0, 26.7, 0, 0),
                                                              child: Column(
                                                                mainAxisAlignment: MainAxisAlignment.start,
                                                                crossAxisAlignment: CrossAxisAlignment.end,
                                                                children: [
                                                                  Container(
                                                                    margin: EdgeInsets.fromLTRB(0, 0, 14, 1.4),
                                                                    child: Text(
                                                                      'Rp. 990.000',
                                                                      style: GoogleFonts.getFont(
                                                                        'Poppins',
                                                                        fontWeight: FontWeight.w600,
                                                                        fontSize: 12,
                                                                        color: Color(0xFFFC7725),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  Text(
                                                                    '/Pax',
                                                                    style: GoogleFonts.getFont(
                                                                      'Poppins',
                                                                      fontWeight: FontWeight.w400,
                                                                      fontSize: 7.5,
                                                                      color: Color(0xFF9B9B9B),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(6.4, 0, 6.4, 0),
                                                        child: Align(
                                                          alignment: Alignment.topRight,
                                                          child: Container(
                                                            width: 10.5,
                                                            height: 15.5,
                                                            child: SizedBox(
                                                              width: 10.5,
                                                              height: 15.5,
                                                              child: SvgPicture.asset(
                                                                'assets/vectors/vector_59_x2.svg',
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                  Positioned(
                                                    right: -6.8,
                                                    top: 31.7,
                                                    child: Container(
                                                      decoration: BoxDecoration(
                                                        borderRadius: BorderRadius.circular(15.1),
                                                        color: Color(0xFF06A469),
                                                        boxShadow: [
                                                          BoxShadow(
                                                            color: Color(0x1A000000),
                                                            offset: Offset(0, 3),
                                                            blurRadius: 11.2962379456,
                                                          ),
                                                        ],
                                                      ),
                                                      child: Container(
                                                        height: 27.1,
                                                        padding: EdgeInsets.fromLTRB(10.3, 4.3, 10.3, 14.9),
                                                        child: Text(
                                                          'Free Reschedule',
                                                          style: GoogleFonts.getFont(
                                                            'Roboto',
                                                            fontWeight: FontWeight.w400,
                                                            fontSize: 7.5,
                                                            color: Color(0xFFFFFFFF),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        left: 38.1,
                                        bottom: 134.6,
                                        child: Container(
                                          decoration: BoxDecoration(
                                            border: Border.all(color: Color(0xFFDEDEDE)),
                                            borderRadius: BorderRadius.circular(7.5),
                                            color: Color(0xFFFFFFFF),
                                            boxShadow: [
                                              BoxShadow(
                                                color: Color(0x24000000),
                                                offset: Offset(0, 3),
                                                blurRadius: 7.5308256149,
                                              ),
                                            ],
                                          ),
                                          child: SizedBox(
                                            height: 133.3,
                                            child: Container(
                                              padding: EdgeInsets.fromLTRB(16.1, 11.5, 19, 14.2),
                                              child: Stack(
                                                clipBehavior: Clip.none,
                                                children: [
                                                  Column(
                                                    mainAxisAlignment: MainAxisAlignment.start,
                                                    crossAxisAlignment: CrossAxisAlignment.start,
                                                    children: [
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(4.7, 0, 4.7, 6.4),
                                                        child: Align(
                                                          alignment: Alignment.topLeft,
                                                          child: Container(
                                                            decoration: BoxDecoration(
                                                              image: DecorationImage(
                                                                image: AssetImage(
                                                                  'assets/images/logo_citilink_by_kampungdesigner_1.png',
                                                                ),
                                                              ),
                                                            ),
                                                            child: Container(
                                                              width: 39.5,
                                                              height: 20.3,
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(0, 0, 0, 6.9),
                                                        child: Row(
                                                          mainAxisAlignment: MainAxisAlignment.start,
                                                          crossAxisAlignment: CrossAxisAlignment.start,
                                                          children: [
                                                            Container(
                                                              margin: EdgeInsets.fromLTRB(0, 0, 27.1, 8.4),
                                                              child: Row(
                                                                mainAxisAlignment: MainAxisAlignment.start,
                                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                                children: [
                                                                  Container(
                                                                    margin: EdgeInsets.fromLTRB(0, 0, 14.4, 16.1),
                                                                    child: Column(
                                                                      mainAxisAlignment: MainAxisAlignment.start,
                                                                      crossAxisAlignment: CrossAxisAlignment.center,
                                                                      children: [
                                                                        Container(
                                                                          margin: EdgeInsets.fromLTRB(0, 0, 0, 3.3),
                                                                          child: Text(
                                                                            '15:20',
                                                                            style: GoogleFonts.getFont(
                                                                              'Roboto',
                                                                              fontWeight: FontWeight.w500,
                                                                              fontSize: 12,
                                                                              color: Color(0xFF464646),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                        Container(
                                                                          margin: EdgeInsets.fromLTRB(0.5, 0, 3.6, 0),
                                                                          child: Container(
                                                                            decoration: BoxDecoration(
                                                                              color: Color(0x12808080),
                                                                              borderRadius: BorderRadius.circular(7.5),
                                                                            ),
                                                                            child: Container(
                                                                              padding: EdgeInsets.fromLTRB(5.8, 0.8, 5.8, 3.4),
                                                                              child: Text(
                                                                                'BDO',
                                                                                style: GoogleFonts.getFont(
                                                                                  'Poppins',
                                                                                  fontWeight: FontWeight.w500,
                                                                                  fontSize: 7.5,
                                                                                  color: Color(0xFF9B9B9B),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                  Container(
                                                                    margin: EdgeInsets.fromLTRB(0, 9.4, 7.6, 1.2),
                                                                    child: Column(
                                                                      mainAxisAlignment: MainAxisAlignment.start,
                                                                      crossAxisAlignment: CrossAxisAlignment.center,
                                                                      children: [
                                                                        Container(
                                                                          margin: EdgeInsets.fromLTRB(10.3, 0, 5.5, 5.4),
                                                                          child: Text(
                                                                            '1hr 30m',
                                                                            style: GoogleFonts.getFont(
                                                                              'Poppins',
                                                                              fontWeight: FontWeight.w400,
                                                                              fontSize: 7.5,
                                                                              color: Color(0xFF9B9B9B),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                        Container(
                                                                          margin: EdgeInsets.fromLTRB(0, 0, 0, 1.2),
                                                                          child: SizedBox(
                                                                            width: 43,
                                                                            height: 9.4,
                                                                            child: Container(
                                                                              padding: EdgeInsets.fromLTRB(0, 1.4, 0, 7.3),
                                                                              child: Stack(
                                                                                clipBehavior: Clip.none,
                                                                                children: [
                                                                                  Container(
                                                                                    decoration: BoxDecoration(
                                                                                      color: Color(0xFF9B9B9B),
                                                                                    ),
                                                                                    child: Container(
                                                                                      width: 43,
                                                                                      height: 0.8,
                                                                                    ),
                                                                                  ),
                                                                                  Positioned(
                                                                                    left: 16,
                                                                                    bottom: 0,
                                                                                    child: Container(
                                                                                      width: 10.4,
                                                                                      height: 9.4,
                                                                                      child: SizedBox(
                                                                                        width: 10.4,
                                                                                        height: 9.4,
                                                                                        child: SvgPicture.asset(
                                                                                          'assets/vectors/vector_60_x2.svg',
                                                                                        ),
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                        Container(
                                                                          margin: EdgeInsets.fromLTRB(8.9, 0, 13.4, 0),
                                                                          child: Text(
                                                                            'Direct',
                                                                            style: GoogleFonts.getFont(
                                                                              'Poppins',
                                                                              fontWeight: FontWeight.w400,
                                                                              fontSize: 7.5,
                                                                              color: Color(0xFF9B9B9B),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                  Container(
                                                                    margin: EdgeInsets.fromLTRB(0, 16.5, 0, 0),
                                                                    child: Column(
                                                                      mainAxisAlignment: MainAxisAlignment.start,
                                                                      crossAxisAlignment: CrossAxisAlignment.center,
                                                                      children: [
                                                                        Container(
                                                                          margin: EdgeInsets.fromLTRB(0, 0, 0, 3.6),
                                                                          child: Text(
                                                                            '16:60',
                                                                            style: GoogleFonts.getFont(
                                                                              'Roboto',
                                                                              fontWeight: FontWeight.w500,
                                                                              fontSize: 12,
                                                                              color: Color(0xFF464646),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                        Container(
                                                                          margin: EdgeInsets.fromLTRB(0.2, 0, 7.9, 0),
                                                                          child: Container(
                                                                            decoration: BoxDecoration(
                                                                              color: Color(0x12808080),
                                                                              borderRadius: BorderRadius.circular(7.5),
                                                                            ),
                                                                            child: Container(
                                                                              padding: EdgeInsets.fromLTRB(4.5, 0.5, 4.5, 3),
                                                                              child: Text(
                                                                                'DPS',
                                                                                style: GoogleFonts.getFont(
                                                                                  'Poppins',
                                                                                  fontWeight: FontWeight.w500,
                                                                                  fontSize: 7.5,
                                                                                  color: Color(0xFF9B9B9B),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                            Container(
                                                              margin: EdgeInsets.fromLTRB(0, 26.8, 0, 0),
                                                              child: Column(
                                                                mainAxisAlignment: MainAxisAlignment.start,
                                                                crossAxisAlignment: CrossAxisAlignment.end,
                                                                children: [
                                                                  Container(
                                                                    margin: EdgeInsets.fromLTRB(0, 0, 14, 1.2),
                                                                    child: Text(
                                                                      'Rp. 1.02.000',
                                                                      style: GoogleFonts.getFont(
                                                                        'Poppins',
                                                                        fontWeight: FontWeight.w600,
                                                                        fontSize: 12,
                                                                        color: Color(0xFFFC7725),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  Text(
                                                                    '/Pax',
                                                                    style: GoogleFonts.getFont(
                                                                      'Poppins',
                                                                      fontWeight: FontWeight.w400,
                                                                      fontSize: 7.5,
                                                                      color: Color(0xFF9B9B9B),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(6.2, 0, 6.2, 0),
                                                        child: Align(
                                                          alignment: Alignment.topRight,
                                                          child: Container(
                                                            width: 10.5,
                                                            height: 15.5,
                                                            child: SizedBox(
                                                              width: 10.5,
                                                              height: 15.5,
                                                              child: SvgPicture.asset(
                                                                'assets/vectors/vector_2_x2.svg',
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                  Positioned(
                                                    right: -7,
                                                    top: 30.6,
                                                    child: Container(
                                                      decoration: BoxDecoration(
                                                        borderRadius: BorderRadius.circular(15.1),
                                                        color: Color(0xFF06A469),
                                                        boxShadow: [
                                                          BoxShadow(
                                                            color: Color(0x1A000000),
                                                            offset: Offset(0, 3),
                                                            blurRadius: 11.2962379456,
                                                          ),
                                                        ],
                                                      ),
                                                      child: Container(
                                                        height: 27.1,
                                                        padding: EdgeInsets.fromLTRB(10.3, 4.3, 10.3, 14.9),
                                                        child: Text(
                                                          'Free Reschedule',
                                                          style: GoogleFonts.getFont(
                                                            'Roboto',
                                                            fontWeight: FontWeight.w400,
                                                            fontSize: 7.5,
                                                            color: Color(0xFFFFFFFF),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        left: 21.4,
                                        bottom: 39.7,
                                        child: Container(
                                          decoration: BoxDecoration(
                                            border: Border.all(color: Color(0xFFDEDEDE)),
                                            borderRadius: BorderRadius.circular(7.5),
                                            color: Color(0xFFFFFFFF),
                                            boxShadow: [
                                              BoxShadow(
                                                color: Color(0x24000000),
                                                offset: Offset(0, 3),
                                                blurRadius: 7.5308256149,
                                              ),
                                            ],
                                          ),
                                          child: SizedBox(
                                            height: 133.3,
                                            child: Container(
                                              padding: EdgeInsets.fromLTRB(16.1, 11.5, 19.3, 14.2),
                                              child: Stack(
                                                clipBehavior: Clip.none,
                                                children: [
                                                  Column(
                                                    mainAxisAlignment: MainAxisAlignment.start,
                                                    crossAxisAlignment: CrossAxisAlignment.start,
                                                    children: [
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(4.7, 0, 4.7, 6.4),
                                                        child: Align(
                                                          alignment: Alignment.topLeft,
                                                          child: Container(
                                                            decoration: BoxDecoration(
                                                              image: DecorationImage(
                                                                image: AssetImage(
                                                                  'assets/images/logo_citilink_by_kampungdesigner_1.png',
                                                                ),
                                                              ),
                                                            ),
                                                            child: Container(
                                                              width: 39.5,
                                                              height: 20.3,
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(0, 0, 0, 7),
                                                        child: Row(
                                                          mainAxisAlignment: MainAxisAlignment.start,
                                                          crossAxisAlignment: CrossAxisAlignment.start,
                                                          children: [
                                                            Container(
                                                              margin: EdgeInsets.fromLTRB(0, 0, 21.6, 8.4),
                                                              child: Row(
                                                                mainAxisAlignment: MainAxisAlignment.start,
                                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                                children: [
                                                                  Container(
                                                                    margin: EdgeInsets.fromLTRB(0, 0, 14.4, 16.1),
                                                                    child: Column(
                                                                      mainAxisAlignment: MainAxisAlignment.start,
                                                                      crossAxisAlignment: CrossAxisAlignment.center,
                                                                      children: [
                                                                        Container(
                                                                          margin: EdgeInsets.fromLTRB(0, 0, 0, 3.3),
                                                                          child: Text(
                                                                            '16:50',
                                                                            style: GoogleFonts.getFont(
                                                                              'Roboto',
                                                                              fontWeight: FontWeight.w500,
                                                                              fontSize: 12,
                                                                              color: Color(0xFF464646),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                        Container(
                                                                          margin: EdgeInsets.fromLTRB(0.5, 0, 3.6, 0),
                                                                          child: Container(
                                                                            decoration: BoxDecoration(
                                                                              color: Color(0x12808080),
                                                                              borderRadius: BorderRadius.circular(7.5),
                                                                            ),
                                                                            child: Container(
                                                                              padding: EdgeInsets.fromLTRB(5.8, 0.8, 5.8, 3.4),
                                                                              child: Text(
                                                                                'BDO',
                                                                                style: GoogleFonts.getFont(
                                                                                  'Poppins',
                                                                                  fontWeight: FontWeight.w500,
                                                                                  fontSize: 7.5,
                                                                                  color: Color(0xFF9B9B9B),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                  Container(
                                                                    margin: EdgeInsets.fromLTRB(0, 9.4, 7.6, 1.2),
                                                                    child: Column(
                                                                      mainAxisAlignment: MainAxisAlignment.start,
                                                                      crossAxisAlignment: CrossAxisAlignment.center,
                                                                      children: [
                                                                        Container(
                                                                          margin: EdgeInsets.fromLTRB(10.3, 0, 5.5, 5.4),
                                                                          child: Text(
                                                                            '1hr 30m',
                                                                            style: GoogleFonts.getFont(
                                                                              'Poppins',
                                                                              fontWeight: FontWeight.w400,
                                                                              fontSize: 7.5,
                                                                              color: Color(0xFF9B9B9B),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                        Container(
                                                                          margin: EdgeInsets.fromLTRB(0, 0, 0, 1.2),
                                                                          child: SizedBox(
                                                                            width: 43,
                                                                            height: 9.4,
                                                                            child: Container(
                                                                              padding: EdgeInsets.fromLTRB(0, 1.4, 0, 7.3),
                                                                              child: Stack(
                                                                                clipBehavior: Clip.none,
                                                                                children: [
                                                                                  Container(
                                                                                    decoration: BoxDecoration(
                                                                                      color: Color(0xFF9B9B9B),
                                                                                    ),
                                                                                    child: Container(
                                                                                      width: 43,
                                                                                      height: 0.8,
                                                                                    ),
                                                                                  ),
                                                                                  Positioned(
                                                                                    left: 16,
                                                                                    bottom: 0,
                                                                                    child: Container(
                                                                                      width: 10.4,
                                                                                      height: 9.4,
                                                                                      child: SizedBox(
                                                                                        width: 10.4,
                                                                                        height: 9.4,
                                                                                        child: SvgPicture.asset(
                                                                                          'assets/vectors/vector_4_x2.svg',
                                                                                        ),
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                        Container(
                                                                          margin: EdgeInsets.fromLTRB(8.9, 0, 13.4, 0),
                                                                          child: Text(
                                                                            'Direct',
                                                                            style: GoogleFonts.getFont(
                                                                              'Poppins',
                                                                              fontWeight: FontWeight.w400,
                                                                              fontSize: 7.5,
                                                                              color: Color(0xFF9B9B9B),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                  Container(
                                                                    margin: EdgeInsets.fromLTRB(0, 16.5, 0, 0),
                                                                    child: Column(
                                                                      mainAxisAlignment: MainAxisAlignment.start,
                                                                      crossAxisAlignment: CrossAxisAlignment.center,
                                                                      children: [
                                                                        Container(
                                                                          margin: EdgeInsets.fromLTRB(0, 0, 0, 3.6),
                                                                          child: Text(
                                                                            '18:10',
                                                                            style: GoogleFonts.getFont(
                                                                              'Roboto',
                                                                              fontWeight: FontWeight.w500,
                                                                              fontSize: 12,
                                                                              color: Color(0xFF464646),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                        Container(
                                                                          margin: EdgeInsets.fromLTRB(0.2, 0, 7.9, 0),
                                                                          child: Container(
                                                                            decoration: BoxDecoration(
                                                                              color: Color(0x12808080),
                                                                              borderRadius: BorderRadius.circular(7.5),
                                                                            ),
                                                                            child: Container(
                                                                              padding: EdgeInsets.fromLTRB(4.5, 0.5, 4.5, 3),
                                                                              child: Text(
                                                                                'DPS',
                                                                                style: GoogleFonts.getFont(
                                                                                  'Poppins',
                                                                                  fontWeight: FontWeight.w500,
                                                                                  fontSize: 7.5,
                                                                                  color: Color(0xFF9B9B9B),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                            Container(
                                                              margin: EdgeInsets.fromLTRB(0, 25.9, 0, 0),
                                                              child: Column(
                                                                mainAxisAlignment: MainAxisAlignment.start,
                                                                crossAxisAlignment: CrossAxisAlignment.end,
                                                                children: [
                                                                  Container(
                                                                    margin: EdgeInsets.fromLTRB(0, 0, 14, 2.1),
                                                                    child: Text(
                                                                      'Rp. 1.100.000',
                                                                      style: GoogleFonts.getFont(
                                                                        'Poppins',
                                                                        fontWeight: FontWeight.w600,
                                                                        fontSize: 12,
                                                                        color: Color(0xFFFC7725),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  Text(
                                                                    '/Pax',
                                                                    style: GoogleFonts.getFont(
                                                                      'Poppins',
                                                                      fontWeight: FontWeight.w400,
                                                                      fontSize: 7.5,
                                                                      color: Color(0xFF9B9B9B),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(5.9, 0, 5.9, 0),
                                                        child: Align(
                                                          alignment: Alignment.topRight,
                                                          child: Container(
                                                            width: 10.5,
                                                            height: 15.5,
                                                            child: SizedBox(
                                                              width: 10.5,
                                                              height: 15.5,
                                                              child: SvgPicture.asset(
                                                                'assets/vectors/vector_28_x2.svg',
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                  Positioned(
                                                    right: -7.3,
                                                    top: 30.6,
                                                    child: Container(
                                                      decoration: BoxDecoration(
                                                        borderRadius: BorderRadius.circular(15.1),
                                                        color: Color(0xFF06A469),
                                                        boxShadow: [
                                                          BoxShadow(
                                                            color: Color(0x1A000000),
                                                            offset: Offset(0, 3),
                                                            blurRadius: 11.2962379456,
                                                          ),
                                                        ],
                                                      ),
                                                      child: Container(
                                                        height: 27.1,
                                                        padding: EdgeInsets.fromLTRB(10.3, 4.3, 10.3, 14.9),
                                                        child: Text(
                                                          'Free Reschedule',
                                                          style: GoogleFonts.getFont(
                                                            'Roboto',
                                                            fontWeight: FontWeight.w400,
                                                            fontSize: 7.5,
                                                            color: Color(0xFFFFFFFF),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        left: 4.6,
                                        bottom: -55.2,
                                        child: Container(
                                          decoration: BoxDecoration(
                                            border: Border.all(color: Color(0xFFDEDEDE)),
                                            borderRadius: BorderRadius.circular(7.5),
                                            color: Color(0xFFFFFFFF),
                                            boxShadow: [
                                              BoxShadow(
                                                color: Color(0x24000000),
                                                offset: Offset(0, 3),
                                                blurRadius: 7.5308256149,
                                              ),
                                            ],
                                          ),
                                          child: SizedBox(
                                            height: 133.3,
                                            child: Container(
                                              padding: EdgeInsets.fromLTRB(16.1, 11.5, 19, 14.2),
                                              child: Stack(
                                                clipBehavior: Clip.none,
                                                children: [
                                                  Column(
                                                    mainAxisAlignment: MainAxisAlignment.start,
                                                    crossAxisAlignment: CrossAxisAlignment.start,
                                                    children: [
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(5, 0, 5, 7.1),
                                                        child: Align(
                                                          alignment: Alignment.topLeft,
                                                          child: Container(
                                                            decoration: BoxDecoration(
                                                              image: DecorationImage(
                                                                fit: BoxFit.cover,
                                                                image: AssetImage(
                                                                  'assets/images/logo_batik_air_1.png',
                                                                ),
                                                              ),
                                                            ),
                                                            child: Container(
                                                              width: 45.8,
                                                              height: 19.6,
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(0, 0, 0, 6.9),
                                                        child: Row(
                                                          mainAxisAlignment: MainAxisAlignment.start,
                                                          crossAxisAlignment: CrossAxisAlignment.start,
                                                          children: [
                                                            Container(
                                                              margin: EdgeInsets.fromLTRB(0, 0, 18.2, 8.4),
                                                              child: Row(
                                                                mainAxisAlignment: MainAxisAlignment.start,
                                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                                children: [
                                                                  Container(
                                                                    margin: EdgeInsets.fromLTRB(0, 0, 13.6, 16.1),
                                                                    child: Column(
                                                                      mainAxisAlignment: MainAxisAlignment.start,
                                                                      crossAxisAlignment: CrossAxisAlignment.center,
                                                                      children: [
                                                                        Container(
                                                                          margin: EdgeInsets.fromLTRB(0, 0, 0, 3.3),
                                                                          child: Text(
                                                                            '18:10',
                                                                            style: GoogleFonts.getFont(
                                                                              'Roboto',
                                                                              fontWeight: FontWeight.w500,
                                                                              fontSize: 12,
                                                                              color: Color(0xFF464646),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                        Container(
                                                                          margin: EdgeInsets.fromLTRB(0.5, 0, 3.6, 0),
                                                                          child: Container(
                                                                            decoration: BoxDecoration(
                                                                              color: Color(0x12808080),
                                                                              borderRadius: BorderRadius.circular(7.5),
                                                                            ),
                                                                            child: Container(
                                                                              padding: EdgeInsets.fromLTRB(5.8, 0.8, 5.8, 3.4),
                                                                              child: Text(
                                                                                'BDO',
                                                                                style: GoogleFonts.getFont(
                                                                                  'Poppins',
                                                                                  fontWeight: FontWeight.w500,
                                                                                  fontSize: 7.5,
                                                                                  color: Color(0xFF9B9B9B),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                  Container(
                                                                    margin: EdgeInsets.fromLTRB(0, 9.4, 6.7, 1.2),
                                                                    child: Stack(
                                                                      children: [
                                                                        Positioned(
                                                                          top: 12.5,
                                                                          child: SizedBox(
                                                                            width: 44.7,
                                                                            height: 17.2,
                                                                            child: SvgPicture.asset(
                                                                              'assets/vectors/frame_781_x2.svg',
                                                                            ),
                                                                          ),
                                                                        ),
                                                                  Container(
                                                                          padding: EdgeInsets.fromLTRB(9.7, 0, 6.4, 0),
                                                                          child: Column(
                                                                            mainAxisAlignment: MainAxisAlignment.start,
                                                                            crossAxisAlignment: CrossAxisAlignment.center,
                                                                            children: [
                                                                              Container(
                                                                                margin: EdgeInsets.fromLTRB(1.4, 0, 0, 16),
                                                                                child: Text(
                                                                                  '1hr 30m',
                                                                                  style: GoogleFonts.getFont(
                                                                                    'Poppins',
                                                                                    fontWeight: FontWeight.w400,
                                                                                    fontSize: 7.5,
                                                                                    color: Color(0xFF9B9B9B),
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                              Container(
                                                                                margin: EdgeInsets.fromLTRB(0, 0, 8, 0),
                                                                                child: Text(
                                                                                  'Direct',
                                                                                  style: GoogleFonts.getFont(
                                                                                    'Poppins',
                                                                                    fontWeight: FontWeight.w400,
                                                                                    fontSize: 7.5,
                                                                                    color: Color(0xFF9B9B9B),
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                            ],
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                  Container(
                                                                    margin: EdgeInsets.fromLTRB(0, 16.5, 0, 0),
                                                                    child: Column(
                                                                      mainAxisAlignment: MainAxisAlignment.start,
                                                                      crossAxisAlignment: CrossAxisAlignment.center,
                                                                      children: [
                                                                        Container(
                                                                          margin: EdgeInsets.fromLTRB(0, 0, 0, 3.6),
                                                                          child: Text(
                                                                            '19:40',
                                                                            style: GoogleFonts.getFont(
                                                                              'Roboto',
                                                                              fontWeight: FontWeight.w500,
                                                                              fontSize: 12,
                                                                              color: Color(0xFF464646),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                        Container(
                                                                          margin: EdgeInsets.fromLTRB(0.2, 0, 7.9, 0),
                                                                          child: Container(
                                                                            decoration: BoxDecoration(
                                                                              color: Color(0x12808080),
                                                                              borderRadius: BorderRadius.circular(7.5),
                                                                            ),
                                                                            child: Container(
                                                                              padding: EdgeInsets.fromLTRB(4.5, 0.5, 4.5, 3),
                                                                              child: Text(
                                                                                'DPS',
                                                                                style: GoogleFonts.getFont(
                                                                                  'Poppins',
                                                                                  fontWeight: FontWeight.w500,
                                                                                  fontSize: 7.5,
                                                                                  color: Color(0xFF9B9B9B),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                            Container(
                                                              margin: EdgeInsets.fromLTRB(0, 25.2, 0, 0),
                                                              child: Column(
                                                                mainAxisAlignment: MainAxisAlignment.start,
                                                                crossAxisAlignment: CrossAxisAlignment.end,
                                                                children: [
                                                                  Container(
                                                                    margin: EdgeInsets.fromLTRB(0, 0, 14, 2.8),
                                                                    child: Text(
                                                                      'Rp. 1.400.000',
                                                                      style: GoogleFonts.getFont(
                                                                        'Poppins',
                                                                        fontWeight: FontWeight.w600,
                                                                        fontSize: 12,
                                                                        color: Color(0xFFFC7725),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  Text(
                                                                    '/Pax',
                                                                    style: GoogleFonts.getFont(
                                                                      'Poppins',
                                                                      fontWeight: FontWeight.w400,
                                                                      fontSize: 7.5,
                                                                      color: Color(0xFF9B9B9B),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(6.2, 0, 6.2, 0),
                                                        child: Align(
                                                          alignment: Alignment.topRight,
                                                          child: Container(
                                                            width: 10.5,
                                                            height: 15.5,
                                                            child: SizedBox(
                                                              width: 10.5,
                                                              height: 15.5,
                                                              child: SvgPicture.asset(
                                                                'assets/vectors/vector_62_x2.svg',
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                  Positioned(
                                                    right: -7.1,
                                                    top: 30.6,
                                                    child: Container(
                                                      decoration: BoxDecoration(
                                                        borderRadius: BorderRadius.circular(15.1),
                                                        color: Color(0xFF06A469),
                                                        boxShadow: [
                                                          BoxShadow(
                                                            color: Color(0x1A000000),
                                                            offset: Offset(0, 3),
                                                            blurRadius: 11.2962379456,
                                                          ),
                                                        ],
                                                      ),
                                                      child: Container(
                                                        height: 27.1,
                                                        padding: EdgeInsets.fromLTRB(10.3, 4.3, 10.3, 14.9),
                                                        child: Text(
                                                          'Free Reschedule',
                                                          style: GoogleFonts.getFont(
                                                            'Roboto',
                                                            fontWeight: FontWeight.w400,
                                                            fontSize: 7.5,
                                                            color: Color(0xFFFFFFFF),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Positioned(
                                                    right: 69.5,
                                                    top: 17.8,
                                                    child: Container(
                                                      decoration: BoxDecoration(
                                                        borderRadius: BorderRadius.circular(15.1),
                                                        color: Color(0xFF255B9B),
                                                        boxShadow: [
                                                          BoxShadow(
                                                            color: Color(0x1A000000),
                                                            offset: Offset(0, 3),
                                                            blurRadius: 11.2962379456,
                                                          ),
                                                        ],
                                                      ),
                                                      child: Container(
                                                        height: 26.4,
                                                        padding: EdgeInsets.fromLTRB(10.3, 4.3, 10.3, 14.2),
                                                        child: Text(
                                                          'Free Protection',
                                                          style: GoogleFonts.getFont(
                                                            'Roboto',
                                                            fontWeight: FontWeight.w400,
                                                            fontSize: 7.5,
                                                            color: Color(0xFFFFFFFF),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        left: 82.5,
                                        bottom: 31.8,
                                        child: Container(
                                          decoration: BoxDecoration(
                                            borderRadius: BorderRadius.circular(15.1),
                                            color: Color(0xFFFFFFFF),
                                            boxShadow: [
                                              BoxShadow(
                                                color: Color(0x33000000),
                                                offset: Offset(0, 5.3),
                                                blurRadius: 7.5308256149,
                                              ),
                                            ],
                                          ),
                                          child: SizedBox(
                                            width: 136.8,
                                            height: 58.6,
                                            child: Container(
                                              padding: EdgeInsets.fromLTRB(13.6, 11.6, 14.9, 11.4),
                                              child: Row(
                                                mainAxisAlignment: MainAxisAlignment.start,
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    margin: EdgeInsets.fromLTRB(0, 3.3, 10.2, 18.3),
                                                    child: Row(
                                                      mainAxisAlignment: MainAxisAlignment.start,
                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                      children: [
                                                        Container(
                                                          margin: EdgeInsets.fromLTRB(0, 0, 2.5, 2),
                                                          width: 14.9,
                                                          height: 12.1,
                                                          child: SizedBox(
                                                            width: 14.9,
                                                            height: 12.1,
                                                            child: SvgPicture.asset(
                                                              'assets/vectors/vector_9_x2.svg',
                                                            ),
                                                          ),
                                                        ),
                                                        Container(
                                                          margin: EdgeInsets.fromLTRB(0, 2.1, 0, 0),
                                                          child: Text(
                                                            'Short',
                                                            style: GoogleFonts.getFont(
                                                              'Roboto',
                                                              fontWeight: FontWeight.w600,
                                                              fontSize: 10.5,
                                                              color: Color(0xFF7060E5),
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                  Container(
                                                    margin: EdgeInsets.fromLTRB(0, 0, 9.2, 0),
                                                    child: SizedBox(
                                                      width: 6.3,
                                                      height: 35.6,
                                                      child: SvgPicture.asset(
                                                        'assets/vectors/vector_4_x2.svg',
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    margin: EdgeInsets.fromLTRB(0, 16.2, 0, 4.4),
                                                    child: Row(
                                                      mainAxisAlignment: MainAxisAlignment.start,
                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                      children: [
                                                        Container(
                                                          margin: EdgeInsets.fromLTRB(0, 0.7, 4.5, 3.8),
                                                          width: 10.5,
                                                          height: 10.5,
                                                          child: SizedBox(
                                                            width: 10.5,
                                                            height: 10.5,
                                                            child: SvgPicture.asset(
                                                              'assets/vectors/vector_66_x2.svg',
                                                            ),
                                                          ),
                                                        ),
                                                        Text(
                                                          'Filter',
                                                          style: GoogleFonts.getFont(
                                                            'Poppins',
                                                            fontWeight: FontWeight.w600,
                                                            fontSize: 10.5,
                                                            letterSpacing: 0.1,
                                                            color: Color(0xFF7060E5),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                      Positioned(
                        right: 286.6,
                        top: 20.7,
                        child: Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(15.1),
                            color: Color(0xFFFFFFFF),
                            boxShadow: [
                              BoxShadow(
                                color: Color(0x33000000),
                                offset: Offset(0, 30.1),
                                blurRadius: 13.1789445877,
                              ),
                              BoxShadow(
                                color: Color(0x33000000),
                                offset: Offset(0, -30.1),
                                blurRadius: 15.0616512299,
                              ),
                            ],
                          ),
                          child: SizedBox(
                            width: 293.7,
                            height: 635.6,
                            child: Stack(
                              children: [
                                Container(
                                  decoration: BoxDecoration(
                                    color: Color(0xFF7060E5),
                                    borderRadius: BorderRadius.circular(15.1),
                                  ),
                                  child: SizedBox(
                                    width: 293.7,
                                    child: Container(
                                      padding: EdgeInsets.fromLTRB(15.1, 10.5, 15.1, 19.6),
                                      child: Stack(
                                        clipBehavior: Clip.none,
                                        children: [
                                          Positioned(
                                            left: -39.9,
                                            top: -59.5,
                                            child: Container(
                                              decoration: BoxDecoration(
                                                color: Color(0xFF7868EC),
                                                borderRadius: BorderRadius.circular(62.9),
                                              ),
                                              child: Container(
                                                width: 125.8,
                                                height: 125.8,
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            left: -58.7,
                                            top: -55.7,
                                            child: Container(
                                              decoration: BoxDecoration(
                                                color: Color(0xFF7F6FF2),
                                                borderRadius: BorderRadius.circular(52.7),
                                              ),
                                              child: Container(
                                                width: 105.4,
                                                height: 105.4,
                                                padding: EdgeInsets.fromLTRB(4.5, 9.8, 4.5, 0),
                                                child: Container(
                                                  decoration: BoxDecoration(
                                                    color: Color(0xFF8778F8),
                                                    borderRadius: BorderRadius.circular(37.7),
                                                  ),
                                                  child: Container(
                                                    width: 75.3,
                                                    height: 75.3,
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                          SizedBox(
                                            width: 263.6,
                                            child: Column(
                                              mainAxisAlignment: MainAxisAlignment.start,
                                              crossAxisAlignment: CrossAxisAlignment.center,
                                              children: [
                                                Container(
                                                  margin: EdgeInsets.fromLTRB(0, 0, 0, 12),
                                                  child: SizedBox(
                                                    width: 263.6,
                                                    child: Row(
                                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                      children: [
                                                        Container(
                                                          width: 40.7,
                                                          height: 16.6,
                                                          child: Positioned(
                                                            right: 9.5,
                                                            bottom: -0.4,
                                                            child: SizedBox(
                                                              height: 17,
                                                              child: Text(
                                                                '9:41',
                                                                style: GoogleFonts.getFont(
                                                                  'Roboto Condensed',
                                                                  fontWeight: FontWeight.w400,
                                                                  fontSize: 12.8,
                                                                  height: 1.3,
                                                                  color: Color(0xFFFFFFFF),
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                        Container(
                                                          margin: EdgeInsets.fromLTRB(0, 3.1, 0, 3.7),
                                                          child: SizedBox(
                                                            width: 39.7,
                                                            child: Row(
                                                              mainAxisAlignment: MainAxisAlignment.start,
                                                              crossAxisAlignment: CrossAxisAlignment.start,
                                                              children: [
                                                                Container(
                                                                  margin: EdgeInsets.fromLTRB(0, 0.5, 5.8, 0.2),
                                                                  child: SizedBox(
                                                                    width: 12.8,
                                                                    height: 9.1,
                                                                    child: SvgPicture.asset(
                                                                      'assets/vectors/wifi_3_x2.svg',
                                                                    ),
                                                                  ),
                                                                ),
                                                                SizedBox(
                                                                  width: 21.1,
                                                                  height: 9.8,
                                                                  child: SvgPicture.asset(
                                                                    'assets/vectors/battery_1_x2.svg',
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ),
                                                Container(
                                                  margin: EdgeInsets.fromLTRB(0, 0, 0, 7.5),
                                                  child: SizedBox(
                                                    width: 263.6,
                                                    child: Row(
                                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                      children: [
                                                        Row(
                                                          mainAxisAlignment: MainAxisAlignment.start,
                                                          crossAxisAlignment: CrossAxisAlignment.start,
                                                          children: [
                                                            Container(
                                                              margin: EdgeInsets.fromLTRB(0, 0, 12, 0),
                                                              child: Container(
                                                                decoration: BoxDecoration(
                                                                  borderRadius: BorderRadius.circular(18.1),
                                                                  image: DecorationImage(
                                                                    fit: BoxFit.cover,
                                                                    image: AssetImage(
                                                                      'assets/images/ellipse_1.png',
                                                                    ),
                                                                  ),
                                                                ),
                                                                child: Container(
                                                                  width: 36.1,
                                                                  height: 36.1,
                                                                ),
                                                              ),
                                                            ),
                                                            Container(
                                                              margin: EdgeInsets.fromLTRB(0, 2.6, 0, 1),
                                                              child: Column(
                                                                mainAxisAlignment: MainAxisAlignment.start,
                                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                                children: [
                                                                  Container(
                                                                    margin: EdgeInsets.fromLTRB(1.4, 0, 1.4, 2.5),
                                                                    child: Align(
                                                                      alignment: Alignment.topLeft,
                                                                      child: Text(
                                                                        'Hi, Kretya!',
                                                                        style: GoogleFonts.getFont(
                                                                          'Poppins',
                                                                          fontWeight: FontWeight.w500,
                                                                          fontSize: 10.5,
                                                                          height: 1.4,
                                                                          letterSpacing: 0.2,
                                                                          color: Color(0xFFFFFFFF),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  Text(
                                                                    'Let’s traveling with us!',
                                                                    style: GoogleFonts.getFont(
                                                                      'Poppins',
                                                                      fontWeight: FontWeight.w400,
                                                                      fontSize: 9,
                                                                      height: 1.7,
                                                                      letterSpacing: 0.2,
                                                                      color: Color(0xFFDBDBDB),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                        Container(
                                                          margin: EdgeInsets.fromLTRB(0, 9.4, 0, 8.7),
                                                          child: SizedBox(
                                                            width: 18.1,
                                                            height: 18.1,
                                                            child: SvgPicture.asset(
                                                              'assets/vectors/notification_x2.svg',
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ),
                                                Container(
                                                  margin: EdgeInsets.fromLTRB(0, 0, 55.6, 0),
                                                  child: Row(
                                                    mainAxisAlignment: MainAxisAlignment.start,
                                                    crossAxisAlignment: CrossAxisAlignment.start,
                                                    children: [
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(0, 1.6, 5, 0.6),
                                                        width: 11.1,
                                                        height: 12.9,
                                                        child: SizedBox(
                                                          width: 11.1,
                                                          height: 12.9,
                                                          child: SvgPicture.asset(
                                                            'assets/vectors/vector_36_x2.svg',
                                                          ),
                                                        ),
                                                      ),
                                                      RichText(
                                                        text: TextSpan(
                                                          style: GoogleFonts.getFont(
                                                            'Poppins',
                                                            fontWeight: FontWeight.w400,
                                                            fontSize: 9,
                                                            height: 1.7,
                                                            letterSpacing: 0.2,
                                                            color: Color(0xFFDBDBDB),
                                                          ),
                                                          children: [
                                                            TextSpan(
                                                              text: 'Bandung, ',
                                                              style: GoogleFonts.getFont(
                                                                'Poppins',
                                                                fontWeight: FontWeight.w500,
                                                                fontSize: 9,
                                                                height: 1.3,
                                                                letterSpacing: 0.2,
                                                                color: Color(0xFFF3F3F3),
                                                              ),
                                                            ),
                                                            TextSpan(
                                                              text: 'Indonesia',
                                                              style: GoogleFonts.getFont(
                                                                'Poppins',
                                                                fontWeight: FontWeight.w400,
                                                                fontSize: 9,
                                                                height: 1.7,
                                                                letterSpacing: 0.2,
                                                                color: Color(0xFFDBDBDB),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  right: -10.5,
                                  top: 137.1,
                                  child: SizedBox(
                                    width: 284.7,
                                    height: 58.7,
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.start,
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Container(
                                          margin: EdgeInsets.fromLTRB(0, 0, 0, 0),
                                          child: Column(
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            crossAxisAlignment: CrossAxisAlignment.center,
                                            children: [
                                              Container(
                                                margin: EdgeInsets.fromLTRB(0, 0, 0, 6),
                                                decoration: BoxDecoration(
                                                  borderRadius: BorderRadius.circular(18.8),
                                                  gradient: LinearGradient(
                                                    begin: Alignment(0, -1),
                                                    end: Alignment(0, 1),
                                                    colors: <Color>[Color(0xFF594AC7), Color(0xFF7060E5)],
                                                    stops: <double>[0, 1],
                                                  ),
                                                  boxShadow: [
                                                    BoxShadow(
                                                      color: Color(0x737060E5),
                                                      offset: Offset(0, 1.5),
                                                      blurRadius: 3.7654128075,
                                                    ),
                                                  ],
                                                ),
                                                child: Container(
                                                  width: 37.7,
                                                  height: 37.7,
                                                  padding: EdgeInsets.fromLTRB(12.8, 12.8, 12, 12),
                                                  child: Container(
                                                    width: 12.8,
                                                    height: 12.8,
                                                    child: Container(
                                                      width: 12.8,
                                                      height: 12.8,
                                                      decoration: BoxDecoration(
                                                        boxShadow: [
                                                          BoxShadow(
                                                            color: Color(0x4D000000),
                                                            offset: Offset(-0.8, 2.3),
                                                            blurRadius: 1.8827064037,
                                                          ),
                                                        ],
                                                      ),
                                                      child: SvgPicture.asset(
                                                        'assets/vectors/vector_65_x2.svg',
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                margin: EdgeInsets.fromLTRB(2.7, 0, 1.3, 0),
                                                child: Text(
                                                  'Flights',
                                                  style: GoogleFonts.getFont(
                                                    'Poppins',
                                                    fontWeight: FontWeight.w400,
                                                    fontSize: 10.5,
                                                    height: 1.4,
                                                    letterSpacing: 0.2,
                                                    color: Color(0xFF121212),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Column(
                                          mainAxisAlignment: MainAxisAlignment.start,
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            Container(
                                              margin: EdgeInsets.fromLTRB(0, 0, 0, 6),
                                              decoration: BoxDecoration(
                                                borderRadius: BorderRadius.circular(18.8),
                                                gradient: LinearGradient(
                                                  begin: Alignment(0, -1),
                                                  end: Alignment(0, 1),
                                                  colors: <Color>[Color(0xFF594AC7), Color(0xFF7060E5)],
                                                  stops: <double>[0, 1],
                                                ),
                                                boxShadow: [
                                                  BoxShadow(
                                                    color: Color(0x737060E5),
                                                    offset: Offset(0, 1.5),
                                                    blurRadius: 3.7654128075,
                                                  ),
                                                ],
                                              ),
                                              child: Container(
                                                width: 37.7,
                                                height: 37.7,
                                                padding: EdgeInsets.fromLTRB(12.8, 11.6, 12.8, 11.7),
                                                child: Container(
                                                  width: 12,
                                                  height: 14.3,
                                                  child: Container(
                                                    width: 12,
                                                    height: 14.3,
                                                    decoration: BoxDecoration(
                                                      boxShadow: [
                                                        BoxShadow(
                                                          color: Color(0x4D000000),
                                                          offset: Offset(-0.8, 2.3),
                                                          blurRadius: 1.8827064037,
                                                        ),
                                                      ],
                                                    ),
                                                    child: SvgPicture.asset(
                                                      'assets/vectors/vector_23_x2.svg',
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Container(
                                              margin: EdgeInsets.fromLTRB(3, 0, 3.2, 0),
                                              child: Text(
                                                'Trains',
                                                style: GoogleFonts.getFont(
                                                  'Poppins',
                                                  fontWeight: FontWeight.w400,
                                                  fontSize: 10.5,
                                                  height: 1.4,
                                                  letterSpacing: 0.2,
                                                  color: Color(0xFF121212),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                        Column(
                                          mainAxisAlignment: MainAxisAlignment.start,
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            Container(
                                              margin: EdgeInsets.fromLTRB(0, 0, 0, 6),
                                              decoration: BoxDecoration(
                                                borderRadius: BorderRadius.circular(18.8),
                                                gradient: LinearGradient(
                                                  begin: Alignment(0, -1),
                                                  end: Alignment(0, 1),
                                                  colors: <Color>[Color(0xFF594AC7), Color(0xFF7060E5)],
                                                  stops: <double>[0, 1],
                                                ),
                                                boxShadow: [
                                                  BoxShadow(
                                                    color: Color(0x737060E5),
                                                    offset: Offset(0, 1.5),
                                                    blurRadius: 3.7654128075,
                                                  ),
                                                ],
                                              ),
                                              child: Container(
                                                width: 37.7,
                                                height: 37.7,
                                                padding: EdgeInsets.fromLTRB(12.8, 11.6, 12.8, 11.7),
                                                child: Container(
                                                  width: 12,
                                                  height: 14.3,
                                                  child: Container(
                                                    width: 12,
                                                    height: 14.3,
                                                    decoration: BoxDecoration(
                                                      boxShadow: [
                                                        BoxShadow(
                                                          color: Color(0x4D000000),
                                                          offset: Offset(-0.8, 2.3),
                                                          blurRadius: 1.8827064037,
                                                        ),
                                                      ],
                                                    ),
                                                    child: SvgPicture.asset(
                                                      'assets/vectors/vector_80_x2.svg',
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Container(
                                              margin: EdgeInsets.fromLTRB(9.8, 0, 9.4, 0),
                                              child: Text(
                                                'Bus',
                                                style: GoogleFonts.getFont(
                                                  'Poppins',
                                                  fontWeight: FontWeight.w400,
                                                  fontSize: 10.5,
                                                  height: 1.4,
                                                  letterSpacing: 0.2,
                                                  color: Color(0xFF121212),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                        Column(
                                          mainAxisAlignment: MainAxisAlignment.start,
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            Container(
                                              margin: EdgeInsets.fromLTRB(0, 0, 0, 6),
                                              decoration: BoxDecoration(
                                                borderRadius: BorderRadius.circular(18.8),
                                                gradient: LinearGradient(
                                                  begin: Alignment(0, -1),
                                                  end: Alignment(0, 1),
                                                  colors: <Color>[Color(0xFF594AC7), Color(0xFF7060E5)],
                                                  stops: <double>[0, 1],
                                                ),
                                                boxShadow: [
                                                  BoxShadow(
                                                    color: Color(0x737060E5),
                                                    offset: Offset(0, 1.5),
                                                    blurRadius: 3.7654128075,
                                                  ),
                                                ],
                                              ),
                                              child: Container(
                                                width: 37.7,
                                                height: 37.7,
                                                padding: EdgeInsets.fromLTRB(11.3, 12.8, 11.3, 12),
                                                child: Container(
                                                  width: 15.1,
                                                  height: 12.8,
                                                  child: Container(
                                                    width: 15.1,
                                                    height: 12.8,
                                                    decoration: BoxDecoration(
                                                      boxShadow: [
                                                        BoxShadow(
                                                          color: Color(0x4D000000),
                                                          offset: Offset(-0.8, 2.3),
                                                          blurRadius: 1.8827064037,
                                                        ),
                                                      ],
                                                    ),
                                                    child: SvgPicture.asset(
                                                      'assets/vectors/vector_42_x2.svg',
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Container(
                                              margin: EdgeInsets.fromLTRB(9.6, 0, 9.2, 0),
                                              child: Text(
                                                'Car',
                                                style: GoogleFonts.getFont(
                                                  'Poppins',
                                                  fontWeight: FontWeight.w400,
                                                  fontSize: 10.5,
                                                  height: 1.4,
                                                  letterSpacing: 0.2,
                                                  color: Color(0xFF121212),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                        Column(
                                          mainAxisAlignment: MainAxisAlignment.start,
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            Container(
                                              margin: EdgeInsets.fromLTRB(0, 0, 0, 6),
                                              decoration: BoxDecoration(
                                                borderRadius: BorderRadius.circular(18.8),
                                                gradient: LinearGradient(
                                                  begin: Alignment(0, -1),
                                                  end: Alignment(0, 1),
                                                  colors: <Color>[Color(0xFF594AC7), Color(0xFF7060E5)],
                                                  stops: <double>[0, 1],
                                                ),
                                                boxShadow: [
                                                  BoxShadow(
                                                    color: Color(0x737060E5),
                                                    offset: Offset(0, 1.5),
                                                    blurRadius: 3.7654128075,
                                                  ),
                                                ],
                                              ),
                                              child: Container(
                                                width: 37.7,
                                                height: 37.7,
                                                padding: EdgeInsets.fromLTRB(12.4, 12.4, 12.4, 11.3),
                                                child: Container(
                                                  width: 12.8,
                                                  height: 13.9,
                                                  child: Container(
                                                    width: 12.8,
                                                    height: 13.9,
                                                    decoration: BoxDecoration(
                                                      boxShadow: [
                                                        BoxShadow(
                                                          color: Color(0x4D000000),
                                                          offset: Offset(-0.8, 2.3),
                                                          blurRadius: 1.8827064037,
                                                        ),
                                                      ],
                                                    ),
                                                    child: SvgPicture.asset(
                                                      'assets/vectors/group_1_x2.svg',
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Container(
                                              margin: EdgeInsets.fromLTRB(4, 0, 3.6, 0),
                                              child: Text(
                                                'Motor',
                                                style: GoogleFonts.getFont(
                                                  'Poppins',
                                                  fontWeight: FontWeight.w400,
                                                  fontSize: 10.5,
                                                  height: 1.4,
                                                  letterSpacing: 0.2,
                                                  color: Color(0xFF121212),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                Positioned(
                                  right: -106.9,
                                  bottom: 15.4,
                                  child: SizedBox(
                                    width: 385.6,
                                    height: 244.4,
                                    child: Column(
                                      mainAxisAlignment: MainAxisAlignment.start,
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Container(
                                          margin: EdgeInsets.fromLTRB(0, 0, 0, 10.1),
                                          child: Align(
                                            alignment: Alignment.topLeft,
                                            child: SizedBox(
                                              width: 263.3,
                                              child: Row(
                                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    margin: EdgeInsets.fromLTRB(0, 0, 11.5, 0),
                                                    child: SizedBox(
                                                      width: 222,
                                                      child: Text(
                                                        'Special offer for you!',
                                                        style: GoogleFonts.getFont(
                                                          'Poppins',
                                                          fontWeight: FontWeight.w600,
                                                          fontSize: 15.1,
                                                          letterSpacing: 0.1,
                                                          color: Color(0xFF121212),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    margin: EdgeInsets.fromLTRB(0, 6.8, 0, 2.2),
                                                    child: Text(
                                                      'See all',
                                                      style: GoogleFonts.getFont(
                                                        'Poppins',
                                                        fontWeight: FontWeight.w400,
                                                        fontSize: 9,
                                                        letterSpacing: 0,
                                                        color: Color(0xFF7060E5),
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                        Container(
                                          margin: EdgeInsets.fromLTRB(0, 0, 0, 10.5),
                                          child: Align(
                                            alignment: Alignment.topLeft,
                                            child: Row(
                                              mainAxisAlignment: MainAxisAlignment.start,
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius: BorderRadius.circular(7.5),
                                                    color: Color(0xFF7060E5),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: Color(0x24000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 7.5308256149,
                                                      ),
                                                    ],
                                                  ),
                                                  child: Container(
                                                    padding: EdgeInsets.fromLTRB(7.5, 3, 8.3, 3),
                                                    child: Text(
                                                      'Train',
                                                      style: GoogleFonts.getFont(
                                                        'Poppins',
                                                        fontWeight: FontWeight.w500,
                                                        fontSize: 9,
                                                        letterSpacing: 0,
                                                        color: Color(0xFFEEEEEE),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius: BorderRadius.circular(7.5),
                                                    color: Color(0x1A7060E5),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: Color(0x1F000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 7.5308256149,
                                                      ),
                                                    ],
                                                  ),
                                                  child: Container(
                                                    padding: EdgeInsets.fromLTRB(7.5, 3, 8, 3),
                                                    child: Text(
                                                      'Bus & Travel',
                                                      style: GoogleFonts.getFont(
                                                        'Poppins',
                                                        fontWeight: FontWeight.w500,
                                                        fontSize: 9,
                                                        letterSpacing: 0,
                                                        color: Color(0xFF7060E5),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius: BorderRadius.circular(7.5),
                                                    color: Color(0x1A7060E5),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: Color(0x1F000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 7.5308256149,
                                                      ),
                                                    ],
                                                  ),
                                                  child: Container(
                                                    padding: EdgeInsets.fromLTRB(7.5, 3, 7.6, 3),
                                                    child: Text(
                                                      'Rent Car',
                                                      style: GoogleFonts.getFont(
                                                        'Poppins',
                                                        fontWeight: FontWeight.w500,
                                                        fontSize: 9,
                                                        letterSpacing: 0,
                                                        color: Color(0xFF7060E5),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                        Row(
                                          mainAxisAlignment: MainAxisAlignment.start,
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              decoration: BoxDecoration(
                                                borderRadius: BorderRadius.circular(7.5),
                                                color: Color(0xFFFFFFFF),
                                                boxShadow: [
                                                  BoxShadow(
                                                    color: Color(0x26000000),
                                                    offset: Offset(0, 3),
                                                    blurRadius: 7.5308256149,
                                                  ),
                                                ],
                                              ),
                                              child: Container(
                                                padding: EdgeInsets.fromLTRB(0, 0, 0, 15.2),
                                                child: Column(
                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    Container(
                                                      margin: EdgeInsets.fromLTRB(0, 0, 0, 4.5),
                                                      width: 120.5,
                                                      height: 120.5,
                                                      child: Positioned(
                                                        left: 0,
                                                        right: 0,
                                                        top: -6.8,
                                                        bottom: -23.3,
                                                        child: ClipRect(
                                                          child: BackdropFilter(
                                                            filter: ImageFilter.blur(
                                                              sigmaX: 1.5061651468,
                                                              sigmaY: 1.5061651468,
                                                            ),
                                                            child: Container(
                                                              decoration: BoxDecoration(
                                                                image: DecorationImage(
                                                                  fit: BoxFit.cover,
                                                                  image: AssetImage(
                                                                    'assets/images/gambar_1.png',
                                                                  ),
                                                                ),
                                                              ),
                                                              child: Container(
                                                                width: 120.5,
                                                                height: 150.6,
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      margin: EdgeInsets.fromLTRB(7.5, 0, 7.5, 2.6),
                                                      child: Align(
                                                        alignment: Alignment.topLeft,
                                                        child: Container(
                                                          child: Text(
                                                            'Bandung - Jakarta',
                                                            style: GoogleFonts.getFont(
                                                              'Poppins',
                                                              fontWeight: FontWeight.w600,
                                                              fontSize: 9,
                                                              color: Color(0xFF000000),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      margin: EdgeInsets.fromLTRB(7.5, 0, 7.5, 0),
                                                      child: Align(
                                                        alignment: Alignment.topLeft,
                                                        child: RichText(
                                                          text: TextSpan(
                                                            style: GoogleFonts.getFont(
                                                              'Poppins',
                                                              fontWeight: FontWeight.w400,
                                                              fontSize: 9,
                                                              height: 1.3,
                                                              letterSpacing: 0,
                                                              color: Color(0xFFFE7926),
                                                            ),
                                                            children: [
                                                              TextSpan(
                                                                text: 'Start from
                                                    ',
                                                                style: GoogleFonts.getFont(
                                                                  'Poppins',
                                                                  fontWeight: FontWeight.w500,
                                                                  fontSize: 9,
                                                                  height: 1.3,
                                                                  letterSpacing: 0,
                                                                ),
                                                              ),
                                                              TextSpan(
                                                                text: 'Rp45.000',
                                                                style: GoogleFonts.getFont(
                                                                  'Poppins',
                                                                  fontWeight: FontWeight.w500,
                                                                  fontSize: 9,
                                                                  height: 1.3,
                                                                  letterSpacing: 0,
                                                                  color: Color(0xFFFE7926),
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                            Container(
                                              decoration: BoxDecoration(
                                                borderRadius: BorderRadius.circular(7.5),
                                                color: Color(0xFFFFFFFF),
                                                boxShadow: [
                                                  BoxShadow(
                                                    color: Color(0x26000000),
                                                    offset: Offset(0, 3),
                                                    blurRadius: 7.5308256149,
                                                  ),
                                                ],
                                              ),
                                              child: Container(
                                                padding: EdgeInsets.fromLTRB(0, 0, 0, 15.2),
                                                child: Column(
                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    Container(
                                                      margin: EdgeInsets.fromLTRB(0, 0, 0, 4.5),
                                                      width: 120.5,
                                                      height: 120.5,
                                                      child: Positioned(
                                                        right: -45.2,
                                                        bottom: -9.8,
                                                        child: Container(
                                                          decoration: BoxDecoration(
                                                            image: DecorationImage(
                                                              fit: BoxFit.cover,
                                                              image: AssetImage(
                                                                'assets/images/image_9.png',
                                                              ),
                                                            ),
                                                          ),
                                                          child: Container(
                                                            width: 210.1,
                                                            height: 140.1,
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      margin: EdgeInsets.fromLTRB(7.5, 0, 6.9, 2.6),
                                                      width: 106,
                                                      height: 14,
                                                      child: Positioned(
                                                        bottom: 0,
                                                        child: SizedBox(
                                                          height: 14,
                                                          child: Text(
                                                            'Bandung - Yogyakarta',
                                                            style: GoogleFonts.getFont(
                                                              'Poppins',
                                                              fontWeight: FontWeight.w600,
                                                              fontSize: 9,
                                                              color: Color(0xFF000000),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      margin: EdgeInsets.fromLTRB(7.5, 0, 7.5, 0),
                                                      child: Align(
                                                        alignment: Alignment.topLeft,
                                                        child: RichText(
                                                          text: TextSpan(
                                                            style: GoogleFonts.getFont(
                                                              'Poppins',
                                                              fontWeight: FontWeight.w400,
                                                              fontSize: 9,
                                                              height: 1.3,
                                                              letterSpacing: 0,
                                                              color: Color(0xFFFE7926),
                                                            ),
                                                            children: [
                                                              TextSpan(
                                                                text: 'Start from
                                                    ',
                                                                style: GoogleFonts.getFont(
                                                                  'Poppins',
                                                                  fontWeight: FontWeight.w500,
                                                                  fontSize: 9,
                                                                  height: 1.3,
                                                                  letterSpacing: 0,
                                                                ),
                                                              ),
                                                              TextSpan(
                                                                text: 'Rp215.000',
                                                                style: GoogleFonts.getFont(
                                                                  'Poppins',
                                                                  fontWeight: FontWeight.w500,
                                                                  fontSize: 9,
                                                                  height: 1.3,
                                                                  letterSpacing: 0,
                                                                  color: Color(0xFFFE7926),
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                            Container(
                                              decoration: BoxDecoration(
                                                borderRadius: BorderRadius.circular(7.5),
                                                color: Color(0xFFFFFFFF),
                                                boxShadow: [
                                                  BoxShadow(
                                                    color: Color(0x26000000),
                                                    offset: Offset(0, 3),
                                                    blurRadius: 7.5308256149,
                                                  ),
                                                ],
                                              ),
                                              child: Container(
                                                padding: EdgeInsets.fromLTRB(0, 0, 0, 15.2),
                                                child: Column(
                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    Container(
                                                      margin: EdgeInsets.fromLTRB(0, 0, 0, 4.5),
                                                      width: 120.5,
                                                      height: 120.5,
                                                      child: Positioned(
                                                        left: -57.2,
                                                        top: -0.8,
                                                        child: Container(
                                                          decoration: BoxDecoration(
                                                            image: DecorationImage(
                                                              fit: BoxFit.cover,
                                                              image: AssetImage(
                                                                'assets/images/image_10.png',
                                                              ),
                                                            ),
                                                          ),
                                                          child: Container(
                                                            width: 234.2,
                                                            height: 121.2,
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      margin: EdgeInsets.fromLTRB(7.5, 0, 12.3, 2.6),
                                                      child: Text(
                                                        'Bandung - Semarang',
                                                        style: GoogleFonts.getFont(
                                                          'Poppins',
                                                          fontWeight: FontWeight.w600,
                                                          fontSize: 9,
                                                          color: Color(0xFF000000),
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      margin: EdgeInsets.fromLTRB(7.5, 0, 7.5, 0),
                                                      child: Align(
                                                        alignment: Alignment.topLeft,
                                                        child: RichText(
                                                          text: TextSpan(
                                                            style: GoogleFonts.getFont(
                                                              'Poppins',
                                                              fontWeight: FontWeight.w400,
                                                              fontSize: 9,
                                                              height: 1.3,
                                                              letterSpacing: 0,
                                                              color: Color(0xFFFE7926),
                                                            ),
                                                            children: [
                                                              TextSpan(
                                                                text: 'Start from
                                                    ',
                                                                style: GoogleFonts.getFont(
                                                                  'Poppins',
                                                                  fontWeight: FontWeight.w500,
                                                                  fontSize: 9,
                                                                  height: 1.3,
                                                                  letterSpacing: 0,
                                                                ),
                                                              ),
                                                              TextSpan(
                                                                text: 'Rp89.000',
                                                                style: GoogleFonts.getFont(
                                                                  'Poppins',
                                                                  fontWeight: FontWeight.w500,
                                                                  fontSize: 9,
                                                                  height: 1.3,
                                                                  letterSpacing: 0,
                                                                  color: Color(0xFFFE7926),
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                Positioned(
                                  right: -44.7,
                                  bottom: -10.3,
                                  child: Container(
                                    decoration: BoxDecoration(
                                      border: Border.all(color: Color(0xFFDEDEDE)),
                                      color: Color(0xFFFFFFFF),
                                      boxShadow: [
                                        BoxShadow(
                                          color: Color(0x1F000000),
                                          offset: Offset(0, -3),
                                          blurRadius: 7.5308256149,
                                        ),
                                      ],
                                    ),
                                    child: SizedBox(
                                      width: 293.7,
                                      height: 67.8,
                                      child: Container(
                                        padding: EdgeInsets.fromLTRB(22.1, 14.1, 22.1, 14.1),
                                        child: Stack(
                                          clipBehavior: Clip.none,
                                          children: [
                                            SizedBox(
                                              width: 174.4,
                                              child: Row(
                                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    margin: EdgeInsets.fromLTRB(0, 1.5, 0, 0),
                                                    child: Column(
                                                      mainAxisAlignment: MainAxisAlignment.start,
                                                      crossAxisAlignment: CrossAxisAlignment.center,
                                                      children: [
                                                        Container(
                                                          margin: EdgeInsets.fromLTRB(6.2, 0, 6.2, 4.5),
                                                          width: 15.1,
                                                          height: 15.1,
                                                          child: SizedBox(
                                                            width: 15.1,
                                                            height: 15.1,
                                                            child: SvgPicture.asset(
                                                              'assets/vectors/vector_12_x2.svg',
                                                            ),
                                                          ),
                                                        ),
                                                        Text(
                                                          'Home',
                                                          style: GoogleFonts.getFont(
                                                            'Poppins',
                                                            fontWeight: FontWeight.w600,
                                                            fontSize: 9,
                                                            height: 1.8,
                                                            color: Color(0xFF7060E5),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                  Container(
                                                    margin: EdgeInsets.fromLTRB(0, 1.5, 0, 0),
                                                    child: Column(
                                                      mainAxisAlignment: MainAxisAlignment.start,
                                                      crossAxisAlignment: CrossAxisAlignment.center,
                                                      children: [
                                                        Container(
                                                          margin: EdgeInsets.fromLTRB(9, 0, 9, 4.5),
                                                          width: 12.8,
                                                          height: 15.1,
                                                          child: SizedBox(
                                                            width: 12.8,
                                                            height: 15.1,
                                                            child: SvgPicture.asset(
                                                              'assets/vectors/vector_83_x2.svg',
                                                            ),
                                                          ),
                                                        ),
                                                        Text(
                                                          'History',
                                                          style: GoogleFonts.getFont(
                                                            'Poppins',
                                                            fontWeight: FontWeight.w400,
                                                            fontSize: 9,
                                                            height: 1.8,
                                                            color: Color(0xFF8C8C8C),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                  Column(
                                                    mainAxisAlignment: MainAxisAlignment.start,
                                                    crossAxisAlignment: CrossAxisAlignment.center,
                                                    children: [
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(4.1, 0, 4.1, 3),
                                                        child: SizedBox(
                                                          width: 18.1,
                                                          height: 18.1,
                                                          child: SvgPicture.asset(
                                                            'assets/vectors/iconsax_linearticket_2_x2.svg',
                                                          ),
                                                        ),
                                                      ),
                                                      Text(
                                                        'Ticket',
                                                        style: GoogleFonts.getFont(
                                                          'Poppins',
                                                          fontWeight: FontWeight.w400,
                                                          fontSize: 9,
                                                          height: 1.8,
                                                          color: Color(0xFF8C8C8C),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Positioned(
                                              right: -0.1,
                                              bottom: 0.8,
                                              child: SizedBox(
                                                width: 27.5,
                                                height: 36.6,
                                                child: Column(
                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                  children: [
                                                    Container(
                                                      margin: EdgeInsets.fromLTRB(8.7, 0, 8.5, 4.7),
                                                      width: 10.3,
                                                      height: 14.9,
                                                      child: SizedBox(
                                                        width: 10.3,
                                                        height: 14.9,
                                                        child: SvgPicture.asset(
                                                          'assets/vectors/vector_43_x2.svg',
                                                        ),
                                                      ),
                                                    ),
                                                    Text(
                                                      'Profile',
                                                      style: GoogleFonts.getFont(
                                                        'Poppins',
                                                        fontWeight: FontWeight.w400,
                                                        fontSize: 9,
                                                        height: 1.8,
                                                        color: Color(0xFF8C8C8C),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  left: 22.6,
                                  bottom: -17.3,
                                  child: Container(
                                    width: 26.4,
                                    height: 25.6,
                                    decoration: BoxDecoration(
                                      boxShadow: [
                                        BoxShadow(
                                          color: Color(0x337060E5),
                                          offset: Offset(0, -3),
                                          blurRadius: 7.5308256149,
                                        ),
                                        BoxShadow(
                                          color: Color(0x40000000),
                                          offset: Offset(0, 3),
                                          blurRadius: 1.5061651468,
                                        ),
                                      ],
                                    ),
                                    child: SvgPicture.asset(
                                      'assets/vectors/ellipse_16_x2.svg',
                                    ),
                                  ),
                                ),
                                Positioned(
                                  right: -106.9,
                                  top: 209.4,
                                  child: SizedBox(
                                    width: 385.6,
                                    height: 152.9,
                                    child: Column(
                                      mainAxisAlignment: MainAxisAlignment.start,
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Container(
                                          margin: EdgeInsets.fromLTRB(0, 0, 0, 10.1),
                                          child: Align(
                                            alignment: Alignment.topLeft,
                                            child: SizedBox(
                                              width: 263.5,
                                              child: Row(
                                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    margin: EdgeInsets.fromLTRB(0, 0, 11.5, 0),
                                                    child: SizedBox(
                                                      width: 222.1,
                                                      child: Text(
                                                        'Most Popular Destination',
                                                        style: GoogleFonts.getFont(
                                                          'Poppins',
                                                          fontWeight: FontWeight.w600,
                                                          fontSize: 15.1,
                                                          letterSpacing: 0.1,
                                                          color: Color(0xFF121212),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    margin: EdgeInsets.fromLTRB(0, 6.8, 0, 2.2),
                                                    child: Text(
                                                      'See all',
                                                      style: GoogleFonts.getFont(
                                                        'Poppins',
                                                        fontWeight: FontWeight.w400,
                                                        fontSize: 9,
                                                        letterSpacing: 0,
                                                        color: Color(0xFF6B5CDF),
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                        Row(
                                          mainAxisAlignment: MainAxisAlignment.start,
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              decoration: BoxDecoration(
                                                borderRadius: BorderRadius.circular(7.5),
                                                color: Color(0xFFFFFFFF),
                                                boxShadow: [
                                                  BoxShadow(
                                                    color: Color(0x24000000),
                                                    offset: Offset(0, 3),
                                                    blurRadius: 11.2962379456,
                                                  ),
                                                ],
                                              ),
                                              child: Stack(
                                                children: [
                                                  Positioned(
                                                    left: 0,
                                                    right: 0,
                                                    top: 0,
                                                    bottom: 0,
                                                    child: Container(
                                                      decoration: BoxDecoration(
                                                        gradient: LinearGradient(
                                                          begin: Alignment(0, -1),
                                                          end: Alignment(0, 1),
                                                          colors: <Color>[Color(0xFF000000), Color(0xFF000000)],
                                                          stops: <double>[0, 1],
                                                        ),
                                                      ),
                                                      child: Container(
                                                        width: 120.5,
                                                        height: 119.7,
                                                        child: Container(
                                                          decoration: BoxDecoration(
                                                            gradient: LinearGradient(
                                                              begin: Alignment(0, 0.088),
                                                              end: Alignment(0, 1),
                                                              colors: <Color>[Color(0x00000000), Color(0xFF000000)],
                                                              stops: <double>[0, 1],
                                                            ),
                                                          ),
                                                          child: Container(
                                                            width: 120.5,
                                                            height: 119.7,
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                            Container(
                                                    padding: EdgeInsets.fromLTRB(0, 0.8, 0, 7.8),
                                                    child: Column(
                                                      mainAxisAlignment: MainAxisAlignment.start,
                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                      children: [
                                                        Container(
                                                          margin: EdgeInsets.fromLTRB(0, 0, 0, 35.4),
                                                          child: Row(
                                                            mainAxisAlignment: MainAxisAlignment.start,
                                                            crossAxisAlignment: CrossAxisAlignment.start,
                                                            children: [
                                                              Container(
                                                                margin: EdgeInsets.fromLTRB(0, 0, 23.3, 0),
                                                                child: Container(
                                                                  decoration: BoxDecoration(
                                                                    image: DecorationImage(
                                                                      fit: BoxFit.cover,
                                                                      image: AssetImage(
                                                                        'assets/images/air_asia_1.png',
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  child: Container(
                                                                    width: 52,
                                                                    height: 35.4,
                                                                  ),
                                                                ),
                                                              ),
                                                              Container(
                                                                margin: EdgeInsets.fromLTRB(0, 10.5, 0, 9.8),
                                                                child: Container(
                                                                  decoration: BoxDecoration(
                                                                    color: Color(0xFF7060E5),
                                                                    borderRadius: BorderRadius.only(
                                                                      topLeft: Radius.circular(4.5),
                                                                      bottomLeft: Radius.circular(4.5),
                                                                    ),
                                                                  ),
                                                                  child: Container(
                                                                    padding: EdgeInsets.fromLTRB(5.3, 0.8, 6.1, 0.3),
                                                                    child: Text(
                                                                      'IDR 1.9jt',
                                                                      style: GoogleFonts.getFont(
                                                                        'Poppins',
                                                                        fontWeight: FontWeight.w500,
                                                                        fontSize: 9,
                                                                        color: Color(0xFFFFFFFF),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                        Container(
                                                          margin: EdgeInsets.fromLTRB(7.5, 0, 7.5, 1.8),
                                                          child: Align(
                                                            alignment: Alignment.topLeft,
                                                            child: Column(
                                                              mainAxisAlignment: MainAxisAlignment.start,
                                                              crossAxisAlignment: CrossAxisAlignment.start,
                                                              children: [
                                                                Align(
                                                                  alignment: Alignment.topLeft,
                                                                  child: Text(
                                                                    'Bandung',
                                                                    style: GoogleFonts.getFont(
                                                                      'Poppins',
                                                                      fontWeight: FontWeight.w600,
                                                                      fontSize: 9,
                                                                      color: Color(0xFFFFFFFF),
                                                                    ),
                                                                  ),
                                                                ),
                                                                Container(
                                                                  margin: EdgeInsets.fromLTRB(1.9, 0, 0, 0),
                                                                  child: Row(
                                                                    mainAxisAlignment: MainAxisAlignment.start,
                                                                    crossAxisAlignment: CrossAxisAlignment.start,
                                                                    children: [
                                                                      Container(
                                                                        margin: EdgeInsets.fromLTRB(0, 2.3, 7.2, 2.6),
                                                                        width: 8.2,
                                                                        height: 9.1,
                                                                        child: SizedBox(
                                                                          width: 8.2,
                                                                          height: 9.1,
                                                                          child: SvgPicture.asset(
                                                                            'assets/vectors/swap_5_x2.svg',
                                                                          ),
                                                                        ),
                                                                      ),
                                                                      Text(
                                                                        'Bali/Denpasar',
                                                                        style: GoogleFonts.getFont(
                                                                          'Poppins',
                                                                          fontWeight: FontWeight.w600,
                                                                          fontSize: 9,
                                                                          color: Color(0xFFFFFFFF),
                                                                        ),
                                                                      ),
                                                                    ],
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                        Container(
                                                          margin: EdgeInsets.fromLTRB(7.5, 0, 7.5, 0),
                                                          child: Align(
                                                            alignment: Alignment.topLeft,
                                                            child: Text(
                                                              '9 - 18 Januari 2023',
                                                              style: GoogleFonts.getFont(
                                                                'Poppins',
                                                                fontWeight: FontWeight.w300,
                                                                fontSize: 7.5,
                                                                color: Color(0xFFFFFFFF),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Container(
                                              decoration: BoxDecoration(
                                                borderRadius: BorderRadius.circular(7.5),
                                                color: Color(0xFFFFFFFF),
                                                boxShadow: [
                                                  BoxShadow(
                                                    color: Color(0x24000000),
                                                    offset: Offset(0, 3),
                                                    blurRadius: 11.2962379456,
                                                  ),
                                                ],
                                              ),
                                              child: Stack(
                                                children: [
                                                  Positioned(
                                                    right: -72.3,
                                                    top: -11.3,
                                                    child: Container(
                                                      decoration: BoxDecoration(
                                                        image: DecorationImage(
                                                          fit: BoxFit.cover,
                                                          image: AssetImage(
                                                            'assets/images/image_121.png',
                                                          ),
                                                        ),
                                                      ),
                                                      child: Container(
                                                        width: 192.8,
                                                        height: 119.7,
                                                      ),
                                                    ),
                                                  ),
                                                  Positioned(
                                                    left: -7.5,
                                                    right: 0,
                                                    top: -11.3,
                                                    bottom: -7.8,
                                                    child: Container(
                                                      decoration: BoxDecoration(
                                                        gradient: LinearGradient(
                                                          begin: Alignment(0, 0.088),
                                                          end: Alignment(0, 1),
                                                          colors: <Color>[Color(0x00000000), Color(0xFF000000)],
                                                          stops: <double>[0, 1],
                                                        ),
                                                      ),
                                                      child: Container(
                                                        width: 120.5,
                                                        height: 119.7,
                                                      ),
                                                    ),
                                                  ),
                                            Container(
                                                    padding: EdgeInsets.fromLTRB(7.5, 11.3, 0, 7.8),
                                                    child: Column(
                                                      mainAxisAlignment: MainAxisAlignment.start,
                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                      children: [
                                                        Container(
                                                          margin: EdgeInsets.fromLTRB(0, 0, 0, 45.2),
                                                          child: SizedBox(
                                                            width: 113,
                                                            child: Row(
                                                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                              crossAxisAlignment: CrossAxisAlignment.start,
                                                              children: [
                                                                Container(
                                                                  margin: EdgeInsets.fromLTRB(0, 0, 0, 1.1),
                                                                  width: 37.7,
                                                                  height: 14,
                                                                  child: Container(
                                                                    decoration: BoxDecoration(
                                                                      image: DecorationImage(
                                                                        image: AssetImage(
                                                                          'assets/images/logo_citilink_by_kampungdesigner_1.png',
                                                                        ),
                                                                      ),
                                                                    ),
                                                                    child: Container(
                                                                      width: 37.7,
                                                                      height: 14,
                                                                    ),
                                                                  ),
                                                                ),
                                                                Container(
                                                                  decoration: BoxDecoration(
                                                                    color: Color(0xFF7060E5),
                                                                    borderRadius: BorderRadius.only(
                                                                      topLeft: Radius.circular(4.5),
                                                                      bottomLeft: Radius.circular(4.5),
                                                                    ),
                                                                  ),
                                                                  child: Container(
                                                                    padding: EdgeInsets.fromLTRB(5.3, 0.8, 6.1, 0.3),
                                                                    child: Text(
                                                                      'IDR 1.5jt',
                                                                      style: GoogleFonts.getFont(
                                                                        'Poppins',
                                                                        fontWeight: FontWeight.w500,
                                                                        fontSize: 9,
                                                                        color: Color(0xFFFFFFFF),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                        Container(
                                                          margin: EdgeInsets.fromLTRB(4.5, 0, 4.5, 1.8),
                                                          child: Align(
                                                            alignment: Alignment.topLeft,
                                                            child: Column(
                                                              mainAxisAlignment: MainAxisAlignment.start,
                                                              crossAxisAlignment: CrossAxisAlignment.start,
                                                              children: [
                                                                Align(
                                                                  alignment: Alignment.topLeft,
                                                                  child: Text(
                                                                    'Jakarta',
                                                                    style: GoogleFonts.getFont(
                                                                      'Poppins',
                                                                      fontWeight: FontWeight.w600,
                                                                      fontSize: 9,
                                                                      color: Color(0xFFFFFFFF),
                                                                    ),
                                                                  ),
                                                                ),
                                                                Container(
                                                                  margin: EdgeInsets.fromLTRB(1.9, 0, 0, 0),
                                                                  child: Row(
                                                                    mainAxisAlignment: MainAxisAlignment.start,
                                                                    crossAxisAlignment: CrossAxisAlignment.start,
                                                                    children: [
                                                                      Container(
                                                                        margin: EdgeInsets.fromLTRB(0, 2.3, 7.2, 2.6),
                                                                        width: 8.2,
                                                                        height: 9.1,
                                                                        child: SizedBox(
                                                                          width: 8.2,
                                                                          height: 9.1,
                                                                          child: SvgPicture.asset(
                                                                            'assets/vectors/swap_11_x2.svg',
                                                                          ),
                                                                        ),
                                                                      ),
                                                                      Text(
                                                                        'Singapore',
                                                                        style: GoogleFonts.getFont(
                                                                          'Poppins',
                                                                          fontWeight: FontWeight.w600,
                                                                          fontSize: 9,
                                                                          color: Color(0xFFFFFFFF),
                                                                        ),
                                                                      ),
                                                                    ],
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                        Container(
                                                          margin: EdgeInsets.fromLTRB(4.5, 0, 4.5, 0),
                                                          child: Align(
                                                            alignment: Alignment.topLeft,
                                                            child: Text(
                                                              '4 - 15 Februari 2023',
                                                              style: GoogleFonts.getFont(
                                                                'Poppins',
                                                                fontWeight: FontWeight.w300,
                                                                fontSize: 7.5,
                                                                color: Color(0xFFFFFFFF),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Container(
                                              decoration: BoxDecoration(
                                                borderRadius: BorderRadius.circular(7.5),
                                                image: DecorationImage(
                                                  image: AssetImage(
                                                    'assets/images/image_13.png',
                                                  ),
                                                ),
                                              ),
                                              child: Stack(
                                                children: [
                                                  Positioned(
                                                    left: -7.5,
                                                    right: 0,
                                                    top: -11.3,
                                                    bottom: -7.8,
                                                    child: Container(
                                                      decoration: BoxDecoration(
                                                        gradient: LinearGradient(
                                                          begin: Alignment(0, 0.088),
                                                          end: Alignment(0, 1),
                                                          colors: <Color>[Color(0x00000000), Color(0xFF000000)],
                                                          stops: <double>[0, 1],
                                                        ),
                                                      ),
                                                      child: Container(
                                                        width: 120.5,
                                                        height: 119.7,
                                                      ),
                                                    ),
                                                  ),
                                            Container(
                                                    padding: EdgeInsets.fromLTRB(7.5, 11.3, 0, 7.8),
                                                    child: Column(
                                                      mainAxisAlignment: MainAxisAlignment.start,
                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                      children: [
                                                        Container(
                                                          margin: EdgeInsets.fromLTRB(0, 0, 0, 45.2),
                                                          child: SizedBox(
                                                            width: 113,
                                                            child: Row(
                                                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                              crossAxisAlignment: CrossAxisAlignment.start,
                                                              children: [
                                                                Container(
                                                                  margin: EdgeInsets.fromLTRB(0, 1.5, 0, 1.5),
                                                                  child: Container(
                                                                    decoration: BoxDecoration(
                                                                      image: DecorationImage(
                                                                        fit: BoxFit.cover,
                                                                        image: AssetImage(
                                                                          'assets/images/logo_batik_air_1.png',
                                                                        ),
                                                                      ),
                                                                    ),
                                                                    child: Container(
                                                                      width: 44.4,
                                                                      height: 12,
                                                                    ),
                                                                  ),
                                                                ),
                                                                Container(
                                                                  decoration: BoxDecoration(
                                                                    color: Color(0xFF7060E5),
                                                                    borderRadius: BorderRadius.only(
                                                                      topLeft: Radius.circular(4.5),
                                                                      bottomLeft: Radius.circular(4.5),
                                                                    ),
                                                                  ),
                                                                  child: Container(
                                                                    padding: EdgeInsets.fromLTRB(4.5, 0.8, 5.4, 0.3),
                                                                    child: Text(
                                                                      'IDR 7jt',
                                                                      style: GoogleFonts.getFont(
                                                                        'Poppins',
                                                                        fontWeight: FontWeight.w500,
                                                                        fontSize: 9,
                                                                        color: Color(0xFFFFFFFF),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                        Container(
                                                          margin: EdgeInsets.fromLTRB(4.5, 0, 4.5, 1.8),
                                                          child: Align(
                                                            alignment: Alignment.topLeft,
                                                            child: Column(
                                                              mainAxisAlignment: MainAxisAlignment.start,
                                                              crossAxisAlignment: CrossAxisAlignment.center,
                                                              children: [
                                                                Container(
                                                                  margin: EdgeInsets.fromLTRB(0, 0, 8.8, 0),
                                                                  child: Text(
                                                                    'Jakarta',
                                                                    style: GoogleFonts.getFont(
                                                                      'Poppins',
                                                                      fontWeight: FontWeight.w600,
                                                                      fontSize: 9,
                                                                      color: Color(0xFFFFFFFF),
                                                                    ),
                                                                  ),
                                                                ),
                                                                Container(
                                                                  margin: EdgeInsets.fromLTRB(1.9, 0, 0, 0),
                                                                  child: Row(
                                                                    mainAxisAlignment: MainAxisAlignment.start,
                                                                    crossAxisAlignment: CrossAxisAlignment.start,
                                                                    children: [
                                                                      Container(
                                                                        margin: EdgeInsets.fromLTRB(0, 3.1, 7.2, 1.9),
                                                                        width: 8.2,
                                                                        height: 9.1,
                                                                        child: SizedBox(
                                                                          width: 8.2,
                                                                          height: 9.1,
                                                                          child: SvgPicture.asset(
                                                                            'assets/vectors/swap_3_x2.svg',
                                                                          ),
                                                                        ),
                                                                      ),
                                                                      Text(
                                                                        'Tokyo',
                                                                        style: GoogleFonts.getFont(
                                                                          'Poppins',
                                                                          fontWeight: FontWeight.w600,
                                                                          fontSize: 9,
                                                                          color: Color(0xFFFFFFFF),
                                                                        ),
                                                                      ),
                                                                    ],
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                        Container(
                                                          margin: EdgeInsets.fromLTRB(4.5, 0, 4.5, 0),
                                                          child: Align(
                                                            alignment: Alignment.topLeft,
                                                            child: Text(
                                                              '3 - 20 Maret 2023',
                                                              style: GoogleFonts.getFont(
                                                                'Poppins',
                                                                fontWeight: FontWeight.w300,
                                                                fontSize: 7.5,
                                                                color: Color(0xFFFFFFFF),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}