import 'package:flutter/material.dart';
import 'dart:ui';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_app/utils.dart';
import 'package:google_fonts/google_fonts.dart';

class Schedule extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return 
    Container(
      decoration: BoxDecoration(
        color: Color(0xFFFFFFFF),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Stack(
        children: [
          SizedBox(
            width: 503,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  margin: EdgeInsets.fromLTRB(0, 0, 0, 20),
                  child: Stack(
                    children: [
                      SizedBox(
                        width: double.infinity,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Expanded(
                              child: Container(
                                margin: EdgeInsets.fromLTRB(0, 0, 12, 0),
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: Color(0xFF7060E5),
                                    borderRadius: BorderRadius.circular(20),
                                  ),
                                  child: Container(
                                    padding: EdgeInsets.fromLTRB(23.5, 14, 20, 12),
                                    child: Stack(
                                      clipBehavior: Clip.none,
                                      children: [
                                        Positioned(
                                          left: -56.5,
                                          top: -79,
                                          child: Container(
                                            decoration: BoxDecoration(
                                              color: Color(0xFF7868EC),
                                              borderRadius: BorderRadius.circular(83.5),
                                            ),
                                            child: Container(
                                              width: 167,
                                              height: 167,
                                            ),
                                          ),
                                        ),
                                        Positioned(
                                          left: -81.5,
                                          top: -74,
                                          child: Container(
                                            decoration: BoxDecoration(
                                              color: Color(0xFF7F6FF2),
                                              borderRadius: BorderRadius.circular(70),
                                            ),
                                            child: Container(
                                              width: 140,
                                              height: 140,
                                              padding: EdgeInsets.fromLTRB(6, 13, 6, 0),
                                              child: Container(
                                                decoration: BoxDecoration(
                                                  color: Color(0xFF8778F8),
                                                  borderRadius: BorderRadius.circular(50),
                                                ),
                                                child: Container(
                                                  width: 100,
                                                  height: 100,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        SizedBox(
                                          width: double.infinity,
                                          child: Column(
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            crossAxisAlignment: CrossAxisAlignment.center,
                                            children: [
                                              Container(
                                                margin: EdgeInsets.fromLTRB(8.9, 0, 0, 17),
                                                child: Row(
                                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    Container(
                                                      child: Text(
                                                        '9:41',
                                                        style: GoogleFonts.getFont(
                                                          'Roboto Condensed',
                                                          fontWeight: FontWeight.w400,
                                                          fontSize: 17,
                                                          height: 1.3,
                                                          color: Color(0xFFEEEEEE),
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      margin: EdgeInsets.fromLTRB(0, 4.1, 0, 4.9),
                                                      child: SizedBox(
                                                        width: 52.7,
                                                        child: Row(
                                                          mainAxisAlignment: MainAxisAlignment.start,
                                                          crossAxisAlignment: CrossAxisAlignment.start,
                                                          children: [
                                                            Container(
                                                              margin: EdgeInsets.fromLTRB(0, 0.6, 7.6, 0.3),
                                                              child: SizedBox(
                                                                width: 17,
                                                                height: 12.1,
                                                                child: SvgPicture.asset(
                                                                  'assets/vectors/wifi_1_x2.svg',
                                                                ),
                                                              ),
                                                            ),
                                                            SizedBox(
                                                              width: 28,
                                                              height: 13,
                                                              child: SvgPicture.asset(
                                                                'assets/vectors/battery_3_x2.svg',
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              Container(
                                                margin: EdgeInsets.fromLTRB(0, 0, 0, 23),
                                                child: Row(
                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    Container(
                                                      margin: EdgeInsets.fromLTRB(0, 16.5, 24, 16),
                                                      width: 16.5,
                                                      height: 13.5,
                                                      child: Container(
                                                        width: 16.5,
                                                        height: 13.5,
                                                        child: SizedBox(
                                                          width: 16.5,
                                                          height: 13.5,
                                                          child: SvgPicture.asset(
                                                            'assets/vectors/combined_shape_4_x2.svg',
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Expanded(
                                                      child: Container(
                                                        margin: EdgeInsets.fromLTRB(0, 0, 45.5, 0),
                                                        child: Column(
                                                          mainAxisAlignment: MainAxisAlignment.start,
                                                          crossAxisAlignment: CrossAxisAlignment.center,
                                                          children: [
                                                            Container(
                                                              margin: EdgeInsets.fromLTRB(0, 0, 0.3, 6),
                                                              child: Text(
                                                                'Bandung to Denpasar',
                                                                style: GoogleFonts.getFont(
                                                                  'Poppins',
                                                                  fontWeight: FontWeight.w500,
                                                                  fontSize: 18,
                                                                  height: 1.2,
                                                                  color: Color(0xFFFFFFFF),
                                                                ),
                                                              ),
                                                            ),
                                                            Row(
                                                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                              crossAxisAlignment: CrossAxisAlignment.start,
                                                              children: [
                                                                Container(
                                                                  margin: EdgeInsets.fromLTRB(0, 0, 10.9, 0),
                                                                  child: Text(
                                                                    'Sun, 9 Jan 23 ',
                                                                    style: GoogleFonts.getFont(
                                                                      'Poppins',
                                                                      fontWeight: FontWeight.w400,
                                                                      fontSize: 12,
                                                                      color: Color(0xFFFFFFFF),
                                                                    ),
                                                                  ),
                                                                ),
                                                                Expanded(
                                                                  child: Container(
                                                                    margin: EdgeInsets.fromLTRB(0, 2, 0, 2),
                                                                    child: Row(
                                                                      mainAxisAlignment: MainAxisAlignment.start,
                                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                                      children: [
                                                                        Container(
                                                                          margin: EdgeInsets.fromLTRB(0, 4.5, 12, 4.5),
                                                                          child: Container(
                                                                            decoration: BoxDecoration(
                                                                              color: Color(0xFFFFFFFF),
                                                                              borderRadius: BorderRadius.circular(2.5),
                                                                            ),
                                                                            child: Container(
                                                                              width: 5,
                                                                              height: 5,
                                                                            ),
                                                                          ),
                                                                        ),
                                                                        Container(
                                                                          margin: EdgeInsets.fromLTRB(0, 0, 10.3, 0),
                                                                          child: Row(
                                                                            mainAxisAlignment: MainAxisAlignment.start,
                                                                            crossAxisAlignment: CrossAxisAlignment.start,
                                                                            children: [
                                                                              Container(
                                                                                margin: EdgeInsets.fromLTRB(0, 2, 4, 2),
                                                                                width: 8,
                                                                                height: 10,
                                                                                child: SizedBox(
                                                                                  width: 8,
                                                                                  height: 10,
                                                                                  child: SvgPicture.asset(
                                                                                    'assets/vectors/vector_6_x2.svg',
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                              Text(
                                                                                '1',
                                                                                style: GoogleFonts.getFont(
                                                                                  'Roboto',
                                                                                  fontWeight: FontWeight.w400,
                                                                                  fontSize: 12,
                                                                                  color: Color(0xFFFFFFFF),
                                                                                ),
                                                                              ),
                                                                            ],
                                                                          ),
                                                                        ),
                                                                        Container(
                                                                          margin: EdgeInsets.fromLTRB(0, 4.5, 10, 4.5),
                                                                          child: Container(
                                                                            decoration: BoxDecoration(
                                                                              color: Color(0xFFFFFFFF),
                                                                              borderRadius: BorderRadius.circular(2.5),
                                                                            ),
                                                                            child: Container(
                                                                              width: 5,
                                                                              height: 5,
                                                                            ),
                                                                          ),
                                                                        ),
                                                                        Container(
                                                                          child: Text(
                                                                            'Economy',
                                                                            style: GoogleFonts.getFont(
                                                                              'Roboto',
                                                                              fontWeight: FontWeight.w400,
                                                                              fontSize: 12,
                                                                              color: Color(0xFFFFFFFF),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                    Expanded(
                                                      child: Container(
                                                        margin: EdgeInsets.fromLTRB(0, 12, 0, 11),
                                                        child: Container(
                                                          decoration: BoxDecoration(
                                                            color: Color(0x33FFFFFF),
                                                            borderRadius: BorderRadius.circular(10),
                                                          ),
                                                          child: Container(
                                                            padding: EdgeInsets.fromLTRB(10, 4, 10.3, 4),
                                                            child: Text(
                                                              'Change',
                                                              style: GoogleFonts.getFont(
                                                                'Poppins',
                                                                fontWeight: FontWeight.w500,
                                                                fontSize: 10,
                                                                letterSpacing: 0.1,
                                                                color: Color(0xFFFFFFFF),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              Container(
                                                margin: EdgeInsets.fromLTRB(14.5, 0, 18, 12),
                                                child: Row(
                                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    Expanded(
                                                      child: Container(
                                                        margin: EdgeInsets.fromLTRB(0, 0, 7, 0),
                                                        child: Container(
                                                          decoration: BoxDecoration(
                                                            color: Color(0x33FFFFFF),
                                                            borderRadius: BorderRadius.circular(10),
                                                          ),
                                                          child: Container(
                                                            padding: EdgeInsets.fromLTRB(12.1, 14, 14.1, 16),
                                                            child: RichText(
                                                              textAlign: TextAlign.center,
                                                              text: TextSpan(
                                                                style: GoogleFonts.getFont(
                                                                  'Roboto',
                                                                  fontWeight: FontWeight.w400,
                                                                  fontSize: 14,
                                                                  color: Color(0xFF6D6D6D),
                                                                ),
                                                                children: [
                                                                  TextSpan(
                                                                    text: 'Sat, 8 Jan
                                                            ',
                                                                    style: GoogleFonts.getFont(
                                                                      'Roboto',
                                                                      fontWeight: FontWeight.w600,
                                                                      fontSize: 14,
                                                                      height: 1.3,
                                                                      color: Color(0xFFFFFFFF),
                                                                    ),
                                                                  ),
                                                                  TextSpan(
                                                                    text: 'Rp. 1.040.000',
                                                                    style: GoogleFonts.getFont(
                                                                      'Roboto',
                                                                      fontWeight: FontWeight.w400,
                                                                      fontSize: 12,
                                                                      height: 1.3,
                                                                      color: Color(0xFFFFFFFF),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Expanded(
                                                      child: Container(
                                                        margin: EdgeInsets.fromLTRB(0, 0, 7, 0),
                                                        child: Container(
                                                          decoration: BoxDecoration(
                                                            color: Color(0xFFFFFFFF),
                                                            borderRadius: BorderRadius.circular(10),
                                                          ),
                                                          child: Container(
                                                            padding: EdgeInsets.fromLTRB(12, 14, 14, 16),
                                                            child: RichText(
                                                              textAlign: TextAlign.center,
                                                              text: TextSpan(
                                                                style: GoogleFonts.getFont(
                                                                  'Roboto',
                                                                  fontWeight: FontWeight.w400,
                                                                  fontSize: 14,
                                                                  color: Color(0xFF7060E5),
                                                                ),
                                                                children: [
                                                                  TextSpan(
                                                                    text: 'Sun, 9 Jan
                                                            ',
                                                                    style: GoogleFonts.getFont(
                                                                      'Roboto',
                                                                      fontWeight: FontWeight.w600,
                                                                      fontSize: 14,
                                                                      height: 1.3,
                                                                      color: Color(0xFF7060E5),
                                                                    ),
                                                                  ),
                                                                  TextSpan(
                                                                    text: 'Rp. 955.000',
                                                                    style: GoogleFonts.getFont(
                                                                      'Roboto',
                                                                      fontWeight: FontWeight.w400,
                                                                      fontSize: 12,
                                                                      height: 1.3,
                                                                      color: Color(0xFF7060E5),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Expanded(
                                                      child: Container(
                                                        decoration: BoxDecoration(
                                                          color: Color(0x33FFFFFF),
                                                          borderRadius: BorderRadius.circular(10),
                                                        ),
                                                        child: Container(
                                                          padding: EdgeInsets.fromLTRB(6.1, 14, 8.1, 16),
                                                          child: RichText(
                                                            textAlign: TextAlign.center,
                                                            text: TextSpan(
                                                              style: GoogleFonts.getFont(
                                                                'Roboto',
                                                                fontWeight: FontWeight.w400,
                                                                fontSize: 14,
                                                                color: Color(0xFF6D6D6D),
                                                              ),
                                                              children: [
                                                                TextSpan(
                                                                  text: 'Mon, 10 Jan
                                                          ',
                                                                  style: GoogleFonts.getFont(
                                                                    'Roboto',
                                                                    fontWeight: FontWeight.w600,
                                                                    fontSize: 14,
                                                                    height: 1.3,
                                                                    color: Color(0xFFFFFFFF),
                                                                  ),
                                                                ),
                                                                TextSpan(
                                                                  text: 'Rp. 935.000',
                                                                  style: GoogleFonts.getFont(
                                                                    'Roboto',
                                                                    fontWeight: FontWeight.w400,
                                                                    fontSize: 12,
                                                                    height: 1.3,
                                                                    color: Color(0xFFFFFFFF),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              Container(
                                                margin: EdgeInsets.fromLTRB(0, 0, 3.5, 0),
                                                width: 20,
                                                height: 20,
                                                child: SizedBox(
                                                  width: 20,
                                                  height: 20,
                                                  child: SvgPicture.asset(
                                                    'assets/vectors/vector_64_x2.svg',
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Expanded(
                              child: Container(
                                margin: EdgeInsets.fromLTRB(0, 173.5, 0, 12.5),
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: Color(0xFFE8E8E8),
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  child: Container(
                                    padding: EdgeInsets.fromLTRB(16, 10, 14.1, 10),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.start,
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Container(
                                          margin: EdgeInsets.fromLTRB(0, 0.2, 13, 0.2),
                                          width: 18,
                                          height: 19.6,
                                          child: SizedBox(
                                            width: 18,
                                            height: 19.6,
                                            child: SvgPicture.asset(
                                              'assets/vectors/vector_76_x2.svg',
                                            ),
                                          ),
                                        ),
                                        Text(
                                          'Flight',
                                          style: GoogleFonts.getFont(
                                            'Poppins',
                                            fontWeight: FontWeight.w500,
                                            fontSize: 14,
                                            height: 1.4,
                                            letterSpacing: 0.3,
                                            color: Color(0xFF121212),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Positioned(
                        right: 45,
                        bottom: 44,
                        child: Container(
                          decoration: BoxDecoration(
                            color: Color(0x33FFFFFF),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Container(
                            height: 60,
                            padding: EdgeInsets.fromLTRB(8.4, 14, 10.4, 16),
                            child: RichText(
                              textAlign: TextAlign.center,
                              text: TextSpan(
                                style: GoogleFonts.getFont(
                                  'Roboto',
                                  fontWeight: FontWeight.w400,
                                  fontSize: 14,
                                  color: Color(0xFF6D6D6D),
                                ),
                                children: [
                                  TextSpan(
                                    text: 'Tue, 11 Jan
                            ',
                                    style: GoogleFonts.getFont(
                                      'Roboto',
                                      fontWeight: FontWeight.w600,
                                      fontSize: 14,
                                      height: 1.3,
                                      color: Color(0xFFFFFFFF),
                                    ),
                                  ),
                                  TextSpan(
                                    text: 'Rp. 1.004.000',
                                    style: GoogleFonts.getFont(
                                      'Roboto',
                                      fontWeight: FontWeight.w400,
                                      fontSize: 12,
                                      height: 1.3,
                                      color: Color(0xFFFFFFFF),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  margin: EdgeInsets.fromLTRB(20, 0, 20, 20),
                  child: Align(
                    alignment: Alignment.topLeft,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            color: Color(0xFF7060E5),
                            boxShadow: [
                              BoxShadow(
                                color: Color(0x24000000),
                                offset: Offset(0, 4),
                                blurRadius: 10,
                              ),
                            ],
                          ),
                          child: Container(
                            padding: EdgeInsets.fromLTRB(10, 4, 10.2, 4),
                            child: Text(
                              'All',
                              style: GoogleFonts.getFont(
                                'Poppins',
                                fontWeight: FontWeight.w500,
                                fontSize: 12,
                                letterSpacing: 0.1,
                                color: Color(0xFFEEEEEE),
                              ),
                            ),
                          ),
                        ),
                        Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            color: Color(0x1A7060E5),
                            boxShadow: [
                              BoxShadow(
                                color: Color(0x1F000000),
                                offset: Offset(0, 4),
                                blurRadius: 10,
                              ),
                            ],
                          ),
                          child: Container(
                            padding: EdgeInsets.fromLTRB(10, 4, 10.2, 4),
                            child: Text(
                              'Free Reschedule',
                              style: GoogleFonts.getFont(
                                'Poppins',
                                fontWeight: FontWeight.w500,
                                fontSize: 12,
                                letterSpacing: 0.1,
                                color: Color(0xFF7060E5),
                              ),
                            ),
                          ),
                        ),
                        Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            color: Color(0x1A7060E5),
                            boxShadow: [
                              BoxShadow(
                                color: Color(0x1F000000),
                                offset: Offset(0, 4),
                                blurRadius: 10,
                              ),
                            ],
                          ),
                          child: Container(
                            padding: EdgeInsets.fromLTRB(10, 4, 10.9, 4),
                            child: Text(
                              'Free Protection',
                              style: GoogleFonts.getFont(
                                'Poppins',
                                fontWeight: FontWeight.w500,
                                fontSize: 12,
                                letterSpacing: 0.1,
                                color: Color(0xFF7060E5),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                Container(
                  margin: EdgeInsets.fromLTRB(20, 0, 20, 0),
                  child: Align(
                    alignment: Alignment.topLeft,
                    child: Stack(
                      children: [
                        Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              margin: EdgeInsets.fromLTRB(0, 0, 0, 10),
                              decoration: BoxDecoration(
                                border: Border.all(color: Color(0xFFDEDEDE)),
                                borderRadius: BorderRadius.circular(10),
                                color: Color(0xFFFFFFFF),
                                boxShadow: [
                                  BoxShadow(
                                    color: Color(0x24000000),
                                    offset: Offset(0, 4),
                                    blurRadius: 10,
                                  ),
                                ],
                              ),
                              child: Container(
                                padding: EdgeInsets.fromLTRB(4, 13, 13.4, 15.5),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Container(
                                      margin: EdgeInsets.fromLTRB(0, 0, 0, 9.7),
                                      child: Align(
                                        alignment: Alignment.topLeft,
                                        child: Container(
                                          width: 64.9,
                                          height: 26.3,
                                          child: Container(
                                            decoration: BoxDecoration(
                                              image: DecorationImage(
                                                image: AssetImage(
                                                  'assets/images/air_asia_1.png',
                                                ),
                                              ),
                                            ),
                                            child: Container(
                                              width: 64.9,
                                              height: 26.3,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      margin: EdgeInsets.fromLTRB(9, 0, 0, 0),
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Container(
                                            margin: EdgeInsets.fromLTRB(0, 0, 37.1, 0.5),
                                            child: Row(
                                              mainAxisAlignment: MainAxisAlignment.start,
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Container(
                                                  margin: EdgeInsets.fromLTRB(0, 0, 21.4, 13),
                                                  child: Column(
                                                    mainAxisAlignment: MainAxisAlignment.start,
                                                    crossAxisAlignment: CrossAxisAlignment.center,
                                                    children: [
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(0, 0, 0, 4),
                                                        child: Text(
                                                          '09:10',
                                                          style: GoogleFonts.getFont(
                                                            'Roboto',
                                                            fontWeight: FontWeight.w500,
                                                            fontSize: 16,
                                                            color: Color(0xFF464646),
                                                          ),
                                                        ),
                                                      ),
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(3.5, 0, 3.1, 0),
                                                        child: Container(
                                                          decoration: BoxDecoration(
                                                            color: Color(0x12808080),
                                                            borderRadius: BorderRadius.circular(10),
                                                          ),
                                                          child: Container(
                                                            padding: EdgeInsets.fromLTRB(6.4, 0, 6.4, 0),
                                                            child: Text(
                                                              'BDO',
                                                              style: GoogleFonts.getFont(
                                                                'Poppins',
                                                                fontWeight: FontWeight.w500,
                                                                fontSize: 10,
                                                                color: Color(0xFF9B9B9B),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                                Container(
                                                  margin: EdgeInsets.fromLTRB(0, 0, 6.4, 0),
                                                  child: Column(
                                                    mainAxisAlignment: MainAxisAlignment.start,
                                                    crossAxisAlignment: CrossAxisAlignment.center,
                                                    children: [
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(9.8, 0, 9.8, 4),
                                                        child: Text(
                                                          '1hr 30m',
                                                          style: GoogleFonts.getFont(
                                                            'Poppins',
                                                            fontWeight: FontWeight.w400,
                                                            fontSize: 10,
                                                            color: Color(0xFF9B9B9B),
                                                          ),
                                                        ),
                                                      ),
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(0, 0, 0, 4),
                                                        child: SizedBox(
                                                          width: 58,
                                                          height: 13,
                                                          child: SvgPicture.asset(
                                                            'assets/vectors/frame_784_x2.svg',
                                                          ),
                                                        ),
                                                      ),
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(14.4, 0, 14.4, 0),
                                                        child: Text(
                                                          'Direct',
                                                          style: GoogleFonts.getFont(
                                                            'Poppins',
                                                            fontWeight: FontWeight.w400,
                                                            fontSize: 10,
                                                            color: Color(0xFF9B9B9B),
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                                Container(
                                                  margin: EdgeInsets.fromLTRB(0, 0, 0, 13),
                                                  child: Column(
                                                    mainAxisAlignment: MainAxisAlignment.start,
                                                    crossAxisAlignment: CrossAxisAlignment.center,
                                                    children: [
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(0, 0, 0, 4),
                                                        child: Text(
                                                          '10:40',
                                                          style: GoogleFonts.getFont(
                                                            'Roboto',
                                                            fontWeight: FontWeight.w500,
                                                            fontSize: 16,
                                                            color: Color(0xFF464646),
                                                          ),
                                                        ),
                                                      ),
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(6.1, 0, 6.5, 0),
                                                        child: Container(
                                                          decoration: BoxDecoration(
                                                            color: Color(0x12808080),
                                                            borderRadius: BorderRadius.circular(10),
                                                          ),
                                                          child: Container(
                                                            padding: EdgeInsets.fromLTRB(4.5, 0, 4.5, 0),
                                                            child: Text(
                                                              'DPS',
                                                              style: GoogleFonts.getFont(
                                                                'Poppins',
                                                                fontWeight: FontWeight.w500,
                                                                fontSize: 10,
                                                                color: Color(0xFF9B9B9B),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Column(
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            crossAxisAlignment: CrossAxisAlignment.end,
                                            children: [
                                              Container(
                                                margin: EdgeInsets.fromLTRB(0, 0, 0, 8.5),
                                                child: Row(
                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    Container(
                                                      margin: EdgeInsets.fromLTRB(0, 0, 0.4, 0),
                                                      child: Text(
                                                        'Rp. 955.000',
                                                        style: GoogleFonts.getFont(
                                                          'Poppins',
                                                          fontWeight: FontWeight.w600,
                                                          fontSize: 16,
                                                          color: Color(0xFFFC7725),
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      margin: EdgeInsets.fromLTRB(0, 9, 0, 0),
                                                      child: Text(
                                                        '/Pax',
                                                        style: GoogleFonts.getFont(
                                                          'Poppins',
                                                          fontWeight: FontWeight.w400,
                                                          fontSize: 10,
                                                          color: Color(0xFF9B9B9B),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              Container(
                                                margin: EdgeInsets.fromLTRB(6, 0, 6, 0),
                                                width: 10.8,
                                                height: 19,
                                                child: SizedBox(
                                                  width: 10.8,
                                                  height: 19,
                                                  child: SvgPicture.asset(
                                                    'assets/vectors/vector_47_x2.svg',
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Container(
                              margin: EdgeInsets.fromLTRB(0, 0, 0, 10),
                              decoration: BoxDecoration(
                                border: Border.all(color: Color(0xFFDEDEDE)),
                                borderRadius: BorderRadius.circular(10),
                                color: Color(0xFFFFFFFF),
                                boxShadow: [
                                  BoxShadow(
                                    color: Color(0x24000000),
                                    offset: Offset(0, 4),
                                    blurRadius: 10,
                                  ),
                                ],
                              ),
                              child: Container(
                                padding: EdgeInsets.fromLTRB(4, 13, 13, 15.5),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      margin: EdgeInsets.fromLTRB(0, 0, 0, 9.7),
                                      child: SizedBox(
                                        width: 331,
                                        child: Row(
                                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              width: 64.9,
                                              height: 26.3,
                                              child: Container(
                                                decoration: BoxDecoration(
                                                  image: DecorationImage(
                                                    image: AssetImage(
                                                      'assets/images/air_asia_1.png',
                                                    ),
                                                  ),
                                                ),
                                                child: Container(
                                                  width: 64.9,
                                                  height: 26.3,
                                                ),
                                              ),
                                            ),
                                            Container(
                                              margin: EdgeInsets.fromLTRB(0, 0, 0, 6.3),
                                              decoration: BoxDecoration(
                                                borderRadius: BorderRadius.circular(20),
                                                color: Color(0xFF06A469),
                                                boxShadow: [
                                                  BoxShadow(
                                                    color: Color(0x1A000000),
                                                    offset: Offset(0, 4),
                                                    blurRadius: 15,
                                                  ),
                                                ],
                                              ),
                                              child: Container(
                                                padding: EdgeInsets.fromLTRB(10.3, 4, 10.3, 4),
                                                child: Text(
                                                  'Free Reschedule',
                                                  style: GoogleFonts.getFont(
                                                    'Roboto',
                                                    fontWeight: FontWeight.w400,
                                                    fontSize: 10,
                                                    color: Color(0xFFFFFFFF),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                    Container(
                                      margin: EdgeInsets.fromLTRB(9, 0, 0.4, 0),
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Container(
                                            margin: EdgeInsets.fromLTRB(0, 0, 37.4, 0.5),
                                            child: Row(
                                              mainAxisAlignment: MainAxisAlignment.start,
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Container(
                                                  margin: EdgeInsets.fromLTRB(0, 0, 21.4, 13),
                                                  child: Column(
                                                    mainAxisAlignment: MainAxisAlignment.start,
                                                    crossAxisAlignment: CrossAxisAlignment.center,
                                                    children: [
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(0, 0, 0, 4),
                                                        child: Text(
                                                          '13:10',
                                                          style: GoogleFonts.getFont(
                                                            'Roboto',
                                                            fontWeight: FontWeight.w500,
                                                            fontSize: 16,
                                                            color: Color(0xFF464646),
                                                          ),
                                                        ),
                                                      ),
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(3.5, 0, 3.1, 0),
                                                        child: Container(
                                                          decoration: BoxDecoration(
                                                            color: Color(0x12808080),
                                                            borderRadius: BorderRadius.circular(10),
                                                          ),
                                                          child: Container(
                                                            padding: EdgeInsets.fromLTRB(6.4, 0, 6.4, 0),
                                                            child: Text(
                                                              'BDO',
                                                              style: GoogleFonts.getFont(
                                                                'Poppins',
                                                                fontWeight: FontWeight.w500,
                                                                fontSize: 10,
                                                                color: Color(0xFF9B9B9B),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                                Container(
                                                  margin: EdgeInsets.fromLTRB(0, 0, 6.4, 0),
                                                  child: Column(
                                                    mainAxisAlignment: MainAxisAlignment.start,
                                                    crossAxisAlignment: CrossAxisAlignment.center,
                                                    children: [
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(9.8, 0, 9.8, 4),
                                                        child: Text(
                                                          '1hr 30m',
                                                          style: GoogleFonts.getFont(
                                                            'Poppins',
                                                            fontWeight: FontWeight.w400,
                                                            fontSize: 10,
                                                            color: Color(0xFF9B9B9B),
                                                          ),
                                                        ),
                                                      ),
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(0, 0, 0, 4),
                                                        child: SizedBox(
                                                          width: 58,
                                                          height: 13,
                                                          child: SvgPicture.asset(
                                                            'assets/vectors/frame_783_x2.svg',
                                                          ),
                                                        ),
                                                      ),
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(14.4, 0, 14.4, 0),
                                                        child: Text(
                                                          'Direct',
                                                          style: GoogleFonts.getFont(
                                                            'Poppins',
                                                            fontWeight: FontWeight.w400,
                                                            fontSize: 10,
                                                            color: Color(0xFF9B9B9B),
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                                Container(
                                                  margin: EdgeInsets.fromLTRB(0, 0, 0, 13),
                                                  child: Column(
                                                    mainAxisAlignment: MainAxisAlignment.start,
                                                    crossAxisAlignment: CrossAxisAlignment.center,
                                                    children: [
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(0, 0, 0, 4),
                                                        child: Text(
                                                          '14:40',
                                                          style: GoogleFonts.getFont(
                                                            'Roboto',
                                                            fontWeight: FontWeight.w500,
                                                            fontSize: 16,
                                                            color: Color(0xFF464646),
                                                          ),
                                                        ),
                                                      ),
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(6.1, 0, 6.5, 0),
                                                        child: Container(
                                                          decoration: BoxDecoration(
                                                            color: Color(0x12808080),
                                                            borderRadius: BorderRadius.circular(10),
                                                          ),
                                                          child: Container(
                                                            padding: EdgeInsets.fromLTRB(4.5, 0, 4.5, 0),
                                                            child: Text(
                                                              'DPS',
                                                              style: GoogleFonts.getFont(
                                                                'Poppins',
                                                                fontWeight: FontWeight.w500,
                                                                fontSize: 10,
                                                                color: Color(0xFF9B9B9B),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Column(
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            crossAxisAlignment: CrossAxisAlignment.end,
                                            children: [
                                              Container(
                                                margin: EdgeInsets.fromLTRB(0, 0, 0, 8.5),
                                                child: Row(
                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    Container(
                                                      margin: EdgeInsets.fromLTRB(0, 0, 0.4, 0),
                                                      child: Text(
                                                        'Rp. 990.000',
                                                        style: GoogleFonts.getFont(
                                                          'Poppins',
                                                          fontWeight: FontWeight.w600,
                                                          fontSize: 16,
                                                          color: Color(0xFFFC7725),
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      margin: EdgeInsets.fromLTRB(0, 9, 0, 0),
                                                      child: Text(
                                                        '/Pax',
                                                        style: GoogleFonts.getFont(
                                                          'Poppins',
                                                          fontWeight: FontWeight.w400,
                                                          fontSize: 10,
                                                          color: Color(0xFF9B9B9B),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              Container(
                                                margin: EdgeInsets.fromLTRB(6, 0, 6, 0),
                                                width: 10.8,
                                                height: 19,
                                                child: SizedBox(
                                                  width: 10.8,
                                                  height: 19,
                                                  child: SvgPicture.asset(
                                                    'assets/vectors/vector_73_x2.svg',
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Container(
                              margin: EdgeInsets.fromLTRB(0, 0, 0, 10),
                              decoration: BoxDecoration(
                                border: Border.all(color: Color(0xFFDEDEDE)),
                                borderRadius: BorderRadius.circular(10),
                                color: Color(0xFFFFFFFF),
                                boxShadow: [
                                  BoxShadow(
                                    color: Color(0x24000000),
                                    offset: Offset(0, 4),
                                    blurRadius: 10,
                                  ),
                                ],
                              ),
                              child: Container(
                                padding: EdgeInsets.fromLTRB(13, 13, 13, 15.5),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      margin: EdgeInsets.fromLTRB(0, 0, 0, 16),
                                      child: SizedBox(
                                        width: 322,
                                        child: Row(
                                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              margin: EdgeInsets.fromLTRB(0, 0, 0, 1.5),
                                              child: Container(
                                                decoration: BoxDecoration(
                                                  image: DecorationImage(
                                                    image: AssetImage(
                                                      'assets/images/logo_citilink_by_kampungdesigner_1.png',
                                                    ),
                                                  ),
                                                ),
                                                child: Container(
                                                  width: 50,
                                                  height: 18.5,
                                                ),
                                              ),
                                            ),
                                            Container(
                                              decoration: BoxDecoration(
                                                borderRadius: BorderRadius.circular(20),
                                                color: Color(0xFF06A469),
                                                boxShadow: [
                                                  BoxShadow(
                                                    color: Color(0x1A000000),
                                                    offset: Offset(0, 4),
                                                    blurRadius: 15,
                                                  ),
                                                ],
                                              ),
                                              child: Container(
                                                padding: EdgeInsets.fromLTRB(10.3, 4, 10.3, 4),
                                                child: Text(
                                                  'Free Reschedule',
                                                  style: GoogleFonts.getFont(
                                                    'Roboto',
                                                    fontWeight: FontWeight.w400,
                                                    fontSize: 10,
                                                    color: Color(0xFFFFFFFF),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                    Container(
                                      margin: EdgeInsets.fromLTRB(0, 0, 0.4, 0),
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Container(
                                            margin: EdgeInsets.fromLTRB(0, 0, 38.3, 0.5),
                                            child: Row(
                                              mainAxisAlignment: MainAxisAlignment.start,
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Container(
                                                  margin: EdgeInsets.fromLTRB(0, 0, 21.4, 13),
                                                  child: Column(
                                                    mainAxisAlignment: MainAxisAlignment.start,
                                                    crossAxisAlignment: CrossAxisAlignment.center,
                                                    children: [
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(0, 0, 0, 4),
                                                        child: Text(
                                                          '15:20',
                                                          style: GoogleFonts.getFont(
                                                            'Roboto',
                                                            fontWeight: FontWeight.w500,
                                                            fontSize: 16,
                                                            color: Color(0xFF464646),
                                                          ),
                                                        ),
                                                      ),
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(3.5, 0, 3.1, 0),
                                                        child: Container(
                                                          decoration: BoxDecoration(
                                                            color: Color(0x12808080),
                                                            borderRadius: BorderRadius.circular(10),
                                                          ),
                                                          child: Container(
                                                            padding: EdgeInsets.fromLTRB(6.4, 0, 6.4, 0),
                                                            child: Text(
                                                              'BDO',
                                                              style: GoogleFonts.getFont(
                                                                'Poppins',
                                                                fontWeight: FontWeight.w500,
                                                                fontSize: 10,
                                                                color: Color(0xFF9B9B9B),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                                Container(
                                                  margin: EdgeInsets.fromLTRB(0, 0, 6.4, 0),
                                                  child: Column(
                                                    mainAxisAlignment: MainAxisAlignment.start,
                                                    crossAxisAlignment: CrossAxisAlignment.center,
                                                    children: [
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(9.8, 0, 9.8, 4),
                                                        child: Text(
                                                          '1hr 30m',
                                                          style: GoogleFonts.getFont(
                                                            'Poppins',
                                                            fontWeight: FontWeight.w400,
                                                            fontSize: 10,
                                                            color: Color(0xFF9B9B9B),
                                                          ),
                                                        ),
                                                      ),
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(0, 0, 0, 4),
                                                        child: SizedBox(
                                                          width: 58,
                                                          height: 13,
                                                          child: SvgPicture.asset(
                                                            'assets/vectors/frame_782_x2.svg',
                                                          ),
                                                        ),
                                                      ),
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(14.4, 0, 14.4, 0),
                                                        child: Text(
                                                          'Direct',
                                                          style: GoogleFonts.getFont(
                                                            'Poppins',
                                                            fontWeight: FontWeight.w400,
                                                            fontSize: 10,
                                                            color: Color(0xFF9B9B9B),
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                                Container(
                                                  margin: EdgeInsets.fromLTRB(0, 0, 0, 13),
                                                  child: Column(
                                                    mainAxisAlignment: MainAxisAlignment.start,
                                                    crossAxisAlignment: CrossAxisAlignment.center,
                                                    children: [
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(0, 0, 0, 4),
                                                        child: Text(
                                                          '16:60',
                                                          style: GoogleFonts.getFont(
                                                            'Roboto',
                                                            fontWeight: FontWeight.w500,
                                                            fontSize: 16,
                                                            color: Color(0xFF464646),
                                                          ),
                                                        ),
                                                      ),
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(6.1, 0, 6.5, 0),
                                                        child: Container(
                                                          decoration: BoxDecoration(
                                                            color: Color(0x12808080),
                                                            borderRadius: BorderRadius.circular(10),
                                                          ),
                                                          child: Container(
                                                            padding: EdgeInsets.fromLTRB(4.5, 0, 4.5, 0),
                                                            child: Text(
                                                              'DPS',
                                                              style: GoogleFonts.getFont(
                                                                'Poppins',
                                                                fontWeight: FontWeight.w500,
                                                                fontSize: 10,
                                                                color: Color(0xFF9B9B9B),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Column(
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            crossAxisAlignment: CrossAxisAlignment.end,
                                            children: [
                                              Container(
                                                margin: EdgeInsets.fromLTRB(0, 0, 0, 8.5),
                                                child: Row(
                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    Container(
                                                      margin: EdgeInsets.fromLTRB(0, 0, 0.4, 0),
                                                      child: Text(
                                                        'Rp. 1.02.000',
                                                        style: GoogleFonts.getFont(
                                                          'Poppins',
                                                          fontWeight: FontWeight.w600,
                                                          fontSize: 16,
                                                          color: Color(0xFFFC7725),
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      margin: EdgeInsets.fromLTRB(0, 9, 0, 0),
                                                      child: Text(
                                                        '/Pax',
                                                        style: GoogleFonts.getFont(
                                                          'Poppins',
                                                          fontWeight: FontWeight.w400,
                                                          fontSize: 10,
                                                          color: Color(0xFF9B9B9B),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              Container(
                                                margin: EdgeInsets.fromLTRB(6, 0, 6, 0),
                                                width: 10.8,
                                                height: 19,
                                                child: SizedBox(
                                                  width: 10.8,
                                                  height: 19,
                                                  child: SvgPicture.asset(
                                                    'assets/vectors/vector_40_x2.svg',
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Container(
                              margin: EdgeInsets.fromLTRB(0, 0, 0, 10),
                              decoration: BoxDecoration(
                                border: Border.all(color: Color(0xFFDEDEDE)),
                                borderRadius: BorderRadius.circular(10),
                                color: Color(0xFFFFFFFF),
                                boxShadow: [
                                  BoxShadow(
                                    color: Color(0x24000000),
                                    offset: Offset(0, 4),
                                    blurRadius: 10,
                                  ),
                                ],
                              ),
                              child: Container(
                                padding: EdgeInsets.fromLTRB(13, 13, 13, 15.5),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      margin: EdgeInsets.fromLTRB(0, 0, 0, 16),
                                      child: SizedBox(
                                        width: 322,
                                        child: Row(
                                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              margin: EdgeInsets.fromLTRB(0, 0, 0, 1.5),
                                              child: Container(
                                                decoration: BoxDecoration(
                                                  image: DecorationImage(
                                                    image: AssetImage(
                                                      'assets/images/logo_citilink_by_kampungdesigner_1.png',
                                                    ),
                                                  ),
                                                ),
                                                child: Container(
                                                  width: 50,
                                                  height: 18.5,
                                                ),
                                              ),
                                            ),
                                            Container(
                                              decoration: BoxDecoration(
                                                borderRadius: BorderRadius.circular(20),
                                                color: Color(0xFF06A469),
                                                boxShadow: [
                                                  BoxShadow(
                                                    color: Color(0x1A000000),
                                                    offset: Offset(0, 4),
                                                    blurRadius: 15,
                                                  ),
                                                ],
                                              ),
                                              child: Container(
                                                padding: EdgeInsets.fromLTRB(10.3, 4, 10.3, 4),
                                                child: Text(
                                                  'Free Reschedule',
                                                  style: GoogleFonts.getFont(
                                                    'Roboto',
                                                    fontWeight: FontWeight.w400,
                                                    fontSize: 10,
                                                    color: Color(0xFFFFFFFF),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                    Container(
                                      margin: EdgeInsets.fromLTRB(0, 0, 0.4, 0),
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Container(
                                            margin: EdgeInsets.fromLTRB(0, 0, 31.3, 0.5),
                                            child: Row(
                                              mainAxisAlignment: MainAxisAlignment.start,
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Container(
                                                  margin: EdgeInsets.fromLTRB(0, 0, 21.4, 13),
                                                  child: Column(
                                                    mainAxisAlignment: MainAxisAlignment.start,
                                                    crossAxisAlignment: CrossAxisAlignment.center,
                                                    children: [
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(0, 0, 0, 4),
                                                        child: Text(
                                                          '16:50',
                                                          style: GoogleFonts.getFont(
                                                            'Roboto',
                                                            fontWeight: FontWeight.w500,
                                                            fontSize: 16,
                                                            color: Color(0xFF464646),
                                                          ),
                                                        ),
                                                      ),
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(3.5, 0, 3.1, 0),
                                                        child: Container(
                                                          decoration: BoxDecoration(
                                                            color: Color(0x12808080),
                                                            borderRadius: BorderRadius.circular(10),
                                                          ),
                                                          child: Container(
                                                            padding: EdgeInsets.fromLTRB(6.4, 0, 6.4, 0),
                                                            child: Text(
                                                              'BDO',
                                                              style: GoogleFonts.getFont(
                                                                'Poppins',
                                                                fontWeight: FontWeight.w500,
                                                                fontSize: 10,
                                                                color: Color(0xFF9B9B9B),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                                Container(
                                                  margin: EdgeInsets.fromLTRB(0, 0, 6.4, 0),
                                                  child: Column(
                                                    mainAxisAlignment: MainAxisAlignment.start,
                                                    crossAxisAlignment: CrossAxisAlignment.center,
                                                    children: [
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(9.8, 0, 9.8, 4),
                                                        child: Text(
                                                          '1hr 30m',
                                                          style: GoogleFonts.getFont(
                                                            'Poppins',
                                                            fontWeight: FontWeight.w400,
                                                            fontSize: 10,
                                                            color: Color(0xFF9B9B9B),
                                                          ),
                                                        ),
                                                      ),
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(0, 0, 0, 4),
                                                        child: SizedBox(
                                                          width: 58,
                                                          height: 13,
                                                          child: SvgPicture.asset(
                                                            'assets/vectors/frame_785_x2.svg',
                                                          ),
                                                        ),
                                                      ),
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(14.4, 0, 14.4, 0),
                                                        child: Text(
                                                          'Direct',
                                                          style: GoogleFonts.getFont(
                                                            'Poppins',
                                                            fontWeight: FontWeight.w400,
                                                            fontSize: 10,
                                                            color: Color(0xFF9B9B9B),
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                                Container(
                                                  margin: EdgeInsets.fromLTRB(0, 0, 0, 13),
                                                  child: Column(
                                                    mainAxisAlignment: MainAxisAlignment.start,
                                                    crossAxisAlignment: CrossAxisAlignment.center,
                                                    children: [
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(0, 0, 0, 4),
                                                        child: Text(
                                                          '18:10',
                                                          style: GoogleFonts.getFont(
                                                            'Roboto',
                                                            fontWeight: FontWeight.w500,
                                                            fontSize: 16,
                                                            color: Color(0xFF464646),
                                                          ),
                                                        ),
                                                      ),
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(6.1, 0, 6.5, 0),
                                                        child: Container(
                                                          decoration: BoxDecoration(
                                                            color: Color(0x12808080),
                                                            borderRadius: BorderRadius.circular(10),
                                                          ),
                                                          child: Container(
                                                            padding: EdgeInsets.fromLTRB(4.5, 0, 4.5, 0),
                                                            child: Text(
                                                              'DPS',
                                                              style: GoogleFonts.getFont(
                                                                'Poppins',
                                                                fontWeight: FontWeight.w500,
                                                                fontSize: 10,
                                                                color: Color(0xFF9B9B9B),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Column(
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            crossAxisAlignment: CrossAxisAlignment.end,
                                            children: [
                                              Container(
                                                margin: EdgeInsets.fromLTRB(0, 0, 0, 8.5),
                                                child: Row(
                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    Container(
                                                      margin: EdgeInsets.fromLTRB(0, 0, 0.4, 0),
                                                      child: Text(
                                                        'Rp. 1.100.000',
                                                        style: GoogleFonts.getFont(
                                                          'Poppins',
                                                          fontWeight: FontWeight.w600,
                                                          fontSize: 16,
                                                          color: Color(0xFFFC7725),
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      margin: EdgeInsets.fromLTRB(0, 9, 0, 0),
                                                      child: Text(
                                                        '/Pax',
                                                        style: GoogleFonts.getFont(
                                                          'Poppins',
                                                          fontWeight: FontWeight.w400,
                                                          fontSize: 10,
                                                          color: Color(0xFF9B9B9B),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              Container(
                                                margin: EdgeInsets.fromLTRB(6, 0, 6, 0),
                                                width: 10.8,
                                                height: 19,
                                                child: SizedBox(
                                                  width: 10.8,
                                                  height: 19,
                                                  child: SvgPicture.asset(
                                                    'assets/vectors/vector_10_x2.svg',
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Container(
                              decoration: BoxDecoration(
                                border: Border.all(color: Color(0xFFDEDEDE)),
                                borderRadius: BorderRadius.circular(10),
                                color: Color(0xFFFFFFFF),
                                boxShadow: [
                                  BoxShadow(
                                    color: Color(0x24000000),
                                    offset: Offset(0, 4),
                                    blurRadius: 10,
                                  ),
                                ],
                              ),
                              child: Container(
                                padding: EdgeInsets.fromLTRB(13, 13, 13, 15.5),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      margin: EdgeInsets.fromLTRB(0, 0, 0, 16),
                                      child: SizedBox(
                                        width: 322,
                                        child: Row(
                                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              margin: EdgeInsets.fromLTRB(0, 0, 0, 4),
                                              child: Container(
                                                decoration: BoxDecoration(
                                                  image: DecorationImage(
                                                    fit: BoxFit.cover,
                                                    image: AssetImage(
                                                      'assets/images/logo_batik_air_1.png',
                                                    ),
                                                  ),
                                                ),
                                                child: Container(
                                                  width: 59,
                                                  height: 16,
                                                ),
                                              ),
                                            ),
                                            Row(
                                              mainAxisAlignment: MainAxisAlignment.start,
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Container(
                                                  margin: EdgeInsets.fromLTRB(0, 0, 10, 0),
                                                  decoration: BoxDecoration(
                                                    borderRadius: BorderRadius.circular(20),
                                                    color: Color(0xFF255B9B),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: Color(0x1A000000),
                                                        offset: Offset(0, 4),
                                                        blurRadius: 15,
                                                      ),
                                                    ],
                                                  ),
                                                  child: Container(
                                                    padding: EdgeInsets.fromLTRB(10.1, 4, 10.1, 4),
                                                    child: Text(
                                                      'Free Protection',
                                                      style: GoogleFonts.getFont(
                                                        'Roboto',
                                                        fontWeight: FontWeight.w400,
                                                        fontSize: 10,
                                                        color: Color(0xFFFFFFFF),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius: BorderRadius.circular(20),
                                                    color: Color(0xFF06A469),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: Color(0x1A000000),
                                                        offset: Offset(0, 4),
                                                        blurRadius: 15,
                                                      ),
                                                    ],
                                                  ),
                                                  child: Container(
                                                    padding: EdgeInsets.fromLTRB(10.3, 4, 10.3, 4),
                                                    child: Text(
                                                      'Free Reschedule',
                                                      style: GoogleFonts.getFont(
                                                        'Roboto',
                                                        fontWeight: FontWeight.w400,
                                                        fontSize: 10,
                                                        color: Color(0xFFFFFFFF),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                    Container(
                                      margin: EdgeInsets.fromLTRB(0, 0, 0.4, 0),
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Container(
                                            margin: EdgeInsets.fromLTRB(0, 0, 26.6, 0.5),
                                            child: Row(
                                              mainAxisAlignment: MainAxisAlignment.start,
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Container(
                                                  margin: EdgeInsets.fromLTRB(0, 0, 21.4, 13),
                                                  child: Column(
                                                    mainAxisAlignment: MainAxisAlignment.start,
                                                    crossAxisAlignment: CrossAxisAlignment.center,
                                                    children: [
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(0, 0, 0, 4),
                                                        child: Text(
                                                          '18:10',
                                                          style: GoogleFonts.getFont(
                                                            'Roboto',
                                                            fontWeight: FontWeight.w500,
                                                            fontSize: 16,
                                                            color: Color(0xFF464646),
                                                          ),
                                                        ),
                                                      ),
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(3.5, 0, 3.1, 0),
                                                        child: Container(
                                                          decoration: BoxDecoration(
                                                            color: Color(0x12808080),
                                                            borderRadius: BorderRadius.circular(10),
                                                          ),
                                                          child: Container(
                                                            padding: EdgeInsets.fromLTRB(6.4, 0, 6.4, 0),
                                                            child: Text(
                                                              'BDO',
                                                              style: GoogleFonts.getFont(
                                                                'Poppins',
                                                                fontWeight: FontWeight.w500,
                                                                fontSize: 10,
                                                                color: Color(0xFF9B9B9B),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                                Container(
                                                  margin: EdgeInsets.fromLTRB(0, 0, 6.4, 0),
                                                  child: Column(
                                                    mainAxisAlignment: MainAxisAlignment.start,
                                                    crossAxisAlignment: CrossAxisAlignment.center,
                                                    children: [
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(9.8, 0, 9.8, 4),
                                                        child: Text(
                                                          '1hr 30m',
                                                          style: GoogleFonts.getFont(
                                                            'Poppins',
                                                            fontWeight: FontWeight.w400,
                                                            fontSize: 10,
                                                            color: Color(0xFF9B9B9B),
                                                          ),
                                                        ),
                                                      ),
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(0, 0, 0, 4),
                                                        child: SizedBox(
                                                          width: 58,
                                                          height: 13,
                                                          child: SvgPicture.asset(
                                                            'assets/vectors/frame_78_x2.svg',
                                                          ),
                                                        ),
                                                      ),
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(14.4, 0, 14.4, 0),
                                                        child: Text(
                                                          'Direct',
                                                          style: GoogleFonts.getFont(
                                                            'Poppins',
                                                            fontWeight: FontWeight.w400,
                                                            fontSize: 10,
                                                            color: Color(0xFF9B9B9B),
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                                Container(
                                                  margin: EdgeInsets.fromLTRB(0, 0, 0, 13),
                                                  child: Column(
                                                    mainAxisAlignment: MainAxisAlignment.start,
                                                    crossAxisAlignment: CrossAxisAlignment.center,
                                                    children: [
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(0, 0, 0, 4),
                                                        child: Text(
                                                          '19:40',
                                                          style: GoogleFonts.getFont(
                                                            'Roboto',
                                                            fontWeight: FontWeight.w500,
                                                            fontSize: 16,
                                                            color: Color(0xFF464646),
                                                          ),
                                                        ),
                                                      ),
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(6.1, 0, 6.5, 0),
                                                        child: Container(
                                                          decoration: BoxDecoration(
                                                            color: Color(0x12808080),
                                                            borderRadius: BorderRadius.circular(10),
                                                          ),
                                                          child: Container(
                                                            padding: EdgeInsets.fromLTRB(4.5, 0, 4.5, 0),
                                                            child: Text(
                                                              'DPS',
                                                              style: GoogleFonts.getFont(
                                                                'Poppins',
                                                                fontWeight: FontWeight.w500,
                                                                fontSize: 10,
                                                                color: Color(0xFF9B9B9B),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Column(
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            crossAxisAlignment: CrossAxisAlignment.end,
                                            children: [
                                              Container(
                                                margin: EdgeInsets.fromLTRB(0, 0, 0, 8.5),
                                                child: Row(
                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    Container(
                                                      margin: EdgeInsets.fromLTRB(0, 0, 0.5, 0),
                                                      child: Text(
                                                        'Rp. 1.400.000',
                                                        style: GoogleFonts.getFont(
                                                          'Poppins',
                                                          fontWeight: FontWeight.w600,
                                                          fontSize: 16,
                                                          color: Color(0xFFFC7725),
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      margin: EdgeInsets.fromLTRB(0, 9, 0, 0),
                                                      child: Text(
                                                        '/Pax',
                                                        style: GoogleFonts.getFont(
                                                          'Poppins',
                                                          fontWeight: FontWeight.w400,
                                                          fontSize: 10,
                                                          color: Color(0xFF9B9B9B),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              Container(
                                                margin: EdgeInsets.fromLTRB(6, 0, 6, 0),
                                                width: 10.8,
                                                height: 19,
                                                child: SizedBox(
                                                  width: 10.8,
                                                  height: 19,
                                                  child: SvgPicture.asset(
                                                    'assets/vectors/vector_52_x2.svg',
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                        Positioned(
                          bottom: 102,
                          child: Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(20),
                              color: Color(0xFFFFFFFF),
                              boxShadow: [
                                BoxShadow(
                                  color: Color(0x33000000),
                                  offset: Offset(0, 7),
                                  blurRadius: 10,
                                ),
                              ],
                            ),
                            child: SizedBox(
                              width: 176,
                              height: 48,
                              child: Container(
                                padding: EdgeInsets.fromLTRB(15.2, 0, 12.7, 0),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Container(
                                      margin: EdgeInsets.fromLTRB(0, 16, 15.6, 16),
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Container(
                                            margin: EdgeInsets.fromLTRB(0, 1.4, 6, 1.4),
                                            width: 17.8,
                                            height: 13.1,
                                            child: SizedBox(
                                              width: 17.8,
                                              height: 13.1,
                                              child: SvgPicture.asset(
                                                'assets/vectors/vector_13_x2.svg',
                                              ),
                                            ),
                                          ),
                                          Text(
                                            'Short',
                                            style: GoogleFonts.getFont(
                                              'Roboto',
                                              fontWeight: FontWeight.w600,
                                              fontSize: 14,
                                              color: Color(0xFF7060E5),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Container(
                                      margin: EdgeInsets.fromLTRB(0, 0, 17, 0),
                                      child: Container(
                                        decoration: BoxDecoration(
                                          color: Color(0xFFDEDEDE),
                                        ),
                                        child: Container(
                                          width: 1,
                                          height: 48,
                                        ),
                                      ),
                                    ),
                                    Container(
                                      margin: EdgeInsets.fromLTRB(0, 15, 0, 12),
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Container(
                                            margin: EdgeInsets.fromLTRB(0, 4.5, 9, 4.5),
                                            width: 12,
                                            height: 12,
                                            child: SizedBox(
                                              width: 12,
                                              height: 12,
                                              child: SvgPicture.asset(
                                                'assets/vectors/vector_25_x2.svg',
                                              ),
                                            ),
                                          ),
                                          Text(
                                            'Filter',
                                            style: GoogleFonts.getFont(
                                              'Poppins',
                                              fontWeight: FontWeight.w600,
                                              fontSize: 14,
                                              letterSpacing: 0.1,
                                              color: Color(0xFF7060E5),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          Positioned(
            left: -70,
            top: 122,
            child: Container(
              decoration: BoxDecoration(
                color: Color(0x33FFFFFF),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Container(
                height: 60,
                padding: EdgeInsets.fromLTRB(12.1, 14, 14.1, 16),
                child: RichText(
                  textAlign: TextAlign.center,
                  text: TextSpan(
                    style: GoogleFonts.getFont(
                      'Roboto',
                      fontWeight: FontWeight.w400,
                      fontSize: 14,
                      color: Color(0xFF6D6D6D),
                    ),
                    children: [
                      TextSpan(
                        text: 'Fri, 7 Jan
                ',
                        style: GoogleFonts.getFont(
                          'Roboto',
                          fontWeight: FontWeight.w600,
                          fontSize: 14,
                          height: 1.3,
                          color: Color(0xFFFFFFFF),
                        ),
                      ),
                      TextSpan(
                        text: 'Rp. 1.004.000',
                        style: GoogleFonts.getFont(
                          'Roboto',
                          fontWeight: FontWeight.w400,
                          fontSize: 12,
                          height: 1.3,
                          color: Color(0xFFFFFFFF),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}