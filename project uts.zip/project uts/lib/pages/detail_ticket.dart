import 'package:flutter/material.dart';
import 'dart:ui';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_app/utils.dart';
import 'package:google_fonts/google_fonts.dart';

class DetailTicket extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return 
    Container(
      decoration: BoxDecoration(
        color: Color(0xFFFFFFFF),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Container(
        padding: EdgeInsets.fromLTRB(0, 0, 0, 30),
        child: Stack(
          clipBehavior: Clip.none,
          children: [
            SizedBox(
              width: 503,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    margin: EdgeInsets.fromLTRB(0, 0, 0, 326),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(
                          child: Container(
                            margin: EdgeInsets.fromLTRB(0, 0, 12, 0),
                            child: Container(
                              decoration: BoxDecoration(
                                color: Color(0xFF7060E5),
                                borderRadius: BorderRadius.circular(20),
                              ),
                              child: SizedBox(
                                height: 440,
                                child: Container(
                                  padding: EdgeInsets.fromLTRB(32.4, 14, 20, 0),
                                  child: Stack(
                                    clipBehavior: Clip.none,
                                    children: [
                                      Positioned(
                                        left: -65.4,
                                        top: -79,
                                        child: Container(
                                          decoration: BoxDecoration(
                                            color: Color(0xFF7868EC),
                                            borderRadius: BorderRadius.circular(83.5),
                                          ),
                                          child: Container(
                                            width: 167,
                                            height: 167,
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        left: -90.4,
                                        top: -74,
                                        child: Container(
                                          decoration: BoxDecoration(
                                            color: Color(0xFF7F6FF2),
                                            borderRadius: BorderRadius.circular(70),
                                          ),
                                          child: Container(
                                            width: 140,
                                            height: 140,
                                            padding: EdgeInsets.fromLTRB(6, 13, 6, 0),
                                            child: Container(
                                              decoration: BoxDecoration(
                                                color: Color(0xFF8778F8),
                                                borderRadius: BorderRadius.circular(50),
                                              ),
                                              child: Container(
                                                width: 100,
                                                height: 100,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      SizedBox(
                                        width: double.infinity,
                                        child: Column(
                                          mainAxisAlignment: MainAxisAlignment.start,
                                          crossAxisAlignment: CrossAxisAlignment.end,
                                          children: [
                                            Container(
                                              margin: EdgeInsets.fromLTRB(0, 0, 0, 14),
                                              child: Row(
                                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    child: Text(
                                                      '9:41',
                                                      style: GoogleFonts.getFont(
                                                        'Roboto Condensed',
                                                        fontWeight: FontWeight.w400,
                                                        fontSize: 17,
                                                        height: 1.3,
                                                        color: Color(0xFFEEEEEE),
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    margin: EdgeInsets.fromLTRB(0, 4.1, 0, 4.9),
                                                    child: SizedBox(
                                                      width: 52.7,
                                                      child: Row(
                                                        mainAxisAlignment: MainAxisAlignment.start,
                                                        crossAxisAlignment: CrossAxisAlignment.start,
                                                        children: [
                                                          Container(
                                                            margin: EdgeInsets.fromLTRB(0, 0.6, 7.6, 0.3),
                                                            child: SizedBox(
                                                              width: 17,
                                                              height: 12.1,
                                                              child: SvgPicture.asset(
                                                                'assets/vectors/wifi_2_x2.svg',
                                                              ),
                                                            ),
                                                          ),
                                                          SizedBox(
                                                            width: 28,
                                                            height: 13,
                                                            child: SvgPicture.asset(
                                                              'assets/vectors/battery_4_x2.svg',
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Container(
                                              margin: EdgeInsets.fromLTRB(10, 0, 10, 10),
                                              child: SizedBox(
                                                width: 182.5,
                                                child: Row(
                                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    Container(
                                                      width: 34,
                                                      height: 34,
                                                      child: Container(
                                                        decoration: BoxDecoration(
                                                          color: Color(0x80ABABAB),
                                                          borderRadius: BorderRadius.circular(100),
                                                        ),
                                                        child: Container(
                                                          width: 34,
                                                          height: 34,
                                                          padding: EdgeInsets.fromLTRB(11, 11, 11, 11),
                                                          child: SizedBox(
                                                            width: 12,
                                                            height: 12,
                                                            child: SvgPicture.asset(
                                                              'assets/vectors/vector_46_x2.svg',
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      margin: EdgeInsets.fromLTRB(0, 9, 0, 7),
                                                      width: 4,
                                                      height: 18,
                                                      child: SizedBox(
                                                        width: 4,
                                                        height: 18,
                                                        child: SvgPicture.asset(
                                                          'assets/vectors/vector_63_x2.svg',
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                            Container(
                                              margin: EdgeInsets.fromLTRB(0, 0, 13.4, 0),
                                              child: Align(
                                                alignment: Alignment.topCenter,
                                                child: Text(
                                                  'Your Ticket',
                                                  style: GoogleFonts.getFont(
                                                    'Poppins',
                                                    fontWeight: FontWeight.w600,
                                                    fontSize: 24,
                                                    color: Color(0xFFEEEEEE),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Expanded(
                          child: Container(
                            margin: EdgeInsets.fromLTRB(0, 173.5, 0, 226.5),
                            child: Container(
                              decoration: BoxDecoration(
                                color: Color(0xFFE8E8E8),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Container(
                                padding: EdgeInsets.fromLTRB(16, 10, 14.1, 10),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Container(
                                      margin: EdgeInsets.fromLTRB(0, 0.2, 13, 0.2),
                                      width: 18,
                                      height: 19.6,
                                      child: SizedBox(
                                        width: 18,
                                        height: 19.6,
                                        child: SvgPicture.asset(
                                          'assets/vectors/vector_71_x2.svg',
                                        ),
                                      ),
                                    ),
                                    Text(
                                      'Flight',
                                      style: GoogleFonts.getFont(
                                        'Poppins',
                                        fontWeight: FontWeight.w500,
                                        fontSize: 14,
                                        height: 1.4,
                                        letterSpacing: 0.3,
                                        color: Color(0xFF121212),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.fromLTRB(20, 0, 20, 0),
                    child: Align(
                      alignment: Alignment.topLeft,
                      child: Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(20),
                          color: Color(0xFF7060E5),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x24000000),
                              offset: Offset(0, 4),
                              blurRadius: 15,
                            ),
                          ],
                        ),
                        child: Container(
                          width: 350,
                          padding: EdgeInsets.fromLTRB(0, 12, 0, 12),
                          child: Text(
                            'Download Ticket',
                            style: GoogleFonts.getFont(
                              'Poppins',
                              fontWeight: FontWeight.w600,
                              fontSize: 16,
                              color: Color(0xFFFFFFFF),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Positioned(
              right: 20,
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: Color(0x24000000),
                      offset: Offset(0, 4),
                      blurRadius: 15,
                    ),
                  ],
                ),
                child: Stack(
                  children: [
                  Positioned(
                    top: -19.8,
                    child: SizedBox(
                      width: 350,
                      height: 534,
                      child: SvgPicture.asset(
                        'assets/vectors/frame_tiket_x2.svg',
                      ),
                    ),
                  ),
            SizedBox(
                      width: 350,
                      height: 534,
                      child: Container(
                        padding: EdgeInsets.fromLTRB(8.3, 19.8, 15.5, 30),
                        child: Stack(
                          clipBehavior: Clip.none,
                          children: [
                            Positioned(
                              top: 91.9,
                              child: Transform(
                                transform: Matrix4.identity()..rotationZ(0.7853981805),
                                child: Container(
                                  width: 24.1,
                                  height: 24.1,
                                  child: SizedBox(
                                    width: 24.1,
                                    height: 24.1,
                                    child: SvgPicture.asset(
                                      'assets/vectors/vector_20_x2.svg',
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            SizedBox(
                              width: double.infinity,
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    margin: EdgeInsets.fromLTRB(0, 0, 0, 14.8),
                                    child: Align(
                                      alignment: Alignment.topLeft,
                                      child: Container(
                                        width: 89.7,
                                        height: 36.4,
                                        child: Container(
                                          decoration: BoxDecoration(
                                            image: DecorationImage(
                                              image: AssetImage(
                                                'assets/images/air_asia_1.png',
                                              ),
                                            ),
                                          ),
                                          child: Container(
                                            width: 89.7,
                                            height: 36.4,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Container(
                                    margin: EdgeInsets.fromLTRB(11.7, 0, 4.5, 9),
                                    child: Container(
                                      decoration: BoxDecoration(
                                        color: Color(0xFFDEDEDE),
                                      ),
                                      child: Container(
                                        width: 310,
                                        height: 1,
                                      ),
                                    ),
                                  ),
                                  Container(
                                    margin: EdgeInsets.fromLTRB(11.7, 0, 4.5, 2),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Container(
                                          margin: EdgeInsets.fromLTRB(0, 0, 9, 0),
                                          child: SizedBox(
                                            width: 241.9,
                                            child: Text(
                                              'Bandung',
                                              style: GoogleFonts.getFont(
                                                'Poppins',
                                                fontWeight: FontWeight.w500,
                                                fontSize: 12,
                                                color: Color(0xFFAAAAAA),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Text(
                                          'Denpasar',
                                          style: GoogleFonts.getFont(
                                            'Poppins',
                                            fontWeight: FontWeight.w500,
                                            fontSize: 12,
                                            color: Color(0xFFAAAAAA),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Container(
                                    margin: EdgeInsets.fromLTRB(11.7, 0, 4.5, 10),
                                    child: Container(
                                      padding: EdgeInsets.fromLTRB(0, 0, 0, 20),
                                      child: Stack(
                                        clipBehavior: Clip.none,
                                        children: [
                                          Text(
                                            'BDO',
                                            style: GoogleFonts.getFont(
                                              'Poppins',
                                              fontWeight: FontWeight.w600,
                                              fontSize: 30,
                                              color: Color(0xFF121212),
                                            ),
                                          ),
                                          Positioned(
                                            left: 0,
                                            right: 0,
                                            bottom: 0,
                                            child: SizedBox(
                                              width: 310,
                                              height: 18,
                                              child: Row(
                                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    margin: EdgeInsets.fromLTRB(0, 0, 9, 0),
                                                    child: SizedBox(
                                                      width: 192.1,
                                                      child: Text(
                                                        '9 Jan 23, 13:10 AM',
                                                        style: GoogleFonts.getFont(
                                                          'Poppins',
                                                          fontWeight: FontWeight.w500,
                                                          fontSize: 12,
                                                          color: Color(0xFF717171),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Text(
                                                    '9 Jan 23, 14:40 AM',
                                                    style: GoogleFonts.getFont(
                                                      'Poppins',
                                                      fontWeight: FontWeight.w500,
                                                      fontSize: 12,
                                                      color: Color(0xFF717171),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            left: 73.5,
                                            top: 23,
                                            child: Opacity(
                                              opacity: 0.7,
                                              child: Container(
                                                decoration: BoxDecoration(
                                                  color: Color(0xFF808080),
                                                ),
                                                child: Container(
                                                  width: 60,
                                                  height: 1,
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            bottom: 13,
                                            child: SizedBox(
                                              height: 18,
                                              child: Text(
                                                '1hr 30m',
                                                style: GoogleFonts.getFont(
                                                  'Poppins',
                                                  fontWeight: FontWeight.w500,
                                                  fontSize: 12,
                                                  color: Color(0xFF717171),
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            right: 71.5,
                                            top: 23,
                                            child: Opacity(
                                              opacity: 0.7,
                                              child: Container(
                                                decoration: BoxDecoration(
                                                  color: Color(0xFF808080),
                                                ),
                                                child: Container(
                                                  width: 60,
                                                  height: 1,
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            right: 0,
                                            top: 0,
                                            child: SizedBox(
                                              height: 45,
                                              child: Text(
                                                'DPS',
                                                style: GoogleFonts.getFont(
                                                  'Poppins',
                                                  fontWeight: FontWeight.w600,
                                                  fontSize: 30,
                                                  color: Color(0xFF121212),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  Container(
                                    margin: EdgeInsets.fromLTRB(11.7, 0, 4.5, 33.5),
                                    child: Container(
                                      decoration: BoxDecoration(
                                        color: Color(0xFFDEDEDE),
                                      ),
                                      child: Container(
                                        width: 310,
                                        height: 1,
                                      ),
                                    ),
                                  ),
                                  Container(
                                    margin: EdgeInsets.fromLTRB(6.7, 0, 0, 28.5),
                                    child: Container(
                                      decoration: BoxDecoration(
                                        color: Color(0xFF121212),
                                      ),
                                      child: Container(
                                        width: 319.5,
                                        height: 1,
                                      ),
                                    ),
                                  ),
                                  Container(
                                    margin: EdgeInsets.fromLTRB(11.7, 0, 4.5, 27),
                                    child: Column(
                                      mainAxisAlignment: MainAxisAlignment.start,
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Container(
                                          margin: EdgeInsets.fromLTRB(0, 0, 0, 17),
                                          child: Column(
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Container(
                                                margin: EdgeInsets.fromLTRB(0, 0, 10, 2),
                                                child: Row(
                                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    Container(
                                                      margin: EdgeInsets.fromLTRB(0, 0, 9, 0),
                                                      child: SizedBox(
                                                        width: 129.3,
                                                        child: Text(
                                                          'Flight No',
                                                          style: GoogleFonts.getFont(
                                                            'Poppins',
                                                            fontWeight: FontWeight.w500,
                                                            fontSize: 12,
                                                            color: Color(0xFFAAAAAA),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Text(
                                                      'Class',
                                                      style: GoogleFonts.getFont(
                                                        'Poppins',
                                                        fontWeight: FontWeight.w500,
                                                        fontSize: 12,
                                                        color: Color(0xFFAAAAAA),
                                                      ),
                                                    ),
                                                    Text(
                                                      'Ticket ID',
                                                      style: GoogleFonts.getFont(
                                                        'Poppins',
                                                        fontWeight: FontWeight.w500,
                                                        fontSize: 12,
                                                        color: Color(0xFFAAAAAA),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              Row(
                                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    margin: EdgeInsets.fromLTRB(0, 0, 10.5, 0),
                                                    child: SizedBox(
                                                      width: 127.9,
                                                      child: Text(
                                                        '673DPS',
                                                        style: GoogleFonts.getFont(
                                                          'Poppins',
                                                          fontWeight: FontWeight.w600,
                                                          fontSize: 14,
                                                          color: Color(0xFF121212),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Text(
                                                    'Economy',
                                                    style: GoogleFonts.getFont(
                                                      'Poppins',
                                                      fontWeight: FontWeight.w600,
                                                      fontSize: 14,
                                                      color: Color(0xFF121212),
                                                    ),
                                                  ),
                                                  Text(
                                                    'A062232',
                                                    style: GoogleFonts.getFont(
                                                      'Poppins',
                                                      fontWeight: FontWeight.w600,
                                                      fontSize: 14,
                                                      color: Color(0xFF121212),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ],
                                          ),
                                        ),
                                        Container(
                                          margin: EdgeInsets.fromLTRB(0, 0, 4, 0),
                                          child: Column(
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Container(
                                                margin: EdgeInsets.fromLTRB(0, 0, 0, 2),
                                                child: Row(
                                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    Container(
                                                      margin: EdgeInsets.fromLTRB(0, 0, 9, 0),
                                                      child: SizedBox(
                                                        width: 129.4,
                                                        child: Text(
                                                          'Passenger',
                                                          style: GoogleFonts.getFont(
                                                            'Poppins',
                                                            fontWeight: FontWeight.w500,
                                                            fontSize: 12,
                                                            color: Color(0xFFAAAAAA),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Text(
                                                      'Seat',
                                                      style: GoogleFonts.getFont(
                                                        'Poppins',
                                                        fontWeight: FontWeight.w500,
                                                        fontSize: 12,
                                                        color: Color(0xFFAAAAAA),
                                                      ),
                                                    ),
                                                    Text(
                                                      'Baggage',
                                                      style: GoogleFonts.getFont(
                                                        'Poppins',
                                                        fontWeight: FontWeight.w500,
                                                        fontSize: 12,
                                                        color: Color(0xFFAAAAAA),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              Container(
                                                margin: EdgeInsets.fromLTRB(0, 0, 20, 0),
                                                child: Row(
                                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    Container(
                                                      margin: EdgeInsets.fromLTRB(0, 0, 10.5, 0),
                                                      child: SizedBox(
                                                        width: 128,
                                                        child: Text(
                                                          '1 Adult',
                                                          style: GoogleFonts.getFont(
                                                            'Poppins',
                                                            fontWeight: FontWeight.w600,
                                                            fontSize: 14,
                                                            color: Color(0xFF121212),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Text(
                                                      'A18',
                                                      style: GoogleFonts.getFont(
                                                        'Poppins',
                                                        fontWeight: FontWeight.w600,
                                                        fontSize: 14,
                                                        color: Color(0xFF121212),
                                                      ),
                                                    ),
                                                    Text(
                                                      '20kg',
                                                      style: GoogleFonts.getFont(
                                                        'Poppins',
                                                        fontWeight: FontWeight.w600,
                                                        fontSize: 14,
                                                        color: Color(0xFF121212),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Container(
                                    margin: EdgeInsets.fromLTRB(6.7, 0, 0, 29),
                                    child: Container(
                                      decoration: BoxDecoration(
                                        color: Color(0xFF121212),
                                      ),
                                      child: Container(
                                        width: 319.5,
                                        height: 1,
                                      ),
                                    ),
                                  ),
                                  Container(
                                    margin: EdgeInsets.fromLTRB(8.2, 0, 0, 0),
                                    child: Align(
                                      alignment: Alignment.topCenter,
                                      child: Column(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          Container(
                                            decoration: BoxDecoration(
                                              image: DecorationImage(
                                                fit: BoxFit.cover,
                                                image: AssetImage(
                                                  'assets/images/image_3.png',
                                                ),
                                              ),
                                            ),
                                            child: Container(
                                              width: 87,
                                              height: 87,
                                            ),
                                          ),
                                          Container(
                                            margin: EdgeInsets.fromLTRB(7, 0, 8, 0),
                                            child: Text(
                                              'Scan Here',
                                              style: GoogleFonts.getFont(
                                                'Poppins',
                                                fontWeight: FontWeight.w600,
                                                fontSize: 14,
                                                color: Color(0xFF121212),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}